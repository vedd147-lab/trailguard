import 'dotenv/config';
import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '8mb' }));

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function getWindCardinal(deg: number): string {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const idx = Math.round((((deg % 360) + 360) % 360) / 45) % 8;
  return dirs[idx];
}

function describeWmoCode(code: number): string {
  if (code === 0) return 'Clear sky';
  if (code <= 3) return 'Partly cloudy';
  if (code === 45 || code === 48) return 'Dense ridge fog';
  if (code >= 51 && code <= 57) return 'Light drizzle';
  if (code >= 61 && code <= 67) return 'Steady rain';
  if (code >= 71 && code <= 77) return 'Snowfall';
  if (code >= 80 && code <= 82) return 'Rain showers';
  if (code >= 95) return 'Thunderstorm risk';
  return 'Variable mountain weather';
}

// Live Open-Meteo Mountain Weather API
app.get('/api/weather', async (req: Request, res: Response) => {
  const lat = Number(req.query.lat);
  const lon = Number(req.query.lon);
  const name = typeof req.query.name === 'string' ? req.query.name.slice(0, 80) : 'Mountain Location';

  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return res.status(400).json({ error: 'Valid numeric lat and lon query parameters are required.' });
  }

  try {
    const url = new URL('https://api.open-meteo.com/v1/forecast');
    url.searchParams.set('latitude', lat.toFixed(4));
    url.searchParams.set('longitude', lon.toFixed(4));
    url.searchParams.set(
      'current',
      'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m'
    );
    url.searchParams.set(
      'hourly',
      'temperature_2m,precipitation_probability,precipitation,visibility,wind_speed_10m,cloud_cover'
    );
    url.searchParams.set('daily', 'sunrise,sunset,precipitation_sum,wind_speed_10m_max');
    url.searchParams.set('timezone', 'auto');
    url.searchParams.set('forecast_days', '2');

    const response = await fetch(url.toString(), { signal: AbortSignal.timeout(9000) });
    if (!response.ok) {
      return res.status(502).json({
        error: `Open-Meteo returned status ${response.status}`,
        source: 'Open-Meteo Forecast API',
      });
    }

    const data: any = await response.json();
    const cur = data.current || {};
    const hourly = data.hourly || {};
    const daily = data.daily || {};

    const nowIdx = 0;
    const visibilityM = Array.isArray(hourly.visibility) ? Number(hourly.visibility[nowIdx] ?? 10000) : 10000;
    const rainProb = Array.isArray(hourly.precipitation_probability)
      ? Number(hourly.precipitation_probability[nowIdx] ?? 0)
      : 0;

    const windSpeedKmh = Number(cur.wind_speed_10m ?? 0);
    const windDirDeg = Number(cur.wind_direction_10m ?? 0);
    const rainfallMm = Number(cur.rain ?? cur.precipitation ?? 0);
    const tempC = Number(cur.temperature_2m ?? 0);
    const feelsLikeC = Number(cur.apparent_temperature ?? tempC);
    const humidity = Number(cur.relative_humidity_2m ?? 0);
    const cloudCover = Number(cur.cloud_cover ?? 0);
    const weatherCode = Number(cur.weather_code ?? 0);

    const warnings: string[] = [];
    if (windSpeedKmh >= 40) warnings.push(`Strong ridge gusts (${windSpeedKmh.toFixed(0)} km/h)`);
    if (rainProb >= 60 || rainfallMm >= 2) warnings.push(`Elevated rain & slippery rock risk (${rainProb}% prob)`);
    if (visibilityM < 2000 || weatherCode === 45 || weatherCode === 48) {
      warnings.push(`Low visibility / fog alert (${(visibilityM / 1000).toFixed(1)} km)`);
    }
    if (weatherCode >= 95) warnings.push('Thunderstorm activity forecast — avoid exposed summits');
    if (tempC <= 4) warnings.push(`Cold alpine exposure (${tempC.toFixed(1)}°C)`);
    if (feelsLikeC >= 35) warnings.push(`Heat exhaustion risk (${feelsLikeC.toFixed(1)}°C feels like)`);

    let goodTimeVerdict: 'Favorable Window' | 'Proceed with Caution' | 'Unfavorable Conditions' = 'Favorable Window';
    if (weatherCode >= 95 || windSpeedKmh >= 50 || rainfallMm >= 8 || visibilityM < 800) {
      goodTimeVerdict = 'Unfavorable Conditions';
    } else if (warnings.length > 0 || rainProb >= 40 || cloudCover >= 85) {
      goodTimeVerdict = 'Proceed with Caution';
    }

    const nextHours = (hourly.time || []).slice(0, 8).map((t: string, i: number) => ({
      time: t,
      tempC: Number(hourly.temperature_2m?.[i] ?? tempC),
      rainProb: Number(hourly.precipitation_probability?.[i] ?? 0),
      windKmh: Number(hourly.wind_speed_10m?.[i] ?? windSpeedKmh),
      visibilityM: Number(hourly.visibility?.[i] ?? visibilityM),
    }));

    return res.json({
      locationName: name,
      coordinates: { lat, lon },
      elevationM: Number(data.elevation ?? 0),
      source: 'Open-Meteo Forecast API',
      fetchedAt: new Date().toISOString(),
      uncertaintyNote:
        'Open-Meteo provides 1–11 km grid model forecasts. Mountain ridges and cliffs can experience sudden microclimate shifts.',
      current: {
        temperatureC: tempC,
        feelsLikeC,
        rainProbabilityPct: rainProb,
        rainfallMm,
        windSpeedKmh,
        windDirectionDeg: windDirDeg,
        windCardinal: getWindCardinal(windDirDeg),
        humidityPct: humidity,
        visibilityKm: Number((visibilityM / 1000).toFixed(1)),
        cloudCoverPct: cloudCover,
        weatherCode,
        conditionLabel: describeWmoCode(weatherCode),
        sunrise: daily.sunrise?.[0] ?? null,
        sunset: daily.sunset?.[0] ?? null,
      },
      warnings,
      goodTimeToHike: {
        verdict: goodTimeVerdict,
        rationale:
          warnings.length > 0
            ? warnings.join(' · ')
            : 'Model winds, precipitation, and visibility are within standard daytime trekking thresholds.',
      },
      hourlyPreview: nextHours,
    });
  } catch (err: any) {
    console.error('Open-Meteo weather fetch failed:', err);
    return res.status(502).json({
      error: 'Unable to reach Open-Meteo live weather feed right now.',
      details: err?.message || 'Network timeout',
    });
  }
});

// AI Trail Risk Intelligence
app.post('/api/ai/risk-analysis', async (req: Request, res: Response) => {
  const ai = getAiClient();
  if (!ai) {
    return res.status(503).json({
      error: 'Gemini AI service key is not configured in server secrets.',
    });
  }

  const { mountainName, elevationM, terrain, difficulty, weather, recentReports, historicalHazards } = req.body || {};
  if (!mountainName || typeof mountainName !== 'string') {
    return res.status(400).json({ error: 'mountainName is required.' });
  }

  try {
    const prompt = `Analyze mountain hiking risk for "${mountainName}" (${elevationM ?? 'unknown'} m).
Terrain: ${terrain ?? 'Basalt & rocky ridge'}.
Difficulty: ${difficulty ?? 'Moderate'}.
Live Weather Snapshot: ${JSON.stringify(weather ?? 'Unavailable')}.
Recent Verified/Reported Trail Hazards: ${JSON.stringify(recentReports ?? [])}.
Historical Hazard Profile: ${JSON.stringify(historicalHazards ?? [])}.

Provide an honest, safety-first risk assessment. Never present this as a certified official clearance—include explicit uncertainty guidance.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        systemInstruction:
          'You are TRAILGUARD Mountain Risk Intelligence. Return concise, grounded, conservative outdoor safety assessments in structured JSON.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskLevel: { type: Type.STRING, enum: ['Low', 'Moderate', 'High', 'Critical'] },
            hikeRecommendation: {
              type: Type.STRING,
              enum: ['Recommended', 'Proceed with Caution', 'Not Recommended'],
            },
            summary: { type: Type.STRING },
            factors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  factor: { type: Type.STRING },
                  impact: { type: Type.STRING, enum: ['Favorable', 'Caution', 'Elevated Risk'] },
                  detail: { type: Type.STRING },
                },
                required: ['factor', 'impact', 'detail'],
              },
            },
            gearChecklist: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            uncertaintyDisclaimer: { type: Type.STRING },
          },
          required: ['riskLevel', 'hikeRecommendation', 'summary', 'factors', 'gearChecklist', 'uncertaintyDisclaimer'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    return res.json({
      ...parsed,
      model: 'gemini-4-hydrogen',
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Gemini risk-analysis error:', err);
    return res.status(502).json({
      error: 'AI risk analysis failed to generate from Gemini.',
      details: err?.message || 'Upstream AI error',
    });
  }
});

// AI Hazard Computer Vision Classification
app.post('/api/ai/hazard-vision', async (req: Request, res: Response) => {
  const ai = getAiClient();
  if (!ai) {
    return res.status(503).json({
      error: 'Gemini AI service key is not configured in server secrets.',
    });
  }

  const { imageBase64, mimeType, mountainName, notes } = req.body || {};
  if (!imageBase64 || typeof imageBase64 !== 'string') {
    return res.status(400).json({ error: 'imageBase64 is required.' });
  }

  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  const safeMime = allowedTypes.includes(mimeType) ? mimeType : 'image/jpeg';
  const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: safeMime,
              data: cleanBase64,
            },
          },
          {
            text: `Classify any hiking trail hazard visible in this photograph from ${mountainName || 'a mountain trail'}. Hiker note: ${notes || 'None'}. Choose the closest category and describe observable terrain evidence honestly.`,
          },
        ],
      },
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedCategory: {
              type: Type.STRING,
              enum: [
                'Landslides',
                'Rockfalls',
                'Fallen trees',
                'Damaged bridges',
                'Flooding',
                'Muddy trails',
                'Slippery trails',
                'Poor visibility',
                'Clear / No visible hazard',
              ],
            },
            severity: { type: Type.STRING, enum: ['Low', 'Moderate', 'High', 'Critical'] },
            confidenceLabel: { type: Type.STRING, enum: ['High visual clarity', 'Moderate visual clarity', 'Low clarity — verify manually'] },
            observations: { type: Type.STRING },
            recommendedAction: { type: Type.STRING },
          },
          required: ['detectedCategory', 'severity', 'confidenceLabel', 'observations', 'recommendedAction'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    return res.json({
      ...parsed,
      requiresHumanVerification: true,
      model: 'gemini-4-hydrogen',
      analyzedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Gemini hazard-vision error:', err);
    return res.status(502).json({
      error: 'Hazard image classification failed.',
      details: err?.message || 'Upstream AI error',
    });
  }
});

// AI Crowd Intelligence Forecast
app.post('/api/ai/crowd-forecast', async (req: Request, res: Response) => {
  const ai = getAiClient();
  if (!ai) {
    return res.status(503).json({
      error: 'Gemini AI service key is not configured in server secrets.',
    });
  }

  const { mountainName, activeSessionsCount, historicalBaselineDaily, dayOfWeek, weatherSummary, trails } =
    req.body || {};

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Estimate crowd patterns for ${mountainName || 'mountain'}.
Active verified GPS sessions right now: ${Number(activeSessionsCount ?? 0)}.
Historical baseline daily range: ${historicalBaselineDaily ?? 'Unknown'}.
Day of week: ${dayOfWeek ?? 'Today'}.
Weather summary: ${weatherSummary ?? 'Unknown'}.
Trails: ${JSON.stringify(trails ?? [])}.
Clearly distinguish observed live counts from experimental model projections.`,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            expectedDensity: { type: Type.STRING, enum: ['Low', 'Moderate', 'High', 'Peak Congestion'] },
            peakWindow: { type: Type.STRING },
            recommendedArrivalWindow: { type: Type.STRING },
            bottleneckNotes: { type: Type.STRING },
            experimentalNote: { type: Type.STRING },
          },
          required: ['expectedDensity', 'peakWindow', 'recommendedArrivalWindow', 'bottleneckNotes', 'experimentalNote'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    return res.json({
      ...parsed,
      model: 'gemini-4-hydrogen',
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Gemini crowd-forecast error:', err);
    return res.status(502).json({
      error: 'AI crowd estimation failed.',
      details: err?.message || 'Upstream AI error',
    });
  }
});

// Emergency SOS Notification Workflow
const sosLogPath = path.resolve(__dirname, '.sos_dispatch_log.json');

app.post('/api/sos/dispatch', async (req: Request, res: Response) => {
  const { displayName, mountainName, lat, lng, message, emergencyContacts } = req.body || {};
  if (!Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) {
    return res.status(400).json({ error: 'Valid GPS coordinates (lat, lng) are required for SOS dispatch.' });
  }

  const referenceId = `SOS-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  const dispatchedAt = new Date().toISOString();
  const safeContacts = Array.isArray(emergencyContacts) ? emergencyContacts.slice(0, 5) : [];

  const record = {
    referenceId,
    dispatchedAt,
    displayName: typeof displayName === 'string' ? displayName.slice(0, 80) : 'Hiker',
    mountainName: typeof mountainName === 'string' ? mountainName.slice(0, 80) : 'Unknown location',
    coordinates: { lat: Number(lat), lng: Number(lng) },
    message: typeof message === 'string' ? message.slice(0, 500) : 'Emergency assistance requested',
    contactsQueued: safeContacts.map((c: any) => ({
      name: String(c?.name || 'Contact').slice(0, 60),
      phone: String(c?.phone || '').slice(0, 30),
      status: 'Payload prepared (manual SMS/call link required from device)',
    })),
  };

  let webhookDelivered = false;
  const webhookUrl = process.env.SOS_WEBHOOK_URL;
  if (webhookUrl && webhookUrl.startsWith('https://')) {
    try {
      const hookRes = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
        signal: AbortSignal.timeout(5000),
      });
      webhookDelivered = hookRes.ok;
    } catch (e) {
      console.error('SOS webhook failed:', e);
    }
  }

  try {
    let existingLogs: any[] = [];
    if (fs.existsSync(sosLogPath)) {
      existingLogs = JSON.parse(fs.readFileSync(sosLogPath, 'utf8'));
    }
    existingLogs.unshift(record);
    fs.writeFileSync(sosLogPath, JSON.stringify(existingLogs.slice(0, 50), null, 2));
  } catch (e) {
    console.error('Failed to persist local SOS audit log:', e);
  }

  return res.json({
    ...record,
    webhookDelivered,
    emergencyServicesContacted: false,
    honestStatus:
      'SOS coordinates logged on TRAILGUARD. Official emergency services (112 / Mountain Rescue) are NOT automatically contacted by a web browser—use the direct 112 Call or SMS trigger immediately.',
  });
});

async function startServer() {
  const PORT = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TRAILGUARD server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
