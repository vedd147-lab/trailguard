// Static verification tests for TRAILGUARD Firestore security rules ("Dirty Dozen")
import assert from 'node:assert/strict';
import fs from 'node:fs';

const rules = fs.readFileSync(new URL('./DRAFT_firestore.rules', import.meta.url), 'utf8');

// Verify Eight Pillars structural invariants exist in the ruleset
assert.ok(rules.includes("rules_version = '2';"), 'Rules version 2 required');
assert.ok(rules.includes('match /{document=**} {\n      allow read, write: if false;'), 'Default deny required');
assert.ok(rules.includes('function isValidId(id)'), 'isValidId path guard required');
assert.ok(rules.includes("request.auth.token.email == 'vedd147@gmail.com'"), 'Bootstrapped admin email required');
assert.ok(rules.includes('email_verified == true'), 'Email verification enforcement required');
assert.ok(rules.includes('isValidUserPrivate'), 'Private user validation required');
assert.ok(rules.includes('isValidTrailReport'), 'Trail report validation required');
assert.ok(rules.includes('isValidHikingSession'), 'Hiking session validation required');
assert.ok(rules.includes('isValidSosAlert'), 'SOS alert validation required');
assert.ok(rules.includes("resource.data.shareMode == 'public'"), 'Secure list query on hiking_sessions required');
assert.ok(rules.includes('allow update, delete: if false;'), 'Immutable audit logs required');

console.log('All static Firestore security rule invariants verified.');
