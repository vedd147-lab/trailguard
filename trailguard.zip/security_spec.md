# TRAILGUARD Firestore Security Specification

## 1. Data Invariants
1. **PII Isolation**: User emails, emergency contacts, and private sharing toggles live exclusively in `/users/{uid}` and are readable/writable only by the verified account owner or an administrator. Public display stats live in `/public_profiles/{uid}` without PII.
2. **Identity Integrity**: Every user-authored record (`trail_reports`, `hiking_sessions`, `sos_alerts`, `community_posts`, `hiking_groups`) enforces `incoming().uid == request.auth.uid` (or `reporterUid` / `leaderUid`) on creation and forbids changing ownership fields on update.
3. **Temporal Integrity**: All `createdAt` and `updatedAt` timestamps on write must equal `request.time`.
4. **Session Privacy Boundary**: `hiking_sessions` with `shareMode == 'private'` are strictly inaccessible to non-owners; only `shareMode == 'public'` sessions are listable for aggregate live crowd metrics.
5. **Immutable Audit Trail**: `admin_audit_logs` are append-only by verified admins (`vedd147@gmail.com` or `/admins/{uid}`) and cannot be modified or deleted.

## 2. Adversarial Test Payloads ("Dirty Dozen")
1. **Shadow Field Injection on Profile Create**: `{ uid, email, displayName, ..., isAdmin: true }` -> `PERMISSION_DENIED` (`hasOnly` rejects `isAdmin`).
2. **Cross-Owner Impersonation on Report**: `{ ..., reporterUid: "victim_uid" }` -> `PERMISSION_DENIED` (`reporterUid == request.auth.uid` fails).
3. **Client Timestamp Forgery**: `{ ..., createdAt: "2020-01-01T00:00:00Z" }` -> `PERMISSION_DENIED` (`createdAt == request.time` fails).
4. **Unverified Email Write**: Signed-in user with `email_verified: false` attempting `create` on `trail_reports` -> `PERMISSION_DENIED`.
5. **ID Poisoning Attack**: `create` on `/trail_reports/<1500-char-junk>` -> `PERMISSION_DENIED` (`isValidId` rejects).
6. **PII Scraping Read**: Authenticated non-owner `get` on `/users/other_uid` -> `PERMISSION_DENIED`.
7. **Private Hiking Session Scraping**: Non-owner `list` on `/hiking_sessions` without `shareMode == 'public'` -> `PERMISSION_DENIED`.
8. **SOS Alert Leakage**: Non-owner `get` on `/sos_alerts/{alertId}` -> `PERMISSION_DENIED`.
9. **Terminal State Bypass**: Non-admin attempting to edit a `Resolved` trail report -> `PERMISSION_DENIED`.
10. **Vote Inflation Attack**: User updating `confirmCount` from `1` to `999` -> `PERMISSION_DENIED` (`confirmCount == existing().confirmCount + 1`).
11. **Admin Override Privilege Escalation**: Non-admin attempting `create` on `/trail_overrides/{id}` -> `PERMISSION_DENIED`.
12. **Audit Log Tampering**: Admin attempting `delete` or `update` on `/admin_audit_logs/{id}` -> `PERMISSION_DENIED`.
