import React, { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, Cpu, FileWarning, ShieldAlert, UserCheck } from 'lucide-react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TrailDataProvider, useTrailData } from './context/TrailDataContext';
import { MOUNTAINS } from './data/mountains';
import { PageRoute } from './types/trailguard';

import { HomePage } from './pages/HomePage';
import { ExploreMountainsPage } from './pages/ExploreMountainsPage';
import { MountainDetailPage } from './pages/MountainDetailPage';
import { LiveMapPage } from './pages/LiveMapPage';
import { ConditionsPage } from './pages/ConditionsPage';
import { TrailReportsPage } from './pages/TrailReportsPage';
import { AiRiskPage } from './pages/AiRiskPage';
import { EmergencyPage } from './pages/EmergencyPage';
import { CommunityPage } from './pages/CommunityPage';
import { DashboardPage } from './pages/DashboardPage';
import { ProfilePage } from './pages/ProfilePage';
import { AdminPage } from './pages/AdminPage';
import { AboutPage, ContactPage, PrivacyPage, TermsPage } from './pages/InfoPages';

interface RouteState {
  route: PageRoute;
  mountainId: string;
}

const DEFAULT_MOUNTAIN_ID = MOUNTAINS[0].id;

function parseHash(): RouteState {
  const raw = window.location.hash.replace(/^#\/?/, '').trim();
  if (!raw) {
    return { route: 'home', mountainId: DEFAULT_MOUNTAIN_ID };
  }

  const [segment, param] = raw.split('/');
  const validMountain = MOUNTAINS.some((m) => m.id === param) ? param : DEFAULT_MOUNTAIN_ID;

  switch (segment) {
    case 'mountains':
      return { route: 'mountains', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'mountain':
      return { route: 'mountain-detail', mountainId: validMountain };
    case 'map':
      return { route: 'map', mountainId: param ? validMountain : DEFAULT_MOUNTAIN_ID };
    case 'conditions':
      return { route: 'conditions', mountainId: param ? validMountain : DEFAULT_MOUNTAIN_ID };
    case 'reports':
      return { route: 'reports', mountainId: param ? validMountain : DEFAULT_MOUNTAIN_ID };
    case 'ai-risk':
      return { route: 'ai-risk', mountainId: param ? validMountain : DEFAULT_MOUNTAIN_ID };
    case 'emergency':
      return { route: 'emergency', mountainId: param ? validMountain : DEFAULT_MOUNTAIN_ID };
    case 'community':
      return { route: 'community', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'dashboard':
      return { route: 'dashboard', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'profile':
      return { route: 'profile', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'admin':
      return { route: 'admin', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'about':
      return { route: 'about', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'contact':
      return { route: 'contact', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'privacy':
      return { route: 'privacy', mountainId: DEFAULT_MOUNTAIN_ID };
    case 'terms':
      return { route: 'terms', mountainId: DEFAULT_MOUNTAIN_ID };
    default:
      return { route: 'home', mountainId: DEFAULT_MOUNTAIN_ID };
  }
}

function buildHash(route: PageRoute, mountainId?: string): string {
  const targetMountain = mountainId || DEFAULT_MOUNTAIN_ID;
  switch (route) {
    case 'home':
      return '#/';
    case 'mountain-detail':
      return `#/mountain/${targetMountain}`;
    case 'map':
    case 'conditions':
    case 'reports':
    case 'ai-risk':
    case 'emergency':
      return mountainId ? `#/${route}/${targetMountain}` : `#/${route}`;
    default:
      return `#/${route}`;
  }
}

function AppShell() {
  const { isAdmin, user } = useAuth();
  const { isOnline, queuedOfflineReports, activeSession } = useTrailData();
  const [routeState, setRouteState] = useState<RouteState>(() => parseHash());

  useEffect(() => {
    const onHashChange = () => {
      setRouteState(parseHash());
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = useCallback((route: PageRoute, mountainId?: string) => {
    const nextHash = buildHash(route, mountainId);
    if (window.location.hash !== nextHash) {
      window.location.hash = nextHash;
    } else {
      setRouteState({
        route,
        mountainId: mountainId || DEFAULT_MOUNTAIN_ID,
      });
    }
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, []);

  const renderPage = () => {
    switch (routeState.route) {
      case 'home':
        return <HomePage onNavigate={navigate} />;
      case 'mountains':
        return <ExploreMountainsPage onNavigate={navigate} />;
      case 'mountain-detail':
        return <MountainDetailPage mountainId={routeState.mountainId} onNavigate={navigate} />;
      case 'map':
        return <LiveMapPage initialMountainId={routeState.mountainId} onNavigate={navigate} />;
      case 'conditions':
        return <ConditionsPage initialMountainId={routeState.mountainId} onNavigate={navigate} />;
      case 'reports':
        return <TrailReportsPage initialMountainId={routeState.mountainId} />;
      case 'ai-risk':
        return <AiRiskPage initialMountainId={routeState.mountainId} />;
      case 'emergency':
        return <EmergencyPage initialMountainId={routeState.mountainId} />;
      case 'community':
        return <CommunityPage />;
      case 'dashboard':
        return <DashboardPage onNavigate={navigate} />;
      case 'profile':
        return <ProfilePage />;
      case 'admin':
        return <AdminPage />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      case 'privacy':
        return <PrivacyPage />;
      case 'terms':
        return <TermsPage />;
      default:
        return <HomePage onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0B0E0D] text-[#E5E7EB]">
      <Navbar currentRoute={routeState.route} onNavigate={navigate} />

      {/* Secondary Operational Utility Strip (desktop & tablet quick access to safety tools) */}
      <div className="hidden md:block bg-[#0E1311] border-b border-white/10">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-10 flex items-center justify-between text-xs">
          <div className="flex items-center gap-5 text-gray-400">
            <button
              onClick={() => navigate('reports', routeState.mountainId)}
              className={`inline-flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer ${
                routeState.route === 'reports' ? 'text-emerald-400 font-semibold' : ''
              }`}
            >
              <FileWarning className="w-3.5 h-3.5" />
              Trail Reports
            </button>
            <button
              onClick={() => navigate('ai-risk', routeState.mountainId)}
              className={`inline-flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer ${
                routeState.route === 'ai-risk' ? 'text-emerald-400 font-semibold' : ''
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              AI Risk Intelligence
            </button>
            <button
              onClick={() => navigate('dashboard')}
              className={`inline-flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer ${
                routeState.route === 'dashboard' ? 'text-emerald-400 font-semibold' : ''
              }`}
            >
              Dashboard & Offline
            </button>
            {user && (
              <button
                onClick={() => navigate('profile')}
                className={`inline-flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer ${
                  routeState.route === 'profile' ? 'text-emerald-400 font-semibold' : ''
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                Profile
              </button>
            )}
            {isAdmin && (
              <button
                onClick={() => navigate('admin')}
                className={`inline-flex items-center gap-1.5 hover:text-amber-300 transition-colors cursor-pointer ${
                  routeState.route === 'admin' ? 'text-amber-400 font-semibold' : 'text-amber-400/80'
                }`}
              >
                Admin Console
              </button>
            )}
          </div>

          <div className="flex items-center gap-4">
            {!isOnline && (
              <span className="inline-flex items-center gap-1.5 text-amber-400 font-medium">
                <AlertTriangle className="w-3.5 h-3.5" />
                Offline Mode {queuedOfflineReports.length > 0 ? `(${queuedOfflineReports.length} queued)` : ''}
              </span>
            )}
            {activeSession && (
              <button
                onClick={() => navigate('map', activeSession.mountainId)}
                className="text-emerald-400 hover:text-emerald-300 font-medium cursor-pointer"
              >
                Active Hike: {activeSession.distanceTravelledKm.toFixed(2)} km
              </button>
            )}
            <button
              onClick={() => navigate('emergency', routeState.mountainId)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 text-red-300 font-semibold transition-colors cursor-pointer"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              SOS Emergency
            </button>
          </div>
        </div>
      </div>

      <main className="flex-1">{renderPage()}</main>

      <Footer onNavigate={navigate} />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <TrailDataProvider>
          <AppShell />
        </TrailDataProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
