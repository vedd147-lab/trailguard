export type PageRoute =
  | 'home'
  | 'mountains'
  | 'mountain-detail'
  | 'map'
  | 'conditions'
  | 'reports'
  | 'ai-risk'
  | 'emergency'
  | 'community'
  | 'dashboard'
  | 'profile'
  | 'admin'
  | 'about'
  | 'contact'
  | 'privacy'
  | 'terms';

export type TrailConditionColor = 'GREEN' | 'YELLOW' | 'RED' | 'GREY';

export type HazardCategory =
  | 'Landslides'
  | 'Rockfalls'
  | 'Fallen trees'
  | 'Damaged bridges'
  | 'Slippery trails'
  | 'Muddy trails'
  | 'Flooding'
  | 'Wildlife encounters'
  | 'Broken trail signs'
  | 'Blocked roads'
  | 'Poor visibility'
  | 'Other hazards';

export type ReportSeverity = 'Low' | 'Moderate' | 'High' | 'Critical';
export type ReportStatus = 'Newly reported' | 'Under verification' | 'Confirmed' | 'Resolved' | 'Expired';
export type ExperienceLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'Alpine';

export interface GeoPoint {
  lat: number;
  lng: number;
  elevationM?: number;
}

export interface MountainPoi {
  id: string;
  name: string;
  type: 'shelter' | 'water' | 'rescue' | 'trailhead' | 'summit';
  lat: number;
  lng: number;
  elevationM: number;
  notes: string;
  contactPhone?: string;
}

export interface MountainTrail {
  id: string;
  name: string;
  distanceKm: number;
  elevationGainM: number;
  estimatedDurationMin: number;
  difficulty: 'Easy' | 'Moderate' | 'Hard' | 'Severe';
  gradientPct: number;
  terrainType: string;
  weatherExposure: 'Low' | 'Moderate' | 'High' | 'Exposed Ridge';
  defaultCondition: TrailConditionColor;
  lastVerifiedLabel: string;
  routeTag: 'Easiest' | 'Shortest' | 'Most Challenging' | 'Alternative';
  safetyWarning: string;
  coordinates: [number, number][];
}

export interface Mountain {
  id: string;
  name: string;
  region: string;
  country: string;
  isInternational: boolean;
  elevationM: number;
  lat: number;
  lng: number;
  imageUrl: string;
  summary: string;
  terrainOverview: string;
  historicalHazards: string[];
  baselineDailyVisitorsRange: string;
  peakHoursLabel: string;
  nearestEmergencyNumber: string;
  boundaryPolygon: [number, number][];
  elevationProfile: { km: number; elevM: number }[];
  trails: MountainTrail[];
  pois: MountainPoi[];
}

export interface WeatherData {
  locationName: string;
  coordinates: { lat: number; lon: number };
  elevationM: number;
  source: string;
  fetchedAt: string;
  uncertaintyNote: string;
  current: {
    temperatureC: number;
    feelsLikeC: number;
    rainProbabilityPct: number;
    rainfallMm: number;
    windSpeedKmh: number;
    windDirectionDeg: number;
    windCardinal: string;
    humidityPct: number;
    visibilityKm: number;
    cloudCoverPct: number;
    weatherCode: number;
    conditionLabel: string;
    sunrise: string | null;
    sunset: string | null;
  };
  warnings: string[];
  goodTimeToHike: {
    verdict: 'Favorable Window' | 'Proceed with Caution' | 'Unfavorable Conditions';
    rationale: string;
  };
  hourlyPreview: {
    time: string;
    tempC: number;
    rainProb: number;
    windKmh: number;
    visibilityM: number;
  }[];
}

export interface TrailReport {
  id: string;
  mountainId: string;
  trailId: string;
  category: HazardCategory | string;
  severity: ReportSeverity;
  status: ReportStatus;
  description: string;
  lat: number;
  lng: number;
  reporterUid: string;
  reporterName: string;
  confirmCount: number;
  aiClassification?: string;
  createdAtIso: string;
  updatedAtIso: string;
}

export interface HikingSession {
  id: string;
  uid: string;
  displayName: string;
  mountainId: string;
  trailId: string;
  status: 'active' | 'paused' | 'completed' | 'expired';
  shareMode: 'private' | 'group' | 'public';
  groupId?: string;
  currentLat: number;
  currentLng: number;
  distanceTravelledKm: number;
  elevationGainedM: number;
  durationSec: number;
  startedAtIso: string;
  updatedAtIso: string;
  expiresAtMs: number;
}

export interface EmergencyContact {
  name: string;
  phone: string;
  relation: string;
}

export interface UserPrivateProfile {
  uid: string;
  email: string;
  displayName: string;
  experienceLevel: ExperienceLevel;
  shareLocationWithGroup: boolean;
  shareLocationPublicActivity: boolean;
  savedMountainIds: string[];
  emergencyContacts: EmergencyContact[];
}

export interface UserPublicProfile {
  uid: string;
  displayName: string;
  experienceLevel: ExperienceLevel;
  totalDistanceKm: number;
  totalElevationM: number;
  hikesCompleted: number;
  photoUrl?: string;
}

export interface CommunityPost {
  id: string;
  uid: string;
  authorName: string;
  mountainId: string;
  trailId: string;
  title: string;
  body: string;
  rating: number;
  likesCount: number;
  flagged: boolean;
  createdAtIso: string;
}

export interface HikingGroup {
  id: string;
  name: string;
  mountainId: string;
  leaderUid: string;
  leaderName: string;
  inviteCode: string;
  plannedDate: string;
}

export interface TrailStatusOverride {
  id: string;
  mountainId: string;
  trailId: string;
  condition: TrailConditionColor;
  reason: string;
  updatedBy: string;
  updatedAtIso: string;
}

export interface SosAlertRecord {
  id: string;
  uid: string;
  displayName: string;
  mountainId: string;
  lat: number;
  lng: number;
  message: string;
  status: 'active' | 'acknowledged' | 'resolved';
  createdAtIso: string;
}

export interface AdminAuditLog {
  id: string;
  adminUid: string;
  adminEmail: string;
  action: string;
  targetPath: string;
  details: string;
  createdAtIso: string;
}

export interface AiRiskResult {
  riskLevel: 'Low' | 'Moderate' | 'High' | 'Critical';
  hikeRecommendation: 'Recommended' | 'Proceed with Caution' | 'Not Recommended';
  summary: string;
  factors: { factor: string; impact: 'Favorable' | 'Caution' | 'Elevated Risk'; detail: string }[];
  gearChecklist: string[];
  uncertaintyDisclaimer: string;
  model: string;
  generatedAt: string;
}

export interface AiVisionResult {
  detectedCategory: string;
  severity: ReportSeverity;
  confidenceLabel: string;
  observations: string;
  recommendedAction: string;
  requiresHumanVerification: boolean;
  model: string;
  analyzedAt: string;
}

export interface AiCrowdResult {
  expectedDensity: 'Low' | 'Moderate' | 'High' | 'Peak Congestion';
  peakWindow: string;
  recommendedArrivalWindow: string;
  bottleneckNotes: string;
  experimentalNote: string;
  model: string;
  generatedAt: string;
}
