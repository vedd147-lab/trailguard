import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'An unexpected error occurred.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0B0E0D] text-[#E5E7EB] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-[#151C19] border border-white/10 rounded-xl p-8 space-y-4">
            <div className="flex items-center gap-3 text-amber-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h2 className="text-xl font-semibold">Application Recovery</h2>
            </div>
            <p className="text-sm text-gray-300 leading-relaxed">
              TRAILGUARD intercepted an unexpected operational error. Your offline mountain packs remain safely stored locally.
            </p>
            <pre className="text-xs font-mono bg-black/40 border border-white/10 rounded-lg p-3 overflow-x-auto text-gray-400">
              {this.state.message}
            </pre>
            <button
              onClick={() => {
                this.setState({ hasError: false, message: '' });
                window.location.hash = '#/';
              }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium rounded-lg transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Return to Home
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
