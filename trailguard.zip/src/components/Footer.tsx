import React from 'react';
import { PageRoute } from '../types/trailguard';
import { useAuth } from '../context/AuthContext';

interface FooterProps {
  onNavigate: (route: PageRoute) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const { isAdmin } = useAuth();

  return (
    <footer className="border-t border-white/10 bg-[#090C0B] text-gray-400">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        <div className="space-y-3">
          <p className="font-display text-lg font-bold text-white tracking-tight">TRAILGUARD</p>
          <p className="text-sm text-gray-400 leading-relaxed">
            Explore Smarter. Navigate Safer. Reach Further. Mountain intelligence, live weather, and community-verified trail safety.
          </p>
          <p className="text-xs text-gray-500">
            Weather data powered by Open-Meteo. Topographic layers via OpenStreetMap & OpenTopoMap.
          </p>
        </div>

        <div className="space-y-2.5">
          <h3 className="text-sm font-semibold text-white">Navigation & Safety</h3>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onNavigate('mountains')} className="hover:text-white transition-colors cursor-pointer">
                Explore Mountains
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('map')} className="hover:text-white transition-colors cursor-pointer">
                Live Topographic Map
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('reports')} className="hover:text-white transition-colors cursor-pointer">
                Trail Hazard Reports
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('ai-risk')} className="hover:text-white transition-colors cursor-pointer">
                AI Risk Intelligence
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('emergency')} className="text-red-400 hover:text-red-300 transition-colors cursor-pointer">
                Emergency & SOS Assistance
              </button>
            </li>
          </ul>
        </div>

        <div className="space-y-2.5">
          <h3 className="text-sm font-semibold text-white">Hiker Workspace</h3>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onNavigate('conditions')} className="hover:text-white transition-colors cursor-pointer">
                Live Conditions & Crowd
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('community')} className="hover:text-white transition-colors cursor-pointer">
                Community & Groups
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('dashboard')} className="hover:text-white transition-colors cursor-pointer">
                My Hiking Dashboard & Offline
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('profile')} className="hover:text-white transition-colors cursor-pointer">
                User Profile & Contacts
              </button>
            </li>
            {isAdmin && (
              <li>
                <button onClick={() => onNavigate('admin')} className="text-amber-400 hover:text-amber-300 transition-colors cursor-pointer">
                  Admin Moderation Console
                </button>
              </li>
            )}
          </ul>
        </div>

        <div className="space-y-2.5">
          <h3 className="text-sm font-semibold text-white">Organization & Legal</h3>
          <ul className="space-y-2 text-sm">
            <li>
              <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">
                About TRAILGUARD
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('contact')} className="hover:text-white transition-colors cursor-pointer">
                Contact Us
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('privacy')} className="hover:text-white transition-colors cursor-pointer">
                Privacy Policy
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors cursor-pointer">
                Terms & Safety Disclaimer
              </button>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-500">
          <span>© {new Date().getFullYear()} TRAILGUARD Mountain Intelligence Platform.</span>
          <span>Advisory platform only — always verify local forest checkpost advisories before ascending.</span>
        </div>
      </div>
    </footer>
  );
}
