import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Mountain, TrailConditionColor } from '../types/trailguard';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface MountainTerrain3DProps {
  mountain: Mountain;
  getTrailCondition: (mountainId: string, trailId: string, def: TrailConditionColor) => TrailConditionColor;
}

const CONDITION_COLORS: Record<TrailConditionColor, number> = {
  GREEN: 0x22c55e,
  YELLOW: 0xf59e0b,
  RED: 0xef4444,
  GREY: 0x9ca3af,
};

function terrainElevation(nx: number, nz: number, mountainId: string): number {
  const r = Math.sqrt(nx * nx + nz * nz);
  if (mountainId === 'mount-fuji') {
    const cone = Math.max(0, 1 - r * 0.95);
    const crater = r < 0.14 ? -0.18 * (1 - r / 0.14) : 0;
    const ribs = 0.045 * Math.sin(Math.atan2(nz, nx) * 14) * Math.min(1, r * 2.5) * Math.max(0, 1 - r);
    return (Math.pow(cone, 1.35) * 4.8 + crater + ribs) * 1.1;
  }
  if (mountainId === 'harishchandragad') {
    // Plateau with dramatic concave Konkan Kada cliff drop on the west (-nx)
    const ridge = Math.exp(-r * r * 1.6) * 3.4;
    const cliffDrop = nx < -0.12 ? Math.max(0, 1 - Math.abs(nz) * 1.4) * (-nx - 0.12) * 3.2 : 0;
    const folds = 0.25 * Math.sin(nx * 6) * Math.cos(nz * 5);
    return Math.max(0.1, ridge - cliffDrop + folds);
  }
  if (mountainId === 'rajmachi-fort') {
    // Twin peaks Shrivardhan & Manaranjan
    const d1 = Math.hypot(nx - 0.26, nz - 0.08);
    const d2 = Math.hypot(nx + 0.28, nz + 0.1);
    const p1 = Math.exp(-d1 * d1 * 5.2) * 3.1;
    const p2 = Math.exp(-d2 * d2 * 5.8) * 2.6;
    const saddle = Math.exp(-r * r * 1.4) * 1.1;
    return p1 + p2 + saddle + 0.15 * Math.sin(nx * 8 + nz * 6);
  }
  // Sinhagad escarpment plateau
  const plateau = Math.exp(-r * r * 1.9) * 3.1;
  const step = plateau > 1.8 ? 1.8 + (plateau - 1.8) * 0.45 : plateau;
  return step + 0.18 * Math.sin(nx * 7) * Math.cos(nz * 7);
}

export function MountainTerrain3D({ mountain, getTrailCondition }: MountainTerrain3DProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const presetTargetRef = useRef<{ pos: [number, number, number]; look: [number, number, number] } | null>(null);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [activePreset, setActivePreset] = useState<'overview' | 'summit' | 'approach'>('overview');
  const [wireframe, setWireframe] = useState(false);
  const wireframeRef = useRef(false);
  const terrainMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const requestRenderFnRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    wireframeRef.current = wireframe;
    if (terrainMatRef.current) {
      terrainMatRef.current.wireframe = wireframe;
      terrainMatRef.current.needsUpdate = true;
      requestRenderFnRef.current?.();
    }
  }, [wireframe]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 420;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0e0d);
    scene.fog = new THREE.FogExp2(0x0b0e0d, 0.032);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 120);
    camera.position.set(10.5, 7.2, 10.5);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    // Warm key sun + cool hemisphere sky/ground fill
    const keyLight = new THREE.DirectionalLight(0xffe7c2, 2.0);
    keyLight.position.set(12, 18, 8);
    if (!isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.left = -10;
      keyLight.shadow.camera.right = 10;
      keyLight.shadow.camera.top = 10;
      keyLight.shadow.camera.bottom = -10;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight(0x88b4d8, 0x1a261f, 0.75);
    scene.add(hemiLight);

    // Procedural Terrain Mesh
    const size = 16;
    const segs = 72;
    const geo = new THREE.PlaneGeometry(size, size, segs, segs);
    geo.rotateX(-Math.PI / 2);

    const posAttr = geo.attributes.position;
    const colors = new Float32Array(posAttr.count * 3);
    const cLow = new THREE.Color(0x162d21);
    const cMid = new THREE.Color(0x2d4035);
    const cRock = new THREE.Color(0x525753);
    const cPeak = new THREE.Color(mountain.id === 'mount-fuji' ? 0xe5e7eb : 0x7b8078);
    const tmpColor = new THREE.Color();

    for (let i = 0; i < posAttr.count; i++) {
      const vx = posAttr.getX(i);
      const vz = posAttr.getZ(i);
      const nx = vx / (size / 2);
      const nz = vz / (size / 2);
      const h = terrainElevation(nx, nz, mountain.id);
      posAttr.setY(i, h);

      if (h < 1.1) {
        tmpColor.copy(cLow).lerp(cMid, h / 1.1);
      } else if (h < 2.6) {
        tmpColor.copy(cMid).lerp(cRock, (h - 1.1) / 1.5);
      } else {
        tmpColor.copy(cRock).lerp(cPeak, Math.min(1, (h - 2.6) / 1.6));
      }
      colors[i * 3] = tmpColor.r;
      colors[i * 3 + 1] = tmpColor.g;
      colors[i * 3 + 2] = tmpColor.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.88,
      metalness: 0.04,
      wireframe: wireframeRef.current,
    });
    terrainMatRef.current = terrainMat;
    const terrainMesh = new THREE.Mesh(geo, terrainMat);
    terrainMesh.receiveShadow = true;
    terrainMesh.castShadow = !isSoftwareGl;
    scene.add(terrainMesh);

    // 3D Trail Routes overlaid cleanly onto terrain height
    const disposables: { dispose: () => void }[] = [geo, terrainMat, envTex];

    mountain.trails.forEach((trail, idx) => {
      const cond = getTrailCondition(mountain.id, trail.id, trail.defaultCondition);
      const pts: THREE.Vector3[] = [];
      const angle = (idx * Math.PI * 2) / Math.max(1, mountain.trails.length) + 0.4;
      for (let step = 0; step <= 24; step++) {
        const t = step / 24;
        const rad = (1 - t) * 5.8 + 0.25;
        const curveAngle = angle + Math.sin(t * Math.PI * 2) * 0.28;
        const px = Math.cos(curveAngle) * rad;
        const pz = Math.sin(curveAngle) * rad;
        const py = terrainElevation(px / (size / 2), pz / (size / 2), mountain.id) + 0.09;
        pts.push(new THREE.Vector3(px, py, pz));
      }
      const curve = new THREE.CatmullRomCurve3(pts);
      const tubeGeo = new THREE.TubeGeometry(curve, 48, 0.06, 8, false);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: CONDITION_COLORS[cond],
        roughness: 0.35,
        metalness: 0.2,
        emissive: CONDITION_COLORS[cond],
        emissiveIntensity: 0.25,
      });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      scene.add(tube);
      disposables.push(tubeGeo, tubeMat);
    });

    // Composite 4-part Summit Beacon Group (bottom-center pivot grounded on summit)
    const summitY = terrainElevation(0, 0, mountain.id);
    const beaconGroup = new THREE.Group();
    beaconGroup.position.set(0, summitY, 0);

    const plinthGeo = new THREE.CylinderGeometry(0.22, 0.28, 0.14, 16);
    const plinthMat = new THREE.MeshStandardMaterial({ color: 0x374151, roughness: 0.75, metalness: 0.2 });
    const plinth = new THREE.Mesh(plinthGeo, plinthMat);
    plinth.position.y = 0.07;

    const mastGeo = new THREE.CylinderGeometry(0.04, 0.05, 0.9, 12);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0xd1d5db, roughness: 0.25, metalness: 0.85 });
    const mast = new THREE.Mesh(mastGeo, mastMat);
    mast.position.y = 0.55;

    const collarGeo = new THREE.TorusGeometry(0.12, 0.025, 10, 24);
    const collar = new THREE.Mesh(collarGeo, mastMat);
    collar.rotation.x = Math.PI / 2;
    collar.position.y = 0.85;

    const headGeo = new THREE.OctahedronGeometry(0.14, 0);
    const headMat = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.2,
      metalness: 0.4,
      emissive: 0xf59e0b,
      emissiveIntensity: 0.4,
    });
    const head = new THREE.Mesh(headGeo, headMat);
    head.position.y = 1.08;

    beaconGroup.add(plinth, mast, collar, head);
    scene.add(beaconGroup);
    disposables.push(plinthGeo, plinthMat, mastGeo, mastMat, collarGeo, headGeo, headMat);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.maxPolarAngle = Math.PI / 2 - 0.08;
    controls.minDistance = 4;
    controls.maxDistance = 24;
    controls.target.set(0, summitY * 0.55, 0);

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    const targetPosVec = new THREE.Vector3();
    const targetLookVec = new THREE.Vector3();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function requestRender() {
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        renderDirty = false;
        if (presetTargetRef.current) {
          targetPosVec.set(...presetTargetRef.current.pos);
          targetLookVec.set(...presetTargetRef.current.look);
          const alpha = isSoftwareGl ? 1 : 1 - Math.exp(-6 * 0.016);
          camera.position.lerp(targetPosVec, alpha);
          controls.target.lerp(targetLookVec, alpha);
          if (camera.position.distanceTo(targetPosVec) < 0.05) {
            presetTargetRef.current = null;
          } else {
            renderDirty = true;
          }
        }
        controls.update();
        renderer.render(scene, camera);
        const done = () => {
          renderBusy = false;
          if (renderDirty) requestRender();
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    requestRenderFnRef.current = requestRender;

    controls.addEventListener('start', () => {
      presetTargetRef.current = null;
    });
    controls.addEventListener('change', requestRender);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    requestRender();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 420;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      controls.dispose();
      disposables.forEach((d) => d.dispose());
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [mountain.id]);

  const applyPreset = (preset: 'overview' | 'summit' | 'approach') => {
    setActivePreset(preset);
    const summitY = terrainElevation(0, 0, mountain.id);
    if (preset === 'overview') {
      presetTargetRef.current = { pos: [10.5, 7.2, 10.5], look: [0, summitY * 0.55, 0] };
    } else if (preset === 'summit') {
      presetTargetRef.current = { pos: [3.2, summitY + 2.4, 3.6], look: [0, summitY + 0.3, 0] };
    } else {
      presetTargetRef.current = { pos: [7.8, 3.4, -7.2], look: [0, summitY * 0.6, 0] };
    }
    requestRenderFnRef.current?.();
  };

  return (
    <div className="relative w-full h-[420px] rounded-xl overflow-hidden border border-white/10 bg-[#0B0E0D]">
      <div ref={mountRef} className="w-full h-full" />

      {/* Minimal Top-Left Label (no backdrop-filter over WebGL) */}
      <div className="pointer-events-none absolute top-3 left-3 bg-[#111614]/90 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-gray-200">
        <span className="font-semibold text-white">{mountain.name}</span>
        <span className="mx-1.5 text-gray-500">·</span>
        <span className="font-mono tabular-nums text-emerald-400">{mountain.elevationM} m</span>
        <span className="mx-1.5 text-gray-500">·</span>
        <span className="text-gray-400">Drag to orbit, scroll to zoom</span>
      </div>

      {/* Collapsible Bottom Control Dock (solid rgba, no backdrop-filter) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center max-w-[94vw]">
        <button
          type="button"
          onClick={() => setDockCollapsed((v) => !v)}
          className="inline-flex items-center gap-1 px-3 py-1 rounded-t-lg bg-[#141B18]/95 border border-b-0 border-white/15 text-[11px] font-medium text-gray-300 hover:text-white cursor-pointer"
        >
          {dockCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          {dockCollapsed ? 'Show 3D Controls' : 'Hide Controls'}
        </button>

        {!dockCollapsed && (
          <div className="flex flex-wrap items-center justify-center gap-2 px-3 py-2 rounded-xl bg-[#141B18]/95 border border-white/15 shadow-xl">
            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg">
              {(['overview', 'summit', 'approach'] as const).map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => applyPreset(preset)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer capitalize ${
                    activePreset === preset ? 'bg-emerald-600 text-white' : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setWireframe((v) => !v)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                wireframe
                  ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-300'
                  : 'bg-black/40 border-white/10 text-gray-300 hover:text-white'
              }`}
            >
              {wireframe ? 'Solid Relief' : 'Contour Mesh'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
