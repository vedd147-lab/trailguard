import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Mountain, TrailConditionColor, TrailReport, HikingSession } from '../types/trailguard';
import { LastKnownGps } from '../lib/offline';
import { Layers, LocateFixed, ShieldAlert } from 'lucide-react';

interface LiveMountainMapProps {
  mountain: Mountain;
  reports: TrailReport[];
  publicSessions: HikingSession[];
  userGps: LastKnownGps | null;
  getTrailCondition: (mountainId: string, trailId: string, def: TrailConditionColor) => TrailConditionColor;
  onSelectMapCoords?: (lat: number, lng: number) => void;
  onSelectReport?: (report: TrailReport) => void;
  heightClass?: string;
  compact?: boolean;
}

const CONDITION_HEX: Record<TrailConditionColor, string> = {
  GREEN: '#22C55E',
  YELLOW: '#F59E0B',
  RED: '#EF4444',
  GREY: '#9CA3AF',
};

const CONDITION_LABEL: Record<TrailConditionColor, string> = {
  GREEN: 'Verified Clear',
  YELLOW: 'Caution / Warning',
  RED: 'Dangerous / Blocked',
  GREY: 'Unverified Condition',
};

function makeCircleDivIcon(color: string, label: string, size = 24): L.DivIcon {
  return L.divIcon({
    className: 'trailguard-custom-marker',
    html: `<div style="width:${size}px;height:${size}px;border-radius:9999px;background:${color};border:2px solid #0b0e0d;box-shadow:0 2px 8px rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;color:#0b0e0d;font-weight:700;font-size:10px;font-family:monospace;">${label}</div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

export function LiveMountainMap({
  mountain,
  reports,
  publicSessions,
  userGps,
  getTrailCondition,
  onSelectMapCoords,
  onSelectReport,
  heightClass = 'h-[560px]',
  compact = false,
}: LiveMountainMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const [tileMode, setTileMode] = useState<'topo' | 'osm' | 'dark'>('topo');
  const [showBoundaries, setShowBoundaries] = useState(true);
  const [showPois, setShowPois] = useState(true);
  const [showHazards, setShowHazards] = useState(true);
  const [showActivity, setShowActivity] = useState(true);
  const [reportPinMode, setReportPinMode] = useState(false);

  // Initialize Leaflet map once
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, {
      center: [mountain.lat, mountain.lng],
      zoom: 13,
      zoomControl: true,
    });
    const layerGroup = L.layerGroup().addTo(map);
    mapRef.current = map;
    layerGroupRef.current = layerGroup;

    return () => {
      map.remove();
      mapRef.current = null;
      layerGroupRef.current = null;
      tileLayerRef.current = null;
    };
  }, []);

  // Re-center when mountain changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    map.setView([mountain.lat, mountain.lng], 13, { animate: true });
  }, [mountain.id, mountain.lat, mountain.lng]);

  // Update tile layer when mode changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }
    const configs = {
      topo: {
        url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        attribution: '&copy; OpenStreetMap contributors, SRTM | OpenTopoMap',
      },
      osm: {
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        attribution: '&copy; OpenStreetMap contributors',
      },
      dark: {
        url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
      },
    };
    const chosen = configs[tileMode];
    tileLayerRef.current = L.tileLayer(chosen.url, {
      maxZoom: 17,
      attribution: chosen.attribution,
    }).addTo(map);
  }, [tileMode]);

  // Handle click-to-report pin mode
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const handleClick = (e: L.LeafletMouseEvent) => {
      if (reportPinMode && onSelectMapCoords) {
        onSelectMapCoords(Number(e.latlng.lat.toFixed(5)), Number(e.latlng.lng.toFixed(5)));
        setReportPinMode(false);
      }
    };
    map.on('click', handleClick);
    return () => {
      map.off('click', handleClick);
    };
  }, [reportPinMode, onSelectMapCoords]);

  // Render overlays: boundaries, trails, POIs, hazards, active hikers, user GPS
  useEffect(() => {
    const group = layerGroupRef.current;
    if (!group) return;
    group.clearLayers();

    if (showBoundaries && mountain.boundaryPolygon.length >= 3) {
      L.polygon(mountain.boundaryPolygon, {
        color: '#6EE7B7',
        weight: 1.5,
        dashArray: '6 4',
        fillColor: '#10B981',
        fillOpacity: 0.06,
      })
        .bindPopup(`<strong>${mountain.name} Zone</strong><br/>Elevation: ${mountain.elevationM} m`)
        .addTo(group);
    }

    // Trails
    mountain.trails.forEach((trail) => {
      const cond = getTrailCondition(mountain.id, trail.id, trail.defaultCondition);
      const color = CONDITION_HEX[cond];
      const poly = L.polyline(trail.coordinates, {
        color,
        weight: 5,
        opacity: 0.92,
        dashArray: cond === 'GREY' ? '8 6' : undefined,
      }).addTo(group);

      poly.bindPopup(
        `<div style="min-width:200px">
          <div style="font-weight:700;font-size:13px;margin-bottom:4px;">${trail.name}</div>
          <div style="font-size:11px;color:${color};font-weight:600;margin-bottom:4px;">${cond} · ${CONDITION_LABEL[cond]}</div>
          <div style="font-size:11px;color:#d1d5db;">${trail.distanceKm} km · +${trail.elevationGainM} m · ${trail.difficulty}</div>
          <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${trail.lastVerifiedLabel}</div>
        </div>`
      );
    });

    // POIs
    if (showPois) {
      const poiColors: Record<string, { bg: string; tag: string }> = {
        summit: { bg: '#FBBF24', tag: '▲' },
        trailhead: { bg: '#34D399', tag: 'T' },
        shelter: { bg: '#60A5FA', tag: 'H' },
        water: { bg: '#38BDF8', tag: 'W' },
        rescue: { bg: '#F87171', tag: '+' },
      };

      mountain.pois.forEach((poi) => {
        const style = poiColors[poi.type] || { bg: '#D1D5DB', tag: 'P' };
        L.marker([poi.lat, poi.lng], {
          icon: makeCircleDivIcon(style.bg, style.tag, 24),
        })
          .bindPopup(
            `<div>
              <div style="font-weight:700;font-size:13px;">${poi.name}</div>
              <div style="font-size:11px;color:#9ca3af;text-transform:capitalize;">${poi.type} · ${poi.elevationM} m</div>
              <div style="font-size:11px;color:#e5e7eb;margin-top:4px;">${poi.notes}</div>
              ${poi.contactPhone ? `<div style="font-size:11px;color:#fca5a5;margin-top:4px;">Emergency: ${poi.contactPhone}</div>` : ''}
            </div>`
          )
          .addTo(group);
      });
    }

    // Hazard Reports
    if (showHazards) {
      const mountainReports = reports.filter(
        (r) => r.mountainId === mountain.id && r.status !== 'Resolved' && r.status !== 'Expired'
      );
      mountainReports.forEach((rep) => {
        const color = rep.severity === 'Critical' || rep.severity === 'High' ? '#EF4444' : '#F59E0B';
        const marker = L.marker([rep.lat, rep.lng], {
          icon: makeCircleDivIcon(color, '!', 26),
        }).addTo(group);

        marker.bindPopup(
          `<div style="min-width:210px">
            <div style="font-weight:700;font-size:13px;color:${color};">${rep.category} (${rep.severity})</div>
            <div style="font-size:11px;color:#9ca3af;margin:2px 0;">Status: ${rep.status} · Confirmations: ${rep.confirmCount}</div>
            <div style="font-size:11px;color:#e5e7eb;margin-top:4px;">${rep.description}</div>
            <div style="font-size:10px;color:#9ca3af;margin-top:4px;">Reported ${new Date(rep.createdAtIso).toLocaleString()}</div>
          </div>`
        );

        if (onSelectReport) {
          marker.on('click', () => onSelectReport(rep));
        }
      });
    }

    // Active Public Hikers
    if (showActivity) {
      publicSessions
        .filter((s) => s.mountainId === mountain.id)
        .forEach((s) => {
          L.marker([s.currentLat, s.currentLng], {
            icon: makeCircleDivIcon('#10B981', 'H', 20),
          })
            .bindPopup(
              `<div>
                <div style="font-weight:600;font-size:12px;">${s.displayName} (Shared Session)</div>
                <div style="font-size:11px;color:#9ca3af;">Status: ${s.status} · ${s.distanceTravelledKm.toFixed(2)} km</div>
              </div>`
            )
            .addTo(group);
        });
    }

    // Current User GPS Position
    if (userGps) {
      L.circleMarker([userGps.lat, userGps.lng], {
        radius: 8,
        color: '#ffffff',
        weight: 2.5,
        fillColor: '#3B82F6',
        fillOpacity: 1,
      })
        .bindPopup(
          `<div>
            <div style="font-weight:700;font-size:12px;">Your GPS Position</div>
            <div style="font-size:11px;font-family:monospace;">${userGps.lat.toFixed(5)}, ${userGps.lng.toFixed(5)}</div>
            <div style="font-size:10px;color:#9ca3af;">Updated ${new Date(userGps.timestampIso).toLocaleTimeString()}</div>
          </div>`
        )
        .addTo(group);
    }
  }, [mountain, reports, publicSessions, userGps, showBoundaries, showPois, showHazards, showActivity, getTrailCondition, onSelectReport]);

  return (
    <div className="relative w-full rounded-xl overflow-hidden border border-white/10 bg-[#0D1210]">
      <div ref={containerRef} className={`w-full ${heightClass} z-0`} />

      {/* Top-right Map Layer Controls */}
      <div className="absolute top-3 right-3 z-[400] flex flex-wrap items-center gap-1.5 bg-[#0B0E0D]/90 border border-white/15 rounded-lg p-1.5">
        <span className="inline-flex items-center gap-1 px-2 text-[11px] font-medium text-gray-400">
          <Layers className="w-3.5 h-3.5" />
        </span>
        {(['topo', 'osm', 'dark'] as const).map((mode) => (
          <button
            key={mode}
            type="button"
            onClick={() => setTileMode(mode)}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              tileMode === mode ? 'bg-emerald-600 text-white' : 'text-gray-300 hover:bg-white/10'
            }`}
          >
            {mode === 'topo' ? 'Topographic' : mode === 'osm' ? 'Standard' : 'Dark'}
          </button>
        ))}
      </div>

      {/* Bottom-left Legend & Overlays */}
      {!compact && (
        <div className="absolute bottom-3 left-3 z-[400] max-w-md bg-[#0B0E0D]/92 border border-white/15 rounded-lg p-3 space-y-2 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <span className="inline-flex items-center gap-1.5 text-gray-200">
              <span className="w-3 h-1 rounded bg-[#22C55E]" /> Clear
            </span>
            <span className="inline-flex items-center gap-1.5 text-gray-200">
              <span className="w-3 h-1 rounded bg-[#F59E0B]" /> Caution
            </span>
            <span className="inline-flex items-center gap-1.5 text-gray-200">
              <span className="w-3 h-1 rounded bg-[#EF4444]" /> Blocked / Danger
            </span>
            <span className="inline-flex items-center gap-1.5 text-gray-200">
              <span className="w-3 h-1 rounded bg-[#9CA3AF]" /> Unverified
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/10">
            <button
              type="button"
              onClick={() => setShowPois((v) => !v)}
              className={`px-2 py-1 rounded text-[11px] border cursor-pointer ${
                showPois ? 'bg-white/10 border-white/25 text-white' : 'border-white/10 text-gray-500'
              }`}
            >
              Shelters & Water
            </button>
            <button
              type="button"
              onClick={() => setShowHazards((v) => !v)}
              className={`px-2 py-1 rounded text-[11px] border cursor-pointer ${
                showHazards ? 'bg-white/10 border-white/25 text-white' : 'border-white/10 text-gray-500'
              }`}
            >
              Hazards
            </button>
            <button
              type="button"
              onClick={() => setShowActivity((v) => !v)}
              className={`px-2 py-1 rounded text-[11px] border cursor-pointer ${
                showActivity ? 'bg-white/10 border-white/25 text-white' : 'border-white/10 text-gray-500'
              }`}
            >
              Active Hikers
            </button>
            <button
              type="button"
              onClick={() => setShowBoundaries((v) => !v)}
              className={`px-2 py-1 rounded text-[11px] border cursor-pointer ${
                showBoundaries ? 'bg-white/10 border-white/25 text-white' : 'border-white/10 text-gray-500'
              }`}
            >
              Zone
            </button>
            {userGps && (
              <button
                type="button"
                onClick={() => mapRef.current?.setView([userGps.lat, userGps.lng], 15, { animate: true })}
                className="inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] bg-blue-600/30 border border-blue-400/40 text-blue-200 cursor-pointer"
              >
                <LocateFixed className="w-3 h-3" /> My GPS
              </button>
            )}
            {onSelectMapCoords && (
              <button
                type="button"
                onClick={() => setReportPinMode((v) => !v)}
                className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] border cursor-pointer ${
                  reportPinMode
                    ? 'bg-amber-500 text-black border-amber-400 font-semibold'
                    : 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                }`}
              >
                <ShieldAlert className="w-3 h-3" />
                {reportPinMode ? 'Click Map to Pin Hazard' : 'Pin Hazard on Map'}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
