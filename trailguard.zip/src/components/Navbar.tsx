import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PageRoute } from '../types/trailguard';

interface NavbarProps {
  currentRoute: PageRoute;
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

export function Navbar({ currentRoute, onNavigate }: NavbarProps) {
  const { user, signInWithGoogle, isAdmin } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks: { label: string; route: PageRoute }[] = [
    { label: 'Home', route: 'home' },
    { label: 'Mountains', route: 'mountains' },
    { label: 'Live Map', route: 'map' },
    { label: 'Conditions', route: 'conditions' },
    { label: 'Community', route: 'community' },
  ];

  const handlePrimaryAction = () => {
    if (user) {
      onNavigate('dashboard');
    } else {
      signInWithGoogle();
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0E0D]/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => onNavigate('home')}
          className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
        >
          TRAILGUARD
        </button>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-gray-300">
          {navLinks.map((item) => {
            const active =
              currentRoute === item.route ||
              (item.route === 'mountains' && currentRoute === 'mountain-detail');
            return (
              <button
                key={item.route}
                onClick={() => onNavigate(item.route)}
                className={`whitespace-nowrap shrink-0 py-1 transition-colors cursor-pointer border-b-2 ${
                  active
                    ? 'text-white border-emerald-500'
                    : 'text-gray-300 border-transparent hover:text-white hover:border-white/30'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action + mobile toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handlePrimaryAction}
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            {user ? 'My Dashboard' : 'Get Started'}
          </button>

          <button
            type="button"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-white/10 text-gray-200 hover:bg-white/5"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="md:hidden bg-[#111614] border-b border-white/10 px-4 py-4 space-y-2">
          {navLinks.map((item) => (
            <button
              key={item.route}
              onClick={() => {
                onNavigate(item.route);
                setMobileOpen(false);
              }}
              className="block w-full text-left px-3 py-2.5 text-sm font-medium text-gray-200 hover:bg-white/5 rounded-lg"
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-white/10 grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onNavigate('reports');
                setMobileOpen(false);
              }}
              className="px-3 py-2 text-xs font-medium text-gray-300 bg-white/5 rounded-lg text-left"
            >
              Trail Reports
            </button>
            <button
              onClick={() => {
                onNavigate('ai-risk');
                setMobileOpen(false);
              }}
              className="px-3 py-2 text-xs font-medium text-gray-300 bg-white/5 rounded-lg text-left"
            >
              AI Risk Analysis
            </button>
            <button
              onClick={() => {
                onNavigate('emergency');
                setMobileOpen(false);
              }}
              className="px-3 py-2 text-xs font-semibold text-red-300 bg-red-950/50 border border-red-500/30 rounded-lg text-left"
            >
              SOS Emergency
            </button>
            <button
              onClick={() => {
                onNavigate(user ? 'profile' : 'dashboard');
                setMobileOpen(false);
              }}
              className="px-3 py-2 text-xs font-medium text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-left"
            >
              {user ? 'Profile & Offline' : 'Dashboard'}
            </button>
            {isAdmin && (
              <button
                onClick={() => {
                  onNavigate('admin');
                  setMobileOpen(false);
                }}
                className="col-span-2 px-3 py-2 text-xs font-medium text-amber-300 bg-amber-950/40 border border-amber-500/30 rounded-lg text-left"
              >
                Admin Console
              </button>
            )}
          </div>
          <button
            onClick={() => {
              handlePrimaryAction();
              setMobileOpen(false);
            }}
            className="w-full py-2.5 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg"
          >
            {user ? 'Open My Dashboard' : 'Sign In with Google'}
          </button>
        </div>
      )}
    </header>
  );
}
