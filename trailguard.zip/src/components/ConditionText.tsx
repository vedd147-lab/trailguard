import React from 'react';
import { AlertTriangle, CheckCircle2, HelpCircle, OctagonAlert } from 'lucide-react';
import { TrailConditionColor } from '../types/trailguard';

export function ConditionText({ condition }: { condition: TrailConditionColor }) {
  if (condition === 'GREEN') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        Verified Clear
      </span>
    );
  }
  if (condition === 'YELLOW') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 whitespace-nowrap shrink-0">
        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
        Caution Advised
      </span>
    );
  }
  if (condition === 'RED') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-400 whitespace-nowrap shrink-0">
        <OctagonAlert className="w-3.5 h-3.5 shrink-0" />
        Danger / Blocked
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-gray-400 whitespace-nowrap shrink-0">
      <HelpCircle className="w-3.5 h-3.5 shrink-0" />
      Unverified
    </span>
  );
}
