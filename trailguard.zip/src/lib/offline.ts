import { Mountain, TrailReport } from '../types/trailguard';

const PACKS_KEY = 'trailguard_offline_packs_v1';
const QUEUE_KEY = 'trailguard_offline_report_queue_v1';
const LAST_GPS_KEY = 'trailguard_last_gps_v1';

export interface OfflineMountainPack {
  mountainId: string;
  mountainName: string;
  savedAtIso: string;
  mountain: Mountain;
  cachedReports: TrailReport[];
  emergencyInstructions: string[];
}

export interface QueuedOfflineReport {
  localId: string;
  mountainId: string;
  trailId: string;
  category: string;
  severity: 'Low' | 'Moderate' | 'High' | 'Critical';
  description: string;
  lat: number;
  lng: number;
  queuedAtIso: string;
}

export interface LastKnownGps {
  lat: number;
  lng: number;
  accuracyM?: number;
  timestampIso: string;
}

export const OFFLINE_EMERGENCY_PROTOCOL: string[] = [
  'Stop moving immediately if visibility drops below 20 meters or you lose trail cairns.',
  'Conserve phone battery: switch to Airplane Mode while not transmitting and enable Low Power Mode.',
  'Use the international alpine distress whistle/light signal: 6 blasts or flashes per minute, 1 minute pause, repeat.',
  'Move away from exposed ridge crests, lone trees, and metal railings if thunder or lightning approaches.',
  'Insulate body from wet basalt ground using a backpack or dry layers to prevent hypothermia.',
  'Record your last known coordinates on paper or local device storage before calling 112 / 110 / 119.',
];

export function getOfflinePacks(): OfflineMountainPack[] {
  try {
    const raw = localStorage.getItem(PACKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveOfflineMountainPack(mountain: Mountain, reports: TrailReport[]): OfflineMountainPack[] {
  const packs = getOfflinePacks().filter((p) => p.mountainId !== mountain.id);
  const pack: OfflineMountainPack = {
    mountainId: mountain.id,
    mountainName: mountain.name,
    savedAtIso: new Date().toISOString(),
    mountain,
    cachedReports: reports.filter((r) => r.mountainId === mountain.id).slice(0, 30),
    emergencyInstructions: OFFLINE_EMERGENCY_PROTOCOL,
  };
  const updated = [pack, ...packs];
  localStorage.setItem(PACKS_KEY, JSON.stringify(updated));
  return updated;
}

export function removeOfflineMountainPack(mountainId: string): OfflineMountainPack[] {
  const updated = getOfflinePacks().filter((p) => p.mountainId !== mountainId);
  localStorage.setItem(PACKS_KEY, JSON.stringify(updated));
  return updated;
}

export function getQueuedOfflineReports(): QueuedOfflineReport[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function enqueueOfflineReport(
  report: Omit<QueuedOfflineReport, 'localId' | 'queuedAtIso'>
): QueuedOfflineReport[] {
  const existing = getQueuedOfflineReports();
  const next: QueuedOfflineReport = {
    ...report,
    localId: `offline-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    queuedAtIso: new Date().toISOString(),
  };
  const updated = [next, ...existing];
  localStorage.setItem(QUEUE_KEY, JSON.stringify(updated));
  return updated;
}

export function removeQueuedOfflineReport(localId: string): QueuedOfflineReport[] {
  const updated = getQueuedOfflineReports().filter((r) => r.localId !== localId);
  localStorage.setItem(QUEUE_KEY, JSON.stringify(updated));
  return updated;
}

export function saveLastKnownGps(gps: LastKnownGps): void {
  try {
    localStorage.setItem(LAST_GPS_KEY, JSON.stringify(gps));
  } catch {
    // ignore storage quota errors
  }
}

export function getLastKnownGps(): LastKnownGps | null {
  try {
    const raw = localStorage.getItem(LAST_GPS_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function haversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
