import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { EmergencyContact, ExperienceLevel, UserPrivateProfile, UserPublicProfile } from '../types/trailguard';

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  isAdmin: boolean;
  privateProfile: UserPrivateProfile | null;
  publicProfile: UserPublicProfile | null;
  authError: string | null;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfileSettings: (updates: {
    displayName?: string;
    experienceLevel?: ExperienceLevel;
    shareLocationWithGroup?: boolean;
    shareLocationPublicActivity?: boolean;
    emergencyContacts?: EmergencyContact[];
  }) => Promise<void>;
  toggleSavedMountain: (mountainId: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const ADMIN_EMAIL = 'vedd147@gmail.com';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [privateProfile, setPrivateProfile] = useState<UserPrivateProfile | null>(null);
  const [publicProfile, setPublicProfile] = useState<UserPublicProfile | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setUser(fbUser);
      if (!fbUser) {
        setPrivateProfile(null);
        setPublicProfile(null);
        setAuthReady(true);
        return;
      }

      try {
        const privRef = doc(db, 'users', fbUser.uid);
        const pubRef = doc(db, 'public_profiles', fbUser.uid);

        const [privSnap, pubSnap] = await Promise.all([getDoc(privRef), getDoc(pubRef)]);

        const defaultName = (fbUser.displayName || fbUser.email?.split('@')[0] || 'Hiker').slice(0, 80);
        const defaultEmail = (fbUser.email || 'unknown@trailguard.app').slice(0, 200);

        if (!privSnap.exists()) {
          await setDoc(privRef, {
            uid: fbUser.uid,
            email: defaultEmail,
            displayName: defaultName,
            experienceLevel: 'Intermediate',
            shareLocationWithGroup: true,
            shareLocationPublicActivity: false,
            savedMountainIds: 'sinhagad-fort',
            emergencyContactsJson: '[]',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          setPrivateProfile({
            uid: fbUser.uid,
            email: defaultEmail,
            displayName: defaultName,
            experienceLevel: 'Intermediate',
            shareLocationWithGroup: true,
            shareLocationPublicActivity: false,
            savedMountainIds: ['sinhagad-fort'],
            emergencyContacts: [],
          });
        } else {
          const d = privSnap.data();
          let parsedContacts: EmergencyContact[] = [];
          try {
            parsedContacts = d.emergencyContactsJson ? JSON.parse(d.emergencyContactsJson) : [];
          } catch {
            parsedContacts = [];
          }
          setPrivateProfile({
            uid: d.uid,
            email: d.email,
            displayName: d.displayName,
            experienceLevel: d.experienceLevel || 'Intermediate',
            shareLocationWithGroup: Boolean(d.shareLocationWithGroup),
            shareLocationPublicActivity: Boolean(d.shareLocationPublicActivity),
            savedMountainIds: d.savedMountainIds ? String(d.savedMountainIds).split(',').filter(Boolean) : [],
            emergencyContacts: parsedContacts,
          });
        }

        if (!pubSnap.exists()) {
          await setDoc(pubRef, {
            uid: fbUser.uid,
            displayName: defaultName,
            experienceLevel: 'Intermediate',
            totalDistanceKm: 0,
            totalElevationM: 0,
            hikesCompleted: 0,
            photoUrl: (fbUser.photoURL || '').slice(0, 500),
            updatedAt: serverTimestamp(),
          });
          setPublicProfile({
            uid: fbUser.uid,
            displayName: defaultName,
            experienceLevel: 'Intermediate',
            totalDistanceKm: 0,
            totalElevationM: 0,
            hikesCompleted: 0,
            photoUrl: fbUser.photoURL || '',
          });
        } else {
          const p = pubSnap.data();
          setPublicProfile({
            uid: p.uid,
            displayName: p.displayName,
            experienceLevel: p.experienceLevel || 'Intermediate',
            totalDistanceKm: Number(p.totalDistanceKm || 0),
            totalElevationM: Number(p.totalElevationM || 0),
            hikesCompleted: Number(p.hikesCompleted || 0),
            photoUrl: p.photoUrl || '',
          });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `users/${fbUser.uid}`);
      } finally {
        setAuthReady(true);
      }
    });
    return () => unsub();
  }, []);

  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setAuthError(err?.message || 'Unable to sign in with Google.');
    }
  };

  const logout = async () => {
    setAuthError(null);
    await signOut(auth);
  };

  const updateProfileSettings = async (updates: {
    displayName?: string;
    experienceLevel?: ExperienceLevel;
    shareLocationWithGroup?: boolean;
    shareLocationPublicActivity?: boolean;
    emergencyContacts?: EmergencyContact[];
  }) => {
    if (!user || !privateProfile) return;
    const nextName = (updates.displayName ?? privateProfile.displayName).trim().slice(0, 80) || 'Hiker';
    const nextLevel = updates.experienceLevel ?? privateProfile.experienceLevel;
    const nextGroupShare = updates.shareLocationWithGroup ?? privateProfile.shareLocationWithGroup;
    const nextPublicShare = updates.shareLocationPublicActivity ?? privateProfile.shareLocationPublicActivity;
    const nextContacts = updates.emergencyContacts ?? privateProfile.emergencyContacts;

    const privRef = doc(db, 'users', user.uid);
    const pubRef = doc(db, 'public_profiles', user.uid);

    try {
      await updateDoc(privRef, {
        displayName: nextName,
        experienceLevel: nextLevel,
        shareLocationWithGroup: nextGroupShare,
        shareLocationPublicActivity: nextPublicShare,
        emergencyContactsJson: JSON.stringify(nextContacts).slice(0, 2000),
        updatedAt: serverTimestamp(),
      });
      await updateDoc(pubRef, {
        displayName: nextName,
        experienceLevel: nextLevel,
        updatedAt: serverTimestamp(),
      });
      setPrivateProfile({
        ...privateProfile,
        displayName: nextName,
        experienceLevel: nextLevel,
        shareLocationWithGroup: nextGroupShare,
        shareLocationPublicActivity: nextPublicShare,
        emergencyContacts: nextContacts,
      });
      if (publicProfile) {
        setPublicProfile({
          ...publicProfile,
          displayName: nextName,
          experienceLevel: nextLevel,
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const toggleSavedMountain = async (mountainId: string) => {
    if (!user || !privateProfile) return;
    const exists = privateProfile.savedMountainIds.includes(mountainId);
    const nextIds = exists
      ? privateProfile.savedMountainIds.filter((id) => id !== mountainId)
      : [...privateProfile.savedMountainIds, mountainId];
    const privRef = doc(db, 'users', user.uid);
    try {
      await updateDoc(privRef, {
        savedMountainIds: nextIds.join(',').slice(0, 500),
        updatedAt: serverTimestamp(),
      });
      setPrivateProfile({ ...privateProfile, savedMountainIds: nextIds });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const isAdmin = Boolean(user?.email && user.email === ADMIN_EMAIL && user.emailVerified);

  return (
    <AuthContext.Provider
      value={{
        user,
        authReady,
        isAdmin,
        privateProfile,
        publicProfile,
        authError,
        signInWithGoogle,
        logout,
        updateProfileSettings,
        toggleSavedMountain,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
