import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import {
  addDoc,
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, testFirestoreConnection } from '../lib/firebase';
import {
  getLastKnownGps,
  getOfflinePacks,
  getQueuedOfflineReports,
  haversineDistanceKm,
  LastKnownGps,
  OfflineMountainPack,
  QueuedOfflineReport,
  removeOfflineMountainPack,
  removeQueuedOfflineReport,
  saveLastKnownGps,
  saveOfflineMountainPack,
  enqueueOfflineReport,
} from '../lib/offline';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import {
  AdminAuditLog,
  CommunityPost,
  HazardCategory,
  HikingGroup,
  HikingSession,
  ReportSeverity,
  ReportStatus,
  SosAlertRecord,
  TrailConditionColor,
  TrailReport,
  TrailStatusOverride,
  UserPublicProfile,
  WeatherData,
} from '../types/trailguard';
import { useAuth } from './AuthContext';

interface TrailDataContextValue {
  isOnline: boolean;
  firestoreConnected: boolean;
  reports: TrailReport[];
  overrides: TrailStatusOverride[];
  publicSessions: HikingSession[];
  mySessions: HikingSession[];
  communityPosts: CommunityPost[];
  hikingGroups: HikingGroup[];
  publicProfiles: UserPublicProfile[];
  sosAlerts: SosAlertRecord[];
  auditLogs: AdminAuditLog[];
  weatherByMountain: Record<string, WeatherData>;
  weatherLoading: Record<string, boolean>;
  weatherError: Record<string, string | null>;
  fetchWeatherForMountain: (mountainId: string, force?: boolean) => Promise<void>;
  getEffectiveTrailCondition: (mountainId: string, trailId: string, defaultColor: TrailConditionColor) => TrailConditionColor;
  // Live GPS Tracking
  activeSession: HikingSession | null;
  gpsCoordinates: LastKnownGps | null;
  gpsPermissionStatus: 'idle' | 'requesting' | 'active' | 'denied' | 'unavailable';
  gpsError: string | null;
  startHikingSession: (mountainId: string, trailId: string, shareMode: 'private' | 'group' | 'public', groupId?: string) => Promise<void>;
  pauseHikingSession: () => Promise<void>;
  resumeHikingSession: () => Promise<void>;
  endHikingSession: () => Promise<void>;
  requestSingleGpsFix: () => Promise<LastKnownGps | null>;
  // Mutations
  submitTrailReport: (input: {
    mountainId: string;
    trailId: string;
    category: HazardCategory | string;
    severity: ReportSeverity;
    description: string;
    lat: number;
    lng: number;
    aiClassification?: string;
  }) => Promise<{ queuedOffline: boolean }>;
  confirmTrailReport: (reportId: string, currentCount: number, currentStatus: ReportStatus) => Promise<void>;
  createCommunityPost: (input: {
    mountainId: string;
    trailId: string;
    title: string;
    body: string;
    rating: number;
  }) => Promise<void>;
  likeCommunityPost: (postId: string, currentLikes: number) => Promise<void>;
  flagCommunityPost: (postId: string) => Promise<void>;
  createHikingGroup: (input: { name: string; mountainId: string; plannedDate: string }) => Promise<string>;
  triggerSosAlert: (input: { mountainId: string; lat: number; lng: number; message: string }) => Promise<any>;
  // Admin actions
  adminUpdateReportStatus: (reportId: string, status: ReportStatus) => Promise<void>;
  adminSetTrailOverride: (mountainId: string, trailId: string, condition: TrailConditionColor, reason: string) => Promise<void>;
  adminResolveCommunityFlag: (postId: string, flagged: boolean) => Promise<void>;
  adminUpdateSosStatus: (alertId: string, status: 'active' | 'acknowledged' | 'resolved') => Promise<void>;
  // Offline packs
  offlinePacks: OfflineMountainPack[];
  queuedOfflineReports: QueuedOfflineReport[];
  downloadMountainOffline: (mountainId: string) => void;
  deleteMountainOffline: (mountainId: string) => void;
  syncQueuedOfflineReports: () => Promise<number>;
}

const TrailDataContext = createContext<TrailDataContextValue | null>(null);

function tsToIso(val: any): string {
  if (val && typeof val.toDate === 'function') {
    return val.toDate().toISOString();
  }
  if (typeof val === 'string') return val;
  return new Date().toISOString();
}

export function TrailDataProvider({ children }: { children: React.ReactNode }) {
  const { user, isAdmin, privateProfile, publicProfile } = useAuth();
  const [isOnline, setIsOnline] = useState<boolean>(() => (typeof navigator !== 'undefined' ? navigator.onLine : true));
  const [firestoreConnected, setFirestoreConnected] = useState(true);

  const [reports, setReports] = useState<TrailReport[]>([]);
  const [overrides, setOverrides] = useState<TrailStatusOverride[]>([]);
  const [publicSessions, setPublicSessions] = useState<HikingSession[]>([]);
  const [mySessions, setMySessions] = useState<HikingSession[]>([]);
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>([]);
  const [hikingGroups, setHikingGroups] = useState<HikingGroup[]>([]);
  const [publicProfiles, setPublicProfiles] = useState<UserPublicProfile[]>([]);
  const [sosAlerts, setSosAlerts] = useState<SosAlertRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);

  const [weatherByMountain, setWeatherByMountain] = useState<Record<string, WeatherData>>({});
  const [weatherLoading, setWeatherLoading] = useState<Record<string, boolean>>({});
  const [weatherError, setWeatherError] = useState<Record<string, string | null>>({});

  const [gpsCoordinates, setGpsCoordinates] = useState<LastKnownGps | null>(() => getLastKnownGps());
  const [gpsPermissionStatus, setGpsPermissionStatus] = useState<'idle' | 'requesting' | 'active' | 'denied' | 'unavailable'>('idle');
  const [gpsError, setGpsError] = useState<string | null>(null);

  const [offlinePacks, setOfflinePacks] = useState<OfflineMountainPack[]>(() => getOfflinePacks());
  const [queuedOfflineReports, setQueuedOfflineReports] = useState<QueuedOfflineReport[]>(() => getQueuedOfflineReports());

  const watchIdRef = useRef<number | null>(null);
  const timerIdRef = useRef<number | null>(null);
  const lastTrackPointRef = useRef<{ lat: number; lng: number } | null>(null);
  const activeSessionRef = useRef<HikingSession | null>(null);

  const activeSession = mySessions.find((s) => s.status === 'active' || s.status === 'paused') || null;
  activeSessionRef.current = activeSession;

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    testFirestoreConnection().then(setFirestoreConnected);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Public Firestore listeners
  useEffect(() => {
    const unsubReports = onSnapshot(
      query(collection(db, 'trail_reports'), orderBy('createdAt', 'desc'), limit(100)),
      (snap) => {
        setReports(
          snap.docs.map((d) => {
            const x = d.data();
            return {
              id: d.id,
              mountainId: x.mountainId,
              trailId: x.trailId,
              category: x.category,
              severity: x.severity,
              status: x.status,
              description: x.description,
              lat: Number(x.lat),
              lng: Number(x.lng),
              reporterUid: x.reporterUid,
              reporterName: x.reporterName,
              confirmCount: Number(x.confirmCount || 1),
              aiClassification: x.aiClassification,
              createdAtIso: tsToIso(x.createdAt),
              updatedAtIso: tsToIso(x.updatedAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'trail_reports')
    );

    const unsubOverrides = onSnapshot(
      collection(db, 'trail_overrides'),
      (snap) => {
        setOverrides(
          snap.docs.map((d) => {
            const x = d.data();
            return {
              id: d.id,
              mountainId: x.mountainId,
              trailId: x.trailId,
              condition: x.condition,
              reason: x.reason,
              updatedBy: x.updatedBy,
              updatedAtIso: tsToIso(x.updatedAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'trail_overrides')
    );

    const unsubPublicSessions = onSnapshot(
      query(collection(db, 'hiking_sessions'), where('shareMode', '==', 'public'), limit(100)),
      (snap) => {
        const now = Date.now();
        setPublicSessions(
          snap.docs
            .map((d) => {
              const x = d.data();
              return {
                id: d.id,
                uid: x.uid,
                displayName: x.displayName,
                mountainId: x.mountainId,
                trailId: x.trailId,
                status: x.status,
                shareMode: x.shareMode,
                groupId: x.groupId,
                currentLat: Number(x.currentLat),
                currentLng: Number(x.currentLng),
                distanceTravelledKm: Number(x.distanceTravelledKm || 0),
                elevationGainedM: Number(x.elevationGainedM || 0),
                durationSec: Number(x.durationSec || 0),
                startedAtIso: tsToIso(x.startedAt),
                updatedAtIso: tsToIso(x.updatedAt),
                expiresAtMs: Number(x.expiresAtMs || 0),
              } as HikingSession;
            })
            .filter((s) => s.expiresAtMs > now && (s.status === 'active' || s.status === 'paused'))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'hiking_sessions')
    );

    const unsubPosts = onSnapshot(
      query(collection(db, 'community_posts'), orderBy('createdAt', 'desc'), limit(60)),
      (snap) => {
        setCommunityPosts(
          snap.docs.map((d) => {
            const x = d.data();
            return {
              id: d.id,
              uid: x.uid,
              authorName: x.authorName,
              mountainId: x.mountainId,
              trailId: x.trailId,
              title: x.title,
              body: x.body,
              rating: Number(x.rating || 5),
              likesCount: Number(x.likesCount || 0),
              flagged: Boolean(x.flagged),
              createdAtIso: tsToIso(x.createdAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'community_posts')
    );

    const unsubGroups = onSnapshot(
      query(collection(db, 'hiking_groups'), orderBy('createdAt', 'desc'), limit(40)),
      (snap) => {
        setHikingGroups(
          snap.docs.map((d) => {
            const x = d.data();
            return {
              id: d.id,
              name: x.name,
              mountainId: x.mountainId,
              leaderUid: x.leaderUid,
              leaderName: x.leaderName,
              inviteCode: x.inviteCode,
              plannedDate: x.plannedDate,
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'hiking_groups')
    );

    const unsubProfiles = onSnapshot(
      query(collection(db, 'public_profiles'), limit(50)),
      (snap) => {
        setPublicProfiles(
          snap.docs.map((d) => {
            const x = d.data();
            return {
              uid: x.uid,
              displayName: x.displayName,
              experienceLevel: x.experienceLevel || 'Intermediate',
              totalDistanceKm: Number(x.totalDistanceKm || 0),
              totalElevationM: Number(x.totalElevationM || 0),
              hikesCompleted: Number(x.hikesCompleted || 0),
              photoUrl: x.photoUrl || '',
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'public_profiles')
    );

    return () => {
      unsubReports();
      unsubOverrides();
      unsubPublicSessions();
      unsubPosts();
      unsubGroups();
      unsubProfiles();
    };
  }, []);

  // User-specific & Admin listeners
  useEffect(() => {
    if (!user) {
      setMySessions([]);
      setSosAlerts([]);
      setAuditLogs([]);
      return;
    }

    const unsubMySessions = onSnapshot(
      query(collection(db, 'hiking_sessions'), where('uid', '==', user.uid), limit(50)),
      (snap) => {
        const list = snap.docs.map((d) => {
          const x = d.data();
          return {
            id: d.id,
            uid: x.uid,
            displayName: x.displayName,
            mountainId: x.mountainId,
            trailId: x.trailId,
            status: x.status,
            shareMode: x.shareMode,
            groupId: x.groupId,
            currentLat: Number(x.currentLat),
            currentLng: Number(x.currentLng),
            distanceTravelledKm: Number(x.distanceTravelledKm || 0),
            elevationGainedM: Number(x.elevationGainedM || 0),
            durationSec: Number(x.durationSec || 0),
            startedAtIso: tsToIso(x.startedAt),
            updatedAtIso: tsToIso(x.updatedAt),
            expiresAtMs: Number(x.expiresAtMs || 0),
          } as HikingSession;
        });
        list.sort((a, b) => b.startedAtIso.localeCompare(a.startedAtIso));
        setMySessions(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'hiking_sessions')
    );

    const sosQ = isAdmin
      ? query(collection(db, 'sos_alerts'), orderBy('createdAt', 'desc'), limit(50))
      : query(collection(db, 'sos_alerts'), where('uid', '==', user.uid), limit(20));

    const unsubSos = onSnapshot(
      sosQ,
      (snap) => {
        setSosAlerts(
          snap.docs.map((d) => {
            const x = d.data();
            return {
              id: d.id,
              uid: x.uid,
              displayName: x.displayName,
              mountainId: x.mountainId,
              lat: Number(x.lat),
              lng: Number(x.lng),
              message: x.message,
              status: x.status,
              createdAtIso: tsToIso(x.createdAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'sos_alerts')
    );

    let unsubAudit = () => {};
    if (isAdmin) {
      unsubAudit = onSnapshot(
        query(collection(db, 'admin_audit_logs'), orderBy('createdAt', 'desc'), limit(60)),
        (snap) => {
          setAuditLogs(
            snap.docs.map((d) => {
              const x = d.data();
              return {
                id: d.id,
                adminUid: x.adminUid,
                adminEmail: x.adminEmail,
                action: x.action,
                targetPath: x.targetPath,
                details: x.details,
                createdAtIso: tsToIso(x.createdAt),
              };
            })
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'admin_audit_logs')
      );
    }

    return () => {
      unsubMySessions();
      unsubSos();
      unsubAudit();
    };
  }, [user, isAdmin]);

  const fetchWeatherForMountain = useCallback(
    async (mountainId: string, force = false) => {
      const m = getMountainById(mountainId);
      if (!force && weatherByMountain[mountainId]) return;
      setWeatherLoading((prev) => ({ ...prev, [mountainId]: true }));
      setWeatherError((prev) => ({ ...prev, [mountainId]: null }));
      try {
        const res = await fetch(
          `/api/weather?lat=${m.lat}&lon=${m.lng}&elevation=${m.elevationM}&name=${encodeURIComponent(m.name)}`
        );
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Weather service unavailable');
        }
        setWeatherByMountain((prev) => ({ ...prev, [mountainId]: data }));
      } catch (err: any) {
        setWeatherError((prev) => ({
          ...prev,
          [mountainId]: err?.message || 'Unable to load live Open-Meteo conditions.',
        }));
      } finally {
        setWeatherLoading((prev) => ({ ...prev, [mountainId]: false }));
      }
    },
    [weatherByMountain]
  );

  // Pre-fetch weather for primary Sahyadri mountains on load
  useEffect(() => {
    fetchWeatherForMountain('sinhagad-fort');
  }, [fetchWeatherForMountain]);

  const getEffectiveTrailCondition = useCallback(
    (mountainId: string, trailId: string, defaultColor: TrailConditionColor): TrailConditionColor => {
      const ov = overrides.find((o) => o.mountainId === mountainId && o.trailId === trailId);
      if (ov) return ov.condition;

      const activeReports = reports.filter(
        (r) =>
          r.mountainId === mountainId &&
          r.trailId === trailId &&
          r.status !== 'Resolved' &&
          r.status !== 'Expired'
      );
      if (activeReports.some((r) => r.severity === 'Critical' || (r.severity === 'High' && r.status === 'Confirmed'))) {
        return 'RED';
      }
      if (activeReports.length > 0) {
        return defaultColor === 'RED' ? 'RED' : 'YELLOW';
      }
      return defaultColor;
    },
    [overrides, reports]
  );

  // Geolocation helpers
  const requestSingleGpsFix = useCallback(async (): Promise<LastKnownGps | null> => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setGpsPermissionStatus('unavailable');
      setGpsError('Browser geolocation is unavailable on this device.');
      return null;
    }
    setGpsPermissionStatus('requesting');
    setGpsError(null);
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const fix: LastKnownGps = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracyM: Math.round(pos.coords.accuracy),
            timestampIso: new Date().toISOString(),
          };
          saveLastKnownGps(fix);
          setGpsCoordinates(fix);
          setGpsPermissionStatus('active');
          resolve(fix);
        },
        (err) => {
          setGpsPermissionStatus(err.code === 1 ? 'denied' : 'unavailable');
          setGpsError(err.message || 'Location permission was declined.');
          resolve(null);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 15000 }
      );
    });
  }, []);

  // Watch GPS & duration while an active hiking session is running
  useEffect(() => {
    if (!activeSession || activeSession.status !== 'active' || !user) {
      if (watchIdRef.current !== null && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (timerIdRef.current !== null) {
        window.clearInterval(timerIdRef.current);
        timerIdRef.current = null;
      }
      return;
    }

    if ('geolocation' in navigator) {
      setGpsPermissionStatus('requesting');
      watchIdRef.current = navigator.geolocation.watchPosition(
        async (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const fix: LastKnownGps = {
            lat,
            lng,
            accuracyM: Math.round(pos.coords.accuracy),
            timestampIso: new Date().toISOString(),
          };
          saveLastKnownGps(fix);
          setGpsCoordinates(fix);
          setGpsPermissionStatus('active');
          setGpsError(null);

          const cur = activeSessionRef.current;
          if (!cur || cur.status !== 'active') return;
          let addedDist = 0;
          if (lastTrackPointRef.current) {
            const d = haversineDistanceKm(lastTrackPointRef.current.lat, lastTrackPointRef.current.lng, lat, lng);
            if (d > 0.005 && d < 2) addedDist = d;
          }
          lastTrackPointRef.current = { lat, lng };

          try {
            await updateDoc(doc(db, 'hiking_sessions', cur.id), {
              currentLat: lat,
              currentLng: lng,
              distanceTravelledKm: Number((cur.distanceTravelledKm + addedDist).toFixed(3)),
              elevationGainedM: Number((cur.elevationGainedM + addedDist * 110).toFixed(0)),
              updatedAt: serverTimestamp(),
              expiresAtMs: Date.now() + 2 * 60 * 60 * 1000,
            });
          } catch (e) {
            console.error('GPS session sync error:', e);
          }
        },
        (err) => {
          setGpsPermissionStatus(err.code === 1 ? 'denied' : 'unavailable');
          setGpsError(err.message || 'GPS signal paused.');
        },
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
      );
    }

    timerIdRef.current = window.setInterval(async () => {
      const cur = activeSessionRef.current;
      if (!cur || cur.status !== 'active') return;
      if (Date.now() > cur.expiresAtMs) {
        await updateDoc(doc(db, 'hiking_sessions', cur.id), {
          status: 'expired',
          updatedAt: serverTimestamp(),
        }).catch(() => {});
        return;
      }
      try {
        await updateDoc(doc(db, 'hiking_sessions', cur.id), {
          durationSec: Math.floor(cur.durationSec + 10),
          updatedAt: serverTimestamp(),
        });
      } catch {
        // non-fatal ticker update
      }
    }, 10000);

    return () => {
      if (watchIdRef.current !== null && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (timerIdRef.current !== null) {
        window.clearInterval(timerIdRef.current);
        timerIdRef.current = null;
      }
    };
  }, [activeSession?.id, activeSession?.status, user]);

  const startHikingSession = async (
    mountainId: string,
    trailId: string,
    shareMode: 'private' | 'group' | 'public',
    groupId?: string
  ) => {
    if (!user) throw new Error('Please sign in with Google to start live GPS session tracking.');
    const m = getMountainById(mountainId);
    const trail = m.trails.find((t) => t.id === trailId) || m.trails[0];
    const fix = await requestSingleGpsFix();
    const startLat = fix?.lat ?? trail.coordinates[0][0];
    const startLng = fix?.lng ?? trail.coordinates[0][1];
    lastTrackPointRef.current = { lat: startLat, lng: startLng };

    const payload: any = {
      uid: user.uid,
      displayName: (privateProfile?.displayName || user.displayName || 'Hiker').slice(0, 80),
      mountainId,
      trailId,
      status: 'active',
      shareMode,
      currentLat: startLat,
      currentLng: startLng,
      distanceTravelledKm: 0,
      elevationGainedM: 0,
      durationSec: 0,
      startedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      expiresAtMs: Date.now() + 2 * 60 * 60 * 1000,
    };
    if (groupId) payload.groupId = groupId;

    try {
      await addDoc(collection(db, 'hiking_sessions'), payload);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'hiking_sessions');
    }
  };

  const pauseHikingSession = async () => {
    if (!activeSession) return;
    try {
      await updateDoc(doc(db, 'hiking_sessions', activeSession.id), {
        status: 'paused',
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `hiking_sessions/${activeSession.id}`);
    }
  };

  const resumeHikingSession = async () => {
    if (!activeSession) return;
    try {
      await updateDoc(doc(db, 'hiking_sessions', activeSession.id), {
        status: 'active',
        updatedAt: serverTimestamp(),
        expiresAtMs: Date.now() + 2 * 60 * 60 * 1000,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `hiking_sessions/${activeSession.id}`);
    }
  };

  const endHikingSession = async () => {
    if (!activeSession || !user) return;
    try {
      await updateDoc(doc(db, 'hiking_sessions', activeSession.id), {
        status: 'completed',
        updatedAt: serverTimestamp(),
      });
      if (publicProfile) {
        await updateDoc(doc(db, 'public_profiles', user.uid), {
          totalDistanceKm: Number((publicProfile.totalDistanceKm + activeSession.distanceTravelledKm).toFixed(2)),
          totalElevationM: Math.round(publicProfile.totalElevationM + activeSession.elevationGainedM),
          hikesCompleted: Math.round(publicProfile.hikesCompleted + 1),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `hiking_sessions/${activeSession.id}`);
    }
  };

  const submitTrailReport = async (input: {
    mountainId: string;
    trailId: string;
    category: HazardCategory | string;
    severity: ReportSeverity;
    description: string;
    lat: number;
    lng: number;
    aiClassification?: string;
  }): Promise<{ queuedOffline: boolean }> => {
    if (!isOnline) {
      const updated = enqueueOfflineReport(input);
      setQueuedOfflineReports(updated);
      return { queuedOffline: true };
    }
    if (!user) throw new Error('Please sign in with Google to submit a verified trail report.');

    const payload: any = {
      mountainId: input.mountainId,
      trailId: input.trailId,
      category: input.category,
      severity: input.severity,
      status: 'Newly reported',
      description: input.description.trim().slice(0, 1200),
      lat: Number(input.lat),
      lng: Number(input.lng),
      reporterUid: user.uid,
      reporterName: (privateProfile?.displayName || user.displayName || 'Hiker').slice(0, 80),
      confirmCount: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (input.aiClassification) {
      payload.aiClassification = input.aiClassification.slice(0, 120);
    }

    try {
      await addDoc(collection(db, 'trail_reports'), payload);
      return { queuedOffline: false };
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'trail_reports');
    }
  };

  const confirmTrailReport = async (reportId: string, currentCount: number, currentStatus: ReportStatus) => {
    if (!user) throw new Error('Sign in with Google to confirm hazard reports.');
    const nextCount = currentCount + 1;
    const nextStatus: ReportStatus = nextCount >= 2 ? 'Confirmed' : currentStatus === 'Newly reported' ? 'Under verification' : currentStatus;
    try {
      await updateDoc(doc(db, 'trail_reports', reportId), {
        confirmCount: nextCount,
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trail_reports/${reportId}`);
    }
  };

  const createCommunityPost = async (input: {
    mountainId: string;
    trailId: string;
    title: string;
    body: string;
    rating: number;
  }) => {
    if (!user) throw new Error('Sign in with Google to publish a trail experience.');
    try {
      await addDoc(collection(db, 'community_posts'), {
        uid: user.uid,
        authorName: (privateProfile?.displayName || user.displayName || 'Hiker').slice(0, 80),
        mountainId: input.mountainId,
        trailId: input.trailId,
        title: input.title.trim().slice(0, 120),
        body: input.body.trim().slice(0, 2000),
        rating: Math.max(1, Math.min(5, Math.round(input.rating))),
        likesCount: 0,
        flagged: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'community_posts');
    }
  };

  const likeCommunityPost = async (postId: string, currentLikes: number) => {
    if (!user) throw new Error('Sign in with Google to upvote trail experiences.');
    try {
      await updateDoc(doc(db, 'community_posts', postId), {
        likesCount: currentLikes + 1,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `community_posts/${postId}`);
    }
  };

  const flagCommunityPost = async (postId: string) => {
    if (!user) throw new Error('Sign in with Google to report inappropriate posts.');
    try {
      await updateDoc(doc(db, 'community_posts', postId), {
        flagged: true,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `community_posts/${postId}`);
    }
  };

  const createHikingGroup = async (input: { name: string; mountainId: string; plannedDate: string }): Promise<string> => {
    if (!user) throw new Error('Sign in with Google to create a hiking group.');
    const inviteCode = `TG-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    try {
      await addDoc(collection(db, 'hiking_groups'), {
        name: input.name.trim().slice(0, 80),
        mountainId: input.mountainId,
        leaderUid: user.uid,
        leaderName: (privateProfile?.displayName || user.displayName || 'Leader').slice(0, 80),
        inviteCode,
        plannedDate: input.plannedDate.slice(0, 32),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return inviteCode;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'hiking_groups');
    }
  };

  const triggerSosAlert = async (input: { mountainId: string; lat: number; lng: number; message: string }) => {
    const displayName = privateProfile?.displayName || user?.displayName || 'Hiker';
    const mountainName = getMountainById(input.mountainId).name;

    const serverRes = await fetch('/api/sos/dispatch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        displayName,
        mountainName,
        lat: input.lat,
        lng: input.lng,
        message: input.message,
        emergencyContacts: privateProfile?.emergencyContacts || [],
      }),
    });
    const dispatchData = await serverRes.json();
    if (!serverRes.ok) throw new Error(dispatchData.error || 'SOS dispatch failed');

    if (user) {
      try {
        await addDoc(collection(db, 'sos_alerts'), {
          uid: user.uid,
          displayName: displayName.slice(0, 80),
          mountainId: input.mountainId,
          lat: Number(input.lat),
          lng: Number(input.lng),
          message: input.message.slice(0, 500),
          status: 'active',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, 'sos_alerts');
      }
    }

    return dispatchData;
  };

  const writeAuditLog = async (action: string, targetPath: string, details: string) => {
    if (!user || !isAdmin) return;
    await addDoc(collection(db, 'admin_audit_logs'), {
      adminUid: user.uid,
      adminEmail: (user.email || '').slice(0, 200),
      action: action.slice(0, 100),
      targetPath: targetPath.slice(0, 200),
      details: details.slice(0, 500),
      createdAt: serverTimestamp(),
    });
  };

  const adminUpdateReportStatus = async (reportId: string, status: ReportStatus) => {
    if (!isAdmin) throw new Error('Administrator authorization required.');
    try {
      await updateDoc(doc(db, 'trail_reports', reportId), {
        status,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('UPDATE_REPORT_STATUS', `trail_reports/${reportId}`, `Set status to ${status}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trail_reports/${reportId}`);
    }
  };

  const adminSetTrailOverride = async (
    mountainId: string,
    trailId: string,
    condition: TrailConditionColor,
    reason: string
  ) => {
    if (!isAdmin || !user) throw new Error('Administrator authorization required.');
    const overrideId = `${mountainId}__${trailId}`;
    try {
      await setDoc(doc(db, 'trail_overrides', overrideId), {
        mountainId,
        trailId,
        condition,
        reason: reason.slice(0, 300),
        updatedBy: user.email || user.uid,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('SET_TRAIL_OVERRIDE', `trail_overrides/${overrideId}`, `Condition ${condition}: ${reason}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `trail_overrides/${overrideId}`);
    }
  };

  const adminResolveCommunityFlag = async (postId: string, flagged: boolean) => {
    if (!isAdmin) throw new Error('Administrator authorization required.');
    try {
      await updateDoc(doc(db, 'community_posts', postId), {
        flagged,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('MODERATE_POST', `community_posts/${postId}`, `Set flagged=${flagged}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `community_posts/${postId}`);
    }
  };

  const adminUpdateSosStatus = async (alertId: string, status: 'active' | 'acknowledged' | 'resolved') => {
    if (!isAdmin) throw new Error('Administrator authorization required.');
    try {
      await updateDoc(doc(db, 'sos_alerts', alertId), {
        status,
        updatedAt: serverTimestamp(),
      });
      await writeAuditLog('UPDATE_SOS_STATUS', `sos_alerts/${alertId}`, `Set SOS status to ${status}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `sos_alerts/${alertId}`);
    }
  };

  const downloadMountainOffline = (mountainId: string) => {
    const m = getMountainById(mountainId);
    setOfflinePacks(saveOfflineMountainPack(m, reports));
  };

  const deleteMountainOffline = (mountainId: string) => {
    setOfflinePacks(removeOfflineMountainPack(mountainId));
  };

  const syncQueuedOfflineReports = async (): Promise<number> => {
    if (!isOnline || !user) return 0;
    let synced = 0;
    for (const q of queuedOfflineReports) {
      await submitTrailReport({
        mountainId: q.mountainId,
        trailId: q.trailId,
        category: q.category,
        severity: q.severity,
        description: q.description,
        lat: q.lat,
        lng: q.lng,
      });
      setQueuedOfflineReports(removeQueuedOfflineReport(q.localId));
      synced++;
    }
    return synced;
  };

  return (
    <TrailDataContext.Provider
      value={{
        isOnline,
        firestoreConnected,
        reports,
        overrides,
        publicSessions,
        mySessions,
        communityPosts,
        hikingGroups,
        publicProfiles,
        sosAlerts,
        auditLogs,
        weatherByMountain,
        weatherLoading,
        weatherError,
        fetchWeatherForMountain,
        getEffectiveTrailCondition,
        activeSession,
        gpsCoordinates,
        gpsPermissionStatus,
        gpsError,
        startHikingSession,
        pauseHikingSession,
        resumeHikingSession,
        endHikingSession,
        requestSingleGpsFix,
        submitTrailReport,
        confirmTrailReport,
        createCommunityPost,
        likeCommunityPost,
        flagCommunityPost,
        createHikingGroup,
        triggerSosAlert,
        adminUpdateReportStatus,
        adminSetTrailOverride,
        adminResolveCommunityFlag,
        adminUpdateSosStatus,
        offlinePacks,
        queuedOfflineReports,
        downloadMountainOffline,
        deleteMountainOffline,
        syncQueuedOfflineReports,
      }}
    >
      {children}
    </TrailDataContext.Provider>
  );
}

export function useTrailData(): TrailDataContextValue {
  const ctx = useContext(TrailDataContext);
  if (!ctx) throw new Error('useTrailData must be used inside TrailDataProvider');
  return ctx;
}
