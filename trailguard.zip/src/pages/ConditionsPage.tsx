import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Cloud,
  CloudRain,
  Compass,
  Droplets,
  Eye,
  RefreshCw,
  Sun,
  Sunrise,
  Sunset,
  Thermometer,
  Users,
  Wind,
} from 'lucide-react';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { PageRoute } from '../types/trailguard';

interface ConditionsPageProps {
  initialMountainId: string;
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

export function ConditionsPage({ initialMountainId, onNavigate }: ConditionsPageProps) {
  const {
    weatherByMountain,
    weatherLoading,
    weatherError,
    fetchWeatherForMountain,
    publicSessions,
    reports,
  } = useTrailData();

  const [selectedId, setSelectedId] = useState(initialMountainId || MOUNTAINS[0].id);
  const mountain = getMountainById(selectedId);

  useEffect(() => {
    fetchWeatherForMountain(mountain.id);
  }, [mountain.id, fetchWeatherForMountain]);

  const weather = weatherByMountain[mountain.id];
  const loading = weatherLoading[mountain.id];
  const error = weatherError[mountain.id];

  const liveSessionsHere = publicSessions.filter((s) => s.mountainId === mountain.id);
  const trailActivityBreakdown = mountain.trails.map((trail) => {
    const count = liveSessionsHere.filter((s) => s.trailId === trail.id).length;
    const label = count >= 10 ? 'High activity' : count >= 3 ? 'Moderate activity' : count >= 1 ? 'Low live activity' : 'No shared GPS sessions';
    return { trail, count, label };
  });

  const activeMountainReports = reports.filter(
    (r) => r.mountainId === mountain.id && r.status !== 'Resolved' && r.status !== 'Expired'
  );

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header & Mountain Switcher */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Live Conditions & Crowd Intelligence</h1>
          <p className="text-sm text-gray-400 mt-1.5">
            Real-time Open-Meteo mountain weather combined with voluntary live hiker session telemetry.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {MOUNTAINS.map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedId(m.id)}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                selectedId === m.id
                  ? 'bg-emerald-600 border-emerald-500 text-white'
                  : 'bg-[#131917] border-white/10 text-gray-300 hover:text-white'
              }`}
            >
              {m.name}
            </button>
          ))}
        </div>
      </div>

      {/* Weather Dashboard */}
      <section className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-2xl font-semibold text-white">{mountain.name} Weather Telemetry</h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Coordinates: {mountain.lat.toFixed(4)}, {mountain.lng.toFixed(4)} · Summit {mountain.elevationM} m
            </p>
          </div>
          <button
            onClick={() => fetchWeatherForMountain(mountain.id, true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#131917] hover:bg-white/5 border border-white/15 rounded-lg text-xs text-gray-200 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh Open-Meteo
          </button>
        </div>

        {loading && !weather && (
          <div className="bg-[#131917] border border-white/10 rounded-xl p-10 text-sm text-gray-400">
            Fetching live meteorological telemetry from Open-Meteo API...
          </div>
        )}

        {error && (
          <div className="bg-red-950/50 border border-red-500/30 rounded-xl p-6 text-sm text-red-200">
            {error}
          </div>
        )}

        {weather && (
          <div className="space-y-6">
            {/* IS IT A GOOD TIME TO HIKE? */}
            <div className="bg-[#131917] border border-white/10 rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="text-xs font-semibold text-emerald-400">IS IT A GOOD TIME TO HIKE?</div>
                <div className="text-2xl font-display font-bold text-white">{weather.goodTimeToHike.verdict}</div>
                <p className="text-sm text-gray-300">{weather.goodTimeToHike.rationale}</p>
                <p className="text-xs text-gray-500">
                  Source: {weather.source} · Fetched {new Date(weather.fetchedAt).toLocaleString()} · {weather.uncertaintyNote}
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-2.5 shrink-0">
                <button
                  onClick={() => onNavigate('ai-risk', mountain.id)}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Open AI Risk Analysis
                </button>
                <button
                  onClick={() => onNavigate('map', mountain.id)}
                  className="px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/15 text-white text-xs font-medium rounded-lg cursor-pointer"
                >
                  Open Live Map
                </button>
              </div>
            </div>

            {/* Weather Warnings if any */}
            {weather.warnings.length > 0 && (
              <div className="bg-amber-950/40 border border-amber-500/35 rounded-xl p-5 space-y-2">
                <div className="text-sm font-semibold text-amber-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Active Weather & Visibility Alerts
                </div>
                <ul className="space-y-1 text-xs text-amber-100">
                  {weather.warnings.map((w, idx) => (
                    <li key={idx}>· {w}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* All Requested Weather Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Thermometer className="w-3.5 h-3.5" /> Temperature</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.temperatureC.toFixed(1)}°C
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400">Feels Like</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.feelsLikeC.toFixed(1)}°C
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><CloudRain className="w-3.5 h-3.5" /> Rain Prob</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.rainProbabilityPct}%
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400">Rainfall</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.rainfallMm.toFixed(1)} mm
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Wind className="w-3.5 h-3.5" /> Wind Speed</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.windSpeedKmh.toFixed(0)} km/h
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Compass className="w-3.5 h-3.5" /> Wind Direction</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.windCardinal} ({weather.current.windDirectionDeg}°)
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Droplets className="w-3.5 h-3.5" /> Humidity</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.humidityPct}%
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" /> Visibility</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.visibilityKm} km
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Cloud className="w-3.5 h-3.5" /> Cloud Cover</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1.5">
                  {weather.current.cloudCoverPct}%
                </div>
              </div>
              <div className="bg-[#131917] border border-white/10 rounded-xl p-4">
                <div className="text-xs text-gray-400 flex items-center gap-1.5"><Sun className="w-3.5 h-3.5" /> Daylight</div>
                <div className="text-xs font-mono tabular-nums text-white mt-2 space-y-0.5">
                  <div className="flex items-center gap-1"><Sunrise className="w-3 h-3 text-amber-400" /> {weather.current.sunrise ? weather.current.sunrise.slice(11, 16) : '--'}</div>
                  <div className="flex items-center gap-1"><Sunset className="w-3 h-3 text-orange-400" /> {weather.current.sunset ? weather.current.sunset.slice(11, 16) : '--'}</div>
                </div>
              </div>
            </div>

            {/* Next 8 Hours Table */}
            <div className="bg-[#131917] border border-white/10 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-semibold text-white">Next 8-Hour Ridge Forecast</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="border-b border-white/10 text-gray-400">
                    <tr>
                      <th className="py-2 pr-4">Hour</th>
                      <th className="py-2 px-3 text-right">Temp</th>
                      <th className="py-2 px-3 text-right">Rain Prob</th>
                      <th className="py-2 px-3 text-right">Wind</th>
                      <th className="py-2 pl-3 text-right">Visibility</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 font-mono tabular-nums">
                    {weather.hourlyPreview.map((h) => (
                      <tr key={h.time}>
                        <td className="py-2 pr-4 text-gray-300">{h.time.slice(11, 16)}</td>
                        <td className="py-2 px-3 text-right text-white">{h.tempC.toFixed(1)}°C</td>
                        <td className="py-2 px-3 text-right text-sky-300">{h.rainProb}%</td>
                        <td className="py-2 px-3 text-right text-gray-200">{h.windKmh.toFixed(0)} km/h</td>
                        <td className="py-2 pl-3 text-right text-gray-300">{(h.visibilityM / 1000).toFixed(1)} km</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Live Mountain Crowd Intelligence */}
      <section className="space-y-5 pt-4 border-t border-white/10">
        <div>
          <h2 className="font-display text-2xl font-semibold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" /> Live Mountain Crowd Intelligence
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Distinguishes real active voluntary GPS sessions from historical daily reference ranges. No simulated live hiker counts are displayed.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
            <div className="text-xs text-gray-400">Verified Live GPS Sessions</div>
            <div className="text-3xl font-mono tabular-nums font-bold text-white mt-1.5">{liveSessionsHere.length}</div>
            <div className="text-[11px] text-emerald-400 mt-1">Currently active & shared on {mountain.name}</div>
          </div>
          <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
            <div className="text-xs text-gray-400">Historical Daily Reference</div>
            <div className="text-lg font-mono tabular-nums font-semibold text-white mt-2">
              {mountain.baselineDailyVisitorsRange}
            </div>
            <div className="text-[11px] text-gray-400 mt-1">Seasonal reference range (not live sensor count)</div>
          </div>
          <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
            <div className="text-xs text-gray-400">Typical Peak Window</div>
            <div className="text-lg font-mono tabular-nums font-semibold text-white mt-2">{mountain.peakHoursLabel}</div>
            <div className="text-[11px] text-gray-400 mt-1">Arrive earlier for calmer ascent</div>
          </div>
          <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
            <div className="text-xs text-gray-400">Active Hazard Advisories</div>
            <div className="text-3xl font-mono tabular-nums font-bold text-amber-400 mt-1.5">
              {activeMountainReports.length}
            </div>
            <div className="text-[11px] text-gray-400 mt-1">Unresolved reports on this peak</div>
          </div>
        </div>

        <div className="bg-[#131917] border border-white/10 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-white">Trail-wise Live GPS Activity</h3>
          <div className="divide-y divide-white/10">
            {trailActivityBreakdown.map(({ trail, count, label }) => (
              <div key={trail.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-sm">
                <div>
                  <span className="font-medium text-white">{trail.name}</span>
                  <span className="text-xs text-gray-500 ml-2">{trail.routeTag} · {trail.distanceKm} km</span>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <span className="text-gray-300">{label}</span>
                  <span className="font-mono tabular-nums text-emerald-400">{count} active</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
