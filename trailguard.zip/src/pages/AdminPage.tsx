import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';
import { ReportStatus, TrailConditionColor } from '../types/trailguard';

export function AdminPage() {
  const { user, isAdmin, signInWithGoogle } = useAuth();
  const {
    reports,
    communityPosts,
    sosAlerts,
    auditLogs,
    adminUpdateReportStatus,
    adminSetTrailOverride,
    adminResolveCommunityFlag,
    adminUpdateSosStatus,
  } = useTrailData();

  const [overrideMountainId, setOverrideMountainId] = useState(MOUNTAINS[0].id);
  const selectedMountain = getMountainById(overrideMountainId);
  const [overrideTrailId, setOverrideTrailId] = useState(selectedMountain.trails[0].id);
  const [overrideColor, setOverrideColor] = useState<TrailConditionColor>('GREEN');
  const [overrideReason, setOverrideReason] = useState('');
  const [adminMsg, setAdminMsg] = useState<string | null>(null);

  if (!user || !isAdmin) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16">
        <div className="bg-[#131917] border border-white/10 rounded-xl p-8 text-center space-y-4">
          <ShieldCheck className="w-8 h-8 text-amber-400 mx-auto" />
          <h1 className="font-display text-2xl font-bold text-white">Administrator Authorization Required</h1>
          <p className="text-sm text-gray-400">
            This moderation and safety operations console is restricted to verified TRAILGUARD administrators.
          </p>
          {!user && (
            <button
              onClick={signInWithGoogle}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              Sign In with Admin Google Account
            </button>
          )}
        </div>
      </div>
    );
  }

  const handleOverrideSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await adminSetTrailOverride(overrideMountainId, overrideTrailId, overrideColor, overrideReason || 'Admin patrol verification');
    setOverrideReason('');
    setAdminMsg(`Trail override applied (${overrideColor}) and logged to audit trail.`);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="border-b border-white/10 pb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Admin Operations & Moderation Console</h1>
          <p className="text-sm text-gray-400 mt-1">
            Verify hazard reports, issue trail status overrides, moderate community posts, monitor SOS alerts, and inspect the audit trail.
          </p>
        </div>
        <div className="text-xs font-mono text-amber-300">{user.email}</div>
      </div>

      {adminMsg && (
        <div className="bg-emerald-950/50 border border-emerald-500/35 rounded-lg px-4 py-2.5 text-xs text-emerald-200">
          {adminMsg}
        </div>
      )}

      {/* Trail Status Override Control */}
      <form onSubmit={handleOverrideSubmit} className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
        <h2 className="font-display text-lg font-semibold text-white">Verify / Override Trail Condition</h2>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <select
            value={overrideMountainId}
            onChange={(e) => {
              setOverrideMountainId(e.target.value);
              setOverrideTrailId(getMountainById(e.target.value).trails[0].id);
            }}
            className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
          >
            {MOUNTAINS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
          <select
            value={overrideTrailId}
            onChange={(e) => setOverrideTrailId(e.target.value)}
            className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
          >
            {selectedMountain.trails.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
          <select
            value={overrideColor}
            onChange={(e) => setOverrideColor(e.target.value as TrailConditionColor)}
            className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
          >
            <option value="GREEN">GREEN — Verified Clear</option>
            <option value="YELLOW">YELLOW — Caution</option>
            <option value="RED">RED — Dangerous / Blocked</option>
            <option value="GREY">GREY — Unverified</option>
          </select>
          <input
            type="text"
            required
            value={overrideReason}
            onChange={(e) => setOverrideReason(e.target.value)}
            placeholder="Verification reason..."
            className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
        >
          Apply Verified Override
        </button>
      </form>

      {/* Hazard Reports Review */}
      <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
        <h2 className="font-display text-lg font-semibold text-white">Hazard Report Review Queue ({reports.length})</h2>
        {reports.length === 0 ? (
          <p className="text-xs text-gray-400">No reports filed yet.</p>
        ) : (
          <div className="divide-y divide-white/10">
            {reports.slice(0, 15).map((r) => (
              <div key={r.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-semibold text-white">
                    {r.category} ({r.severity}) · {getMountainById(r.mountainId).name}
                  </div>
                  <div className="text-gray-300 mt-0.5">{r.description}</div>
                  <div className="text-gray-500 mt-0.5">
                    Current: {r.status} · Confirmations: {r.confirmCount}
                  </div>
                </div>
                <select
                  value={r.status}
                  onChange={(e) => adminUpdateReportStatus(r.id, e.target.value as ReportStatus)}
                  className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-1.5 text-xs text-white"
                >
                  {(['Newly reported', 'Under verification', 'Confirmed', 'Resolved', 'Expired'] as ReportStatus[]).map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* SOS Alerts & Community Moderation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
          <h2 className="font-display text-lg font-semibold text-white">SOS Incident Monitor ({sosAlerts.length})</h2>
          {sosAlerts.length === 0 ? (
            <p className="text-xs text-gray-400">No active SOS incidents logged.</p>
          ) : (
            <div className="divide-y divide-white/10">
              {sosAlerts.map((s) => (
                <div key={s.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="font-semibold text-red-300">{s.displayName} · {getMountainById(s.mountainId).name}</div>
                    <div className="text-gray-300">{s.message}</div>
                    <div className="font-mono text-gray-500">{s.lat.toFixed(4)}, {s.lng.toFixed(4)}</div>
                  </div>
                  <select
                    value={s.status}
                    onChange={(e) => adminUpdateSosStatus(s.id, e.target.value as 'active' | 'acknowledged' | 'resolved')}
                    className="bg-[#0B0E0D] border border-white/15 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  >
                    <option value="active">active</option>
                    <option value="acknowledged">acknowledged</option>
                    <option value="resolved">resolved</option>
                  </select>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
          <h2 className="font-display text-lg font-semibold text-white">Flagged Community Posts</h2>
          {communityPosts.filter((p) => p.flagged).length === 0 ? (
            <p className="text-xs text-gray-400">No flagged community posts awaiting review.</p>
          ) : (
            <div className="divide-y divide-white/10">
              {communityPosts
                .filter((p) => p.flagged)
                .map((p) => (
                  <div key={p.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-semibold text-white">{p.title}</div>
                      <div className="text-gray-400">{p.body}</div>
                    </div>
                    <button
                      onClick={() => adminResolveCommunityFlag(p.id, false)}
                      className="px-3 py-1.5 bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 rounded-lg cursor-pointer shrink-0"
                    >
                      Clear Flag
                    </button>
                  </div>
                ))}
            </div>
          )}
        </section>
      </div>

      {/* Immutable Admin Audit Log */}
      <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
        <h2 className="font-display text-lg font-semibold text-white">Administrative Audit Trail</h2>
        {auditLogs.length === 0 ? (
          <p className="text-xs text-gray-400">No administrative actions recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-white/10 text-gray-400">
                <tr>
                  <th className="py-2 pr-4">Time</th>
                  <th className="py-2 px-3">Action</th>
                  <th className="py-2 px-3">Target</th>
                  <th className="py-2 pl-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {auditLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="py-2 pr-4 text-gray-400">{new Date(log.createdAtIso).toLocaleString()}</td>
                    <td className="py-2 px-3 text-amber-300">{log.action}</td>
                    <td className="py-2 px-3 text-gray-300">{log.targetPath}</td>
                    <td className="py-2 pl-3 text-gray-200 font-sans">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
