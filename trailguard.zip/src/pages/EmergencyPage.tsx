import React, { useState } from 'react';
import { AlertOctagon, LocateFixed, PhoneCall, Send, ShieldAlert } from 'lucide-react';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';
import { OFFLINE_EMERGENCY_PROTOCOL } from '../lib/offline';

interface EmergencyPageProps {
  initialMountainId: string;
}

export function EmergencyPage({ initialMountainId }: EmergencyPageProps) {
  const { privateProfile } = useAuth();
  const { gpsCoordinates, requestSingleGpsFix, triggerSosAlert, isOnline } = useTrailData();

  const [mountainId, setMountainId] = useState(initialMountainId || MOUNTAINS[0].id);
  const [message, setMessage] = useState('Need assistance on trail — sharing current coordinates.');
  const [confirmStep, setConfirmStep] = useState(false);
  const [sending, setSending] = useState(false);
  const [dispatchResult, setDispatchResult] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const mountain = getMountainById(mountainId);
  const activeLat = gpsCoordinates?.lat ?? mountain.lat;
  const activeLng = gpsCoordinates?.lng ?? mountain.lng;
  const isFallbackCoord = !gpsCoordinates;

  const rescueStations = mountain.pois.filter((p) => p.type === 'rescue');
  const contacts = privateProfile?.emergencyContacts || [];

  const smsBody = encodeURIComponent(
    `TRAILGUARD SOS: ${privateProfile?.displayName || 'Hiker'} at ${mountain.name}. GPS: ${activeLat.toFixed(
      5
    )}, ${activeLng.toFixed(5)}. Note: ${message}`
  );
  const primaryContactPhone = contacts[0]?.phone || '';

  const handleDispatch = async () => {
    setSending(true);
    setErrorMsg(null);
    try {
      const fix = await requestSingleGpsFix();
      const lat = fix?.lat ?? activeLat;
      const lng = fix?.lng ?? activeLng;
      const res = await triggerSosAlert({ mountainId, lat, lng, message });
      setDispatchResult(res);
      setConfirmStep(false);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Network unavailable — use direct SMS or 112 dial below.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="border-b border-red-500/25 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white flex items-center gap-3">
            <ShieldAlert className="w-8 h-8 text-red-500" />
            Emergency & SOS Assistance
          </h1>
          <p className="text-sm text-gray-300 mt-1.5">
            Prepare SOS coordinate payloads, access nearby rescue stations, and follow offline alpine survival protocols.
          </p>
        </div>

        <select
          value={mountainId}
          onChange={(e) => setMountainId(e.target.value)}
          className="bg-[#131917] border border-white/15 rounded-lg px-3.5 py-2 text-xs text-white"
        >
          {MOUNTAINS.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </select>
      </div>

      {/* Main SOS Trigger Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 bg-[#181111] border border-red-500/35 rounded-xl p-6 sm:p-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-xs font-semibold text-red-400">SOS Beacon & Coordinate Dispatch</div>
              <div className="text-sm font-mono tabular-nums text-white mt-1">
                {activeLat.toFixed(5)}, {activeLng.toFixed(5)}
                {isFallbackCoord && (
                  <span className="text-xs font-sans text-amber-300 ml-2">
                    (Mountain reference — click Refresh GPS for live device coordinates)
                  </span>
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={() => requestSingleGpsFix()}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/15 rounded-lg text-xs text-white cursor-pointer"
            >
              <LocateFixed className="w-3.5 h-3.5 text-sky-400" /> Refresh GPS
            </button>
          </div>

          <div>
            <label className="block text-xs text-gray-300 mb-1.5">Situation Message</label>
            <textarea
              rows={2}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full bg-black/50 border border-white/15 rounded-lg px-3.5 py-2.5 text-sm text-white"
            />
          </div>

          {!confirmStep ? (
            <button
              type="button"
              onClick={() => setConfirmStep(true)}
              className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-display text-lg font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2.5 shadow-lg"
            >
              <AlertOctagon className="w-6 h-6" />
              TRIGGER SOS EMERGENCY ALERT
            </button>
          ) : (
            <div className="bg-black/60 border border-red-500/50 rounded-xl p-4 space-y-3">
              <p className="text-xs text-red-200 font-medium">
                Confirm SOS transmission: this logs your coordinates on TRAILGUARD and prepares emergency contact payloads. Note: a web browser cannot directly dial emergency dispatch without your device carrier.
              </p>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={sending}
                  onClick={handleDispatch}
                  className="flex-1 py-2.5 px-4 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg cursor-pointer disabled:opacity-50"
                >
                  {sending ? 'Logging SOS...' : 'Confirm & Send SOS Record'}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmStep(false)}
                  className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-gray-200 text-xs rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="bg-amber-950/60 border border-amber-500/40 rounded-lg p-3 text-xs text-amber-200">
              {errorMsg}
            </div>
          )}

          {dispatchResult && (
            <div className="bg-black/50 border border-white/15 rounded-xl p-4 space-y-2 text-xs">
              <div className="font-semibold text-white">
                SOS Reference: <span className="font-mono text-red-300">{dispatchResult.referenceId}</span>
              </div>
              <p className="text-amber-200">{dispatchResult.honestStatus}</p>
              <div className="text-gray-400">
                Emergency Services Contacted Automatically: <strong className="text-white">No (Manual Call Required)</strong>
              </div>
            </div>
          )}

          {/* Direct Cellular Triggers (Work even when data internet is down) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-white/10">
            <a
              href={`tel:${mountain.nearestEmergencyNumber.split('/')[0].trim()}`}
              className="flex items-center justify-center gap-2 py-3 px-4 bg-white/10 hover:bg-white/15 border border-white/15 rounded-lg text-xs font-semibold text-white"
            >
              <PhoneCall className="w-4 h-4 text-red-400" />
              Call Emergency ({mountain.nearestEmergencyNumber})
            </a>
            <a
              href={`sms:${primaryContactPhone}?body=${smsBody}`}
              className="flex items-center justify-center gap-2 py-3 px-4 bg-white/10 hover:bg-white/15 border border-white/15 rounded-lg text-xs font-semibold text-white"
            >
              <Send className="w-4 h-4 text-emerald-400" />
              Prepare Offline SMS with GPS
            </a>
          </div>
          {!isOnline && (
            <p className="text-xs text-amber-300">
              Offline mode detected: internet alerts cannot reach servers, use direct cellular Call or SMS triggers above.
            </p>
          )}
        </div>

        {/* Rescue Stations, Trusted Contacts & Offline Protocol */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <h2 className="font-display text-lg font-semibold text-white">Nearby Rescue Stations ({mountain.name})</h2>
            {rescueStations.map((st) => (
              <div key={st.id} className="border-t border-white/10 pt-3 text-xs space-y-1">
                <div className="font-semibold text-white">{st.name}</div>
                <div className="text-gray-400">{st.notes}</div>
                <div className="font-mono text-gray-500">
                  {st.lat.toFixed(4)}, {st.lng.toFixed(4)} · Elev {st.elevationM} m
                </div>
              </div>
            ))}
          </div>

          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <h2 className="font-display text-lg font-semibold text-white">Trusted Emergency Contacts</h2>
            {contacts.length === 0 ? (
              <p className="text-xs text-gray-400">
                No emergency contacts saved yet. Add trusted contacts in your User Profile so SOS SMS drafts pre-fill automatically.
              </p>
            ) : (
              <div className="divide-y divide-white/10 text-xs">
                {contacts.map((c, idx) => (
                  <div key={idx} className="py-2 flex items-center justify-between">
                    <div>
                      <span className="font-medium text-white">{c.name}</span>
                      <span className="text-gray-400 ml-2">({c.relation})</span>
                    </div>
                    <a href={`tel:${c.phone}`} className="font-mono text-emerald-400 hover:underline">
                      {c.phone}
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <h2 className="font-display text-lg font-semibold text-white">Offline Survival Protocol</h2>
            <ol className="space-y-2 text-xs text-gray-300 list-decimal pl-4">
              {OFFLINE_EMERGENCY_PROTOCOL.map((step, i) => (
                <li key={i} className="leading-relaxed">
                  {step}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
