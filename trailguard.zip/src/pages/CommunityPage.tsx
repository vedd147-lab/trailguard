import React, { useState } from 'react';
import { Flag, Heart, Plus, Star, Users } from 'lucide-react';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';

export function CommunityPage() {
  const { user, signInWithGoogle } = useAuth();
  const {
    communityPosts,
    hikingGroups,
    publicProfiles,
    createCommunityPost,
    likeCommunityPost,
    flagCommunityPost,
    createHikingGroup,
  } = useTrailData();

  // New Experience Post State
  const [mountainId, setMountainId] = useState(MOUNTAINS[0].id);
  const selectedMountain = getMountainById(mountainId);
  const [trailId, setTrailId] = useState(selectedMountain.trails[0].id);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [rating, setRating] = useState(5);
  const [postMsg, setPostMsg] = useState<string | null>(null);

  // New Group State
  const [groupName, setGroupName] = useState('');
  const [groupMountainId, setGroupMountainId] = useState(MOUNTAINS[0].id);
  const [plannedDate, setPlannedDate] = useState('2026-12-05');
  const [createdInvite, setCreatedInvite] = useState<string | null>(null);

  const handlePublishPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      await signInWithGoogle();
      return;
    }
    if (title.trim().length < 3 || body.trim().length < 5) return;
    await createCommunityPost({ mountainId, trailId, title, body, rating });
    setTitle('');
    setBody('');
    setPostMsg('Experience published to community feed.');
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      await signInWithGoogle();
      return;
    }
    if (groupName.trim().length < 2) return;
    const code = await createHikingGroup({ name: groupName, mountainId: groupMountainId, plannedDate });
    setGroupName('');
    setCreatedInvite(code);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="border-b border-white/10 pb-6">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Community & Group Hiking</h1>
        <p className="text-sm text-gray-400 mt-1.5">
          Create trekking groups, coordinate consented location sharing, publish hike logs, and rate mountain routes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Create Group + Active Groups + Hiker Profiles */}
        <div className="lg:col-span-5 space-y-6">
          <form onSubmit={handleCreateGroup} className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" /> Create Hiking Group
            </h2>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Group Name</label>
              <input
                type="text"
                required
                minLength={2}
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="e.g. Dawn Sinhagad Ridge Crew"
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Destination</label>
                <select
                  value={groupMountainId}
                  onChange={(e) => setGroupMountainId(e.target.value)}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {MOUNTAINS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Planned Date</label>
                <input
                  type="date"
                  value={plannedDate}
                  onChange={(e) => setPlannedDate(e.target.value)}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>
            </div>
            {createdInvite && (
              <div className="bg-emerald-950/50 border border-emerald-500/30 rounded-lg p-3 text-xs text-emerald-200">
                Group created. Share invite code: <strong className="font-mono">{createdInvite}</strong>
              </div>
            )}
            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              {user ? 'Create Group & Generate Invite' : 'Sign In & Create Group'}
            </button>
          </form>

          {/* Active Groups */}
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <h3 className="font-display text-base font-semibold text-white">Active Hiking Groups</h3>
            {hikingGroups.length === 0 ? (
              <p className="text-xs text-gray-400">No groups scheduled yet. Create the first group above.</p>
            ) : (
              <div className="divide-y divide-white/10">
                {hikingGroups.map((g) => (
                  <div key={g.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-semibold text-white">{g.name}</div>
                      <div className="text-gray-400">
                        {getMountainById(g.mountainId).name} · Lead: {g.leaderName} · {g.plannedDate}
                      </div>
                    </div>
                    <span className="font-mono text-emerald-400 shrink-0">{g.inviteCode}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Community Hikers */}
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <h3 className="font-display text-base font-semibold text-white">Active Trail Community</h3>
            {publicProfiles.length === 0 ? (
              <p className="text-xs text-gray-400">Sign in to appear in the community hiker directory.</p>
            ) : (
              <div className="divide-y divide-white/10">
                {publicProfiles.slice(0, 6).map((p) => (
                  <div key={p.uid} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-medium text-white">{p.displayName}</span>
                      <span className="text-gray-500 ml-2">{p.experienceLevel}</span>
                    </div>
                    <span className="font-mono tabular-nums text-gray-300">
                      {p.hikesCompleted} hikes · {p.totalDistanceKm.toFixed(1)} km
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Publish Experience & Feed */}
        <div className="lg:col-span-7 space-y-6">
          <form onSubmit={handlePublishPost} className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold text-white">Share Hiking Experience & Route Rating</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Mountain</label>
                <select
                  value={mountainId}
                  onChange={(e) => {
                    setMountainId(e.target.value);
                    setTrailId(getMountainById(e.target.value).trails[0].id);
                  }}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {MOUNTAINS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Route</label>
                <select
                  value={trailId}
                  onChange={(e) => setTrailId(e.target.value)}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {selectedMountain.trails.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Rating (1–5)</label>
                <select
                  value={rating}
                  onChange={(e) => setRating(Number(e.target.value))}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {[5, 4, 3, 2, 1].map((r) => (
                    <option key={r} value={r}>
                      {r} / 5
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <input
              type="text"
              required
              minLength={3}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Headline (e.g. Clear morning ridge via Atkarwadi)"
              className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
            />
            <textarea
              required
              minLength={5}
              rows={3}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Share trail footing, water availability, wind exposure, and start time..."
              className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
            />
            {postMsg && <p className="text-xs text-emerald-400">{postMsg}</p>}
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              {user ? 'Publish Experience' : 'Sign In & Publish'}
            </button>
          </form>

          {/* Feed */}
          <div className="space-y-4">
            {communityPosts.length === 0 ? (
              <div className="bg-[#131917] border border-white/10 rounded-xl p-8 text-center text-sm text-gray-400">
                No community hike experiences published yet. Share your first trek log above.
              </div>
            ) : (
              communityPosts.map((post) => (
                <div key={post.id} className="bg-[#131917] border border-white/10 rounded-xl p-5 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-display text-lg font-semibold text-white">{post.title}</h3>
                      <div className="text-xs text-gray-400 mt-0.5">
                        {post.authorName} · {getMountainById(post.mountainId).name} ·{' '}
                        {new Date(post.createdAtIso).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="inline-flex items-center gap-1 text-xs font-mono text-amber-400 shrink-0">
                      <Star className="w-3.5 h-3.5 fill-amber-400" /> {post.rating}/5
                    </div>
                  </div>
                  <p className="text-sm text-gray-200 leading-relaxed">{post.body}</p>
                  <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
                    <button
                      onClick={() => (user ? likeCommunityPost(post.id, post.likesCount) : signInWithGoogle())}
                      className="inline-flex items-center gap-1.5 text-gray-300 hover:text-emerald-400 cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5" /> Helpful ({post.likesCount})
                    </button>
                    <button
                      onClick={() => (user ? flagCommunityPost(post.id) : signInWithGoogle())}
                      className="inline-flex items-center gap-1 text-gray-500 hover:text-amber-400 cursor-pointer"
                    >
                      <Flag className="w-3.5 h-3.5" /> {post.flagged ? 'Flagged for Review' : 'Report'}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
