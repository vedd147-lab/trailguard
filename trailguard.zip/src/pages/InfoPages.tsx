import React, { useState } from 'react';

export function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">About TRAILGUARD</h1>
      <p className="text-base text-gray-300 leading-relaxed">
        TRAILGUARD is built around a single mission: making every mountain adventure more informed, connected, and safer. Beginning in the Sahyadri ranges of Maharashtra—including Sinhagad Fort, Rajmachi Fort, and Harishchandragad—and engineered to scale internationally to peaks like Mount Fuji, TRAILGUARD unites topographic mapping, live meteorological feeds, community hazard verification, and AI-assisted risk analysis.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 pt-4">
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5 space-y-2">
          <h2 className="font-display text-base font-semibold text-white">Transparent Telemetry</h2>
          <p className="text-xs text-gray-400 leading-relaxed">
            Every weather metric cites its Open-Meteo source and timestamp. Unverified trails remain marked Grey rather than assumed clear.
          </p>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5 space-y-2">
          <h2 className="font-display text-base font-semibold text-white">Privacy First</h2>
          <p className="text-xs text-gray-400 leading-relaxed">
            GPS tracking requests explicit permission, defaults to private, and automatically expires inactive sessions.
          </p>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5 space-y-2">
          <h2 className="font-display text-base font-semibold text-white">Offline Resilience</h2>
          <p className="text-xs text-gray-400 leading-relaxed">
            Routes, shelters, emergency protocols, and hazard queues remain accessible in low-connectivity mountain valleys.
          </p>
        </div>
      </div>
    </div>
  );
}

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.includes('@') || message.trim().length < 10) return;
    setSubmitted(true);
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
      <h1 className="font-display text-3xl font-bold text-white">Contact TRAILGUARD</h1>
      <p className="text-sm text-gray-400">
        Reach our mountain cartography and safety partnerships team for trail additions, rescue station updates, or moderation inquiries.
      </p>
      <form onSubmit={handleSubmit} className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
        <div>
          <label className="block text-xs text-gray-400 mb-1">Full Name</label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
          />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">Email Address</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
          />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">Message (min 10 characters)</label>
          <textarea
            required
            minLength={10}
            rows={4}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
          />
        </div>
        {submitted && (
          <p className="text-xs text-emerald-400">
            Thank you. Your inquiry has been recorded by the TRAILGUARD operations desk.
          </p>
        )}
        <button
          type="submit"
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
        >
          Send Message
        </button>
      </form>
    </div>
  );
}

export function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-5 text-sm text-gray-300 leading-relaxed">
      <h1 className="font-display text-3xl font-bold text-white">Privacy Policy</h1>
      <p>
        TRAILGUARD collects only the information necessary to provide navigation, weather intelligence, and voluntary safety features.
      </p>
      <h2 className="font-display text-lg font-semibold text-white pt-2">1. Location & GPS Privacy</h2>
      <p>
        GPS tracking begins only after explicit browser permission and user initiation of a hiking session. Sessions default to Private and automatically expire after 2 hours of inactivity.
      </p>
      <h2 className="font-display text-lg font-semibold text-white pt-2">2. PII & Emergency Contacts</h2>
      <p>
        Your email address and emergency contacts are isolated in private user records accessible only to your authenticated account and verified safety operations.
      </p>
    </div>
  );
}

export function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-5 text-sm text-gray-300 leading-relaxed">
      <h1 className="font-display text-3xl font-bold text-white">Terms & Safety Disclaimer</h1>
      <p>
        Mountain environments are inherently hazardous and subject to rapid weather, rockfall, and visibility changes.
      </p>
      <h2 className="font-display text-lg font-semibold text-white pt-2">1. Advisory Nature of Information</h2>
      <p>
        Weather forecasts, crowd estimates, community reports, and AI risk assessments are informational tools only and never constitute certified safety clearance.
      </p>
      <h2 className="font-display text-lg font-semibold text-white pt-2">2. Emergency Limitations</h2>
      <p>
        Web browsers cannot guarantee cellular delivery to official dispatch agencies. Always use direct voice dialing (112 / 110 / 119) or dedicated satellite communicators in emergencies.
      </p>
    </div>
  );
}
