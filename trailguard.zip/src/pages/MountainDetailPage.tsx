import React, { useEffect } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Bookmark,
  CloudRain,
  Download,
  Droplets,
  Home as HomeIcon,
  MapPin,
  Navigation,
  ShieldAlert,
  Thermometer,
  Wind,
} from 'lucide-react';
import { getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';
import { PageRoute } from '../types/trailguard';
import { ConditionText } from '../components/ConditionText';
import { LiveMountainMap } from '../components/LiveMountainMap';
import { MountainTerrain3D } from '../components/MountainTerrain3D';

interface MountainDetailPageProps {
  mountainId: string;
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

export function MountainDetailPage({ mountainId, onNavigate }: MountainDetailPageProps) {
  const mountain = getMountainById(mountainId);
  const { user, privateProfile, toggleSavedMountain } = useAuth();
  const {
    reports,
    publicSessions,
    gpsCoordinates,
    weatherByMountain,
    weatherLoading,
    weatherError,
    fetchWeatherForMountain,
    getEffectiveTrailCondition,
    offlinePacks,
    downloadMountainOffline,
  } = useTrailData();

  useEffect(() => {
    fetchWeatherForMountain(mountain.id);
  }, [mountain.id, fetchWeatherForMountain]);

  const weather = weatherByMountain[mountain.id];
  const isSaved = privateProfile?.savedMountainIds.includes(mountain.id) ?? false;
  const isOfflineSaved = offlinePacks.some((p) => p.mountainId === mountain.id);
  const mountainReports = reports.filter((r) => r.mountainId === mountain.id);

  // Elevation SVG geometry
  const maxElev = Math.max(...mountain.elevationProfile.map((p) => p.elevM));
  const minElev = Math.min(...mountain.elevationProfile.map((p) => p.elevM));
  const maxKm = Math.max(...mountain.elevationProfile.map((p) => p.km), 1);
  const svgPoints = mountain.elevationProfile
    .map((pt) => {
      const x = (pt.km / maxKm) * 560 + 20;
      const y = 135 - ((pt.elevM - minElev) / Math.max(1, maxElev - minElev)) * 105;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Breadcrumb & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={() => onNavigate('mountains')}
          className="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-white cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Mountains
        </button>

        <div className="flex flex-wrap items-center gap-2.5">
          {user && (
            <button
              onClick={() => toggleSavedMountain(mountain.id)}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border cursor-pointer transition-colors ${
                isSaved
                  ? 'bg-emerald-600/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-[#131917] border-white/15 text-gray-200 hover:bg-white/5'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              {isSaved ? 'Saved Mountain' : 'Save Mountain'}
            </button>
          )}
          <button
            onClick={() => downloadMountainOffline(mountain.id)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#131917] hover:bg-white/5 border border-white/15 text-gray-200 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            {isOfflineSaved ? 'Refresh Offline Pack' : 'Save Offline Pack'}
          </button>
          <button
            onClick={() => onNavigate('map', mountain.id)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
          >
            <Navigation className="w-3.5 h-3.5" /> Start Live GPS Map
          </button>
        </div>
      </div>

      {/* Hero Header Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-7 relative min-h-[300px] rounded-xl overflow-hidden border border-white/10 bg-[#131917]">
          <img
            src={mountain.imageUrl}
            alt={mountain.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5 space-y-1.5">
            <div className="text-xs text-emerald-400 font-medium">
              {mountain.region} · {mountain.country}
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">{mountain.name}</h1>
            <p className="text-sm text-gray-200 max-w-2xl">{mountain.summary}</p>
          </div>
        </div>

        {/* Live Weather + Key Metrics */}
        <div className="lg:col-span-5 bg-[#131917] border border-white/10 rounded-xl p-6 flex flex-col justify-between space-y-5">
          <div className="grid grid-cols-2 gap-4 border-b border-white/10 pb-4">
            <div>
              <div className="text-xs text-gray-400">Summit Elevation</div>
              <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-0.5">
                {mountain.elevationM} m
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-400">Coordinates</div>
              <div className="text-sm font-mono tabular-nums text-gray-200 mt-1.5">
                {mountain.lat.toFixed(4)}, {mountain.lng.toFixed(4)}
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-white flex items-center gap-1.5">
                <CloudRain className="w-4 h-4 text-emerald-400" /> Is It a Good Time to Hike?
              </span>
              <button
                onClick={() => fetchWeatherForMountain(mountain.id, true)}
                className="text-xs text-emerald-400 hover:text-emerald-300 cursor-pointer"
              >
                Refresh
              </button>
            </div>

            {weatherLoading[mountain.id] && !weather && (
              <p className="text-xs text-gray-400">Loading Open-Meteo conditions...</p>
            )}
            {weatherError[mountain.id] && (
              <p className="text-xs text-red-400">{weatherError[mountain.id]}</p>
            )}
            {weather && (
              <div className="space-y-3">
                <div className="text-sm font-semibold text-emerald-400">
                  {weather.goodTimeToHike.verdict}
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">{weather.goodTimeToHike.rationale}</p>
                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-xs">
                  <div>
                    <span className="text-gray-400 flex items-center gap-1"><Thermometer className="w-3 h-3" /> Temp</span>
                    <span className="font-mono tabular-nums text-white">{weather.current.temperatureC}°C</span>
                  </div>
                  <div>
                    <span className="text-gray-400 flex items-center gap-1"><Wind className="w-3 h-3" /> Wind</span>
                    <span className="font-mono tabular-nums text-white">{weather.current.windSpeedKmh} km/h</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Rain Prob</span>
                    <span className="font-mono tabular-nums text-white block">{weather.current.rainProbabilityPct}%</span>
                  </div>
                </div>
                <p className="text-[11px] text-gray-500">
                  Source: {weather.source} · {new Date(weather.fetchedAt).toLocaleTimeString()}
                </p>
              </div>
            )}
          </div>

          <button
            onClick={() => onNavigate('ai-risk', mountain.id)}
            className="w-full py-2.5 bg-white/5 hover:bg-white/10 border border-white/15 rounded-lg text-xs font-semibold text-white cursor-pointer"
          >
            Run Gemini AI Trail Risk Assessment
          </button>
        </div>
      </div>

      {/* Route Comparison Matrix */}
      <section className="space-y-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-white">Route Comparison & Safety Intelligence</h2>
          <p className="text-xs text-gray-400 mt-1">
            Routes are evaluated on distance, elevation gain, gradient, terrain exposure, and active hazard reports. Never choose a route solely because it is shorter.
          </p>
        </div>

        <div className="overflow-x-auto bg-[#131917] border border-white/10 rounded-xl">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 text-xs text-gray-400">
              <tr>
                <th className="py-3.5 px-4 font-medium">Trail Route</th>
                <th className="py-3.5 px-4 font-medium">Category</th>
                <th className="py-3.5 px-4 font-medium text-right">Distance</th>
                <th className="py-3.5 px-4 font-medium text-right">Elev Gain</th>
                <th className="py-3.5 px-4 font-medium text-right">Gradient</th>
                <th className="py-3.5 px-4 font-medium text-right">Est. Time</th>
                <th className="py-3.5 px-4 font-medium">Condition</th>
                <th className="py-3.5 px-4 font-medium">Safety Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {mountain.trails.map((t) => {
                const cond = getEffectiveTrailCondition(mountain.id, t.id, t.defaultCondition);
                return (
                  <tr key={t.id} className="hover:bg-white/5">
                    <td className="py-3.5 px-4 font-medium text-white">
                      <div>{t.name}</div>
                      <div className="text-xs text-gray-400 font-normal">{t.terrainType}</div>
                    </td>
                    <td className="py-3.5 px-4 text-xs text-gray-300">{t.routeTag} · {t.difficulty}</td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-right text-gray-200">{t.distanceKm} km</td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-right text-gray-200">+{t.elevationGainM} m</td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-right text-gray-200">{t.gradientPct}%</td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-right text-gray-200">{t.estimatedDurationMin} min</td>
                    <td className="py-3.5 px-4">
                      <ConditionText condition={cond} />
                    </td>
                    <td className="py-3.5 px-4 text-xs text-gray-300 max-w-xs">{t.safetyWarning}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Elevation Profile & 3D Terrain Visualization */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-xl font-semibold text-white">Primary Ascent Elevation Profile</h2>
          <p className="text-xs text-gray-400">
            Baseline ascent from {minElev} m trailhead to {maxElev} m summit ridge.
          </p>
          <svg viewBox="0 0 600 160" className="w-full h-44 bg-black/30 rounded-lg border border-white/10">
            <polyline
              fill="none"
              stroke="#22C55E"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={svgPoints}
            />
            {mountain.elevationProfile.map((pt, i) => {
              const x = (pt.km / maxKm) * 560 + 20;
              const y = 135 - ((pt.elevM - minElev) / Math.max(1, maxElev - minElev)) * 105;
              return (
                <g key={i}>
                  <circle cx={x} cy={y} r="4" fill="#10B981" stroke="#0B0E0D" strokeWidth="1.5" />
                  <text x={x} y={y - 8} textAnchor="middle" fill="#9CA3AF" fontSize="10" fontFamily="monospace">
                    {pt.elevM}m
                  </text>
                </g>
              );
            })}
          </svg>

          <div className="space-y-2 pt-2 border-t border-white/10">
            <h3 className="text-xs font-semibold text-gray-300">Historical Hazard Context</h3>
            <ul className="space-y-1.5 text-xs text-gray-400">
              {mountain.historicalHazards.map((h, i) => (
                <li key={i} className="flex items-start gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{h}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="lg:col-span-7 space-y-3">
          <h2 className="font-display text-xl font-semibold text-white">3D Mountain Terrain & Trail Relief</h2>
          <MountainTerrain3D mountain={mountain} getTrailCondition={getEffectiveTrailCondition} />
        </div>
      </div>

      {/* Interactive Topographic Map */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-semibold text-white">Interactive Topographic Map</h2>
          <button
            onClick={() => onNavigate('reports', mountain.id)}
            className="text-xs font-medium text-amber-400 hover:text-amber-300 cursor-pointer"
          >
            Report Hazard on {mountain.name}
          </button>
        </div>
        <LiveMountainMap
          mountain={mountain}
          reports={reports}
          publicSessions={publicSessions}
          userGps={gpsCoordinates}
          getTrailCondition={getEffectiveTrailCondition}
          heightClass="h-[460px]"
        />
      </section>

      {/* Shelters, Water Sources, Rescue Stations & Recent Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-6 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-xl font-semibold text-white">Shelters, Water Sources & Rescue Stations</h2>
          <div className="divide-y divide-white/10">
            {mountain.pois.map((poi) => (
              <div key={poi.id} className="py-3 flex items-start justify-between gap-4">
                <div className="space-y-0.5">
                  <div className="text-sm font-medium text-white flex items-center gap-2">
                    {poi.type === 'water' && <Droplets className="w-4 h-4 text-sky-400" />}
                    {poi.type === 'shelter' && <HomeIcon className="w-4 h-4 text-blue-400" />}
                    {poi.type === 'rescue' && <ShieldAlert className="w-4 h-4 text-red-400" />}
                    {(poi.type === 'trailhead' || poi.type === 'summit') && <MapPin className="w-4 h-4 text-emerald-400" />}
                    {poi.name}
                  </div>
                  <p className="text-xs text-gray-400">{poi.notes}</p>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs font-mono tabular-nums text-gray-300">{poi.elevationM} m</div>
                  <div className="text-[11px] font-mono text-gray-500">
                    {poi.lat.toFixed(3)}, {poi.lng.toFixed(3)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-6 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-semibold text-white">Recent Trail Reports</h2>
            <button
              onClick={() => onNavigate('reports', mountain.id)}
              className="text-xs font-medium text-emerald-400 hover:text-emerald-300 cursor-pointer"
            >
              Submit Report
            </button>
          </div>
          {mountainReports.length === 0 ? (
            <p className="text-sm text-gray-400 py-6">
              No hazard reports logged for {mountain.name} yet. Unverified sections remain marked Grey or caution until hikers confirm conditions.
            </p>
          ) : (
            <div className="divide-y divide-white/10">
              {mountainReports.slice(0, 5).map((r) => (
                <div key={r.id} className="py-3 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">{r.category} · {r.severity}</span>
                    <span className="text-gray-400">{r.status} · {r.confirmCount} confirmed</span>
                  </div>
                  <p className="text-xs text-gray-300">{r.description}</p>
                  <div className="text-[11px] text-gray-500">
                    {r.reporterName} · {new Date(r.createdAtIso).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
