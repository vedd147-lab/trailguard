import React, { useEffect, useState } from 'react';
import { LogOut, Plus, Shield, Trash2, UserCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { EmergencyContact, ExperienceLevel } from '../types/trailguard';

export function ProfilePage() {
  const { user, privateProfile, signInWithGoogle, logout, updateProfileSettings, authError, isAdmin } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [experienceLevel, setExperienceLevel] = useState<ExperienceLevel>('Intermediate');
  const [shareGroup, setShareGroup] = useState(true);
  const [sharePublic, setSharePublic] = useState(false);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);

  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newRelation, setNewRelation] = useState('');
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  useEffect(() => {
    if (privateProfile) {
      setDisplayName(privateProfile.displayName);
      setExperienceLevel(privateProfile.experienceLevel);
      setShareGroup(privateProfile.shareLocationWithGroup);
      setSharePublic(privateProfile.shareLocationPublicActivity);
      setContacts(privateProfile.emergencyContacts || []);
    }
  }, [privateProfile]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavedMsg(null);
    await updateProfileSettings({
      displayName,
      experienceLevel,
      shareLocationWithGroup: shareGroup,
      shareLocationPublicActivity: sharePublic,
      emergencyContacts: contacts,
    });
    setSavedMsg('Profile, privacy settings, and emergency contacts saved securely.');
  };

  const handleAddContact = () => {
    if (!newName.trim() || !newPhone.trim()) return;
    setContacts((prev) => [
      ...prev,
      { name: newName.trim(), phone: newPhone.trim(), relation: newRelation.trim() || 'Emergency Contact' },
    ]);
    setNewName('');
    setNewPhone('');
    setNewRelation('');
  };

  if (!user) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16">
        <div className="bg-[#131917] border border-white/10 rounded-xl p-8 text-center space-y-4">
          <h1 className="font-display text-2xl font-bold text-white">Sign In to TRAILGUARD</h1>
          <p className="text-sm text-gray-400">
            Authenticate securely with Google to manage your hiker profile, emergency contacts, privacy preferences, and live GPS tracking.
          </p>
          {authError && <p className="text-xs text-red-400">{authError}</p>}
          <button
            onClick={signInWithGoogle}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold rounded-lg cursor-pointer"
          >
            Continue with Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex items-center justify-between border-b border-white/10 pb-6">
        <div className="flex items-center gap-4">
          {user.photoURL ? (
            <img
              src={user.photoURL}
              alt={displayName}
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-full object-cover border border-white/15"
            />
          ) : (
            <div className="w-14 h-14 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-300 font-bold text-lg">
              {displayName.slice(0, 1).toUpperCase()}
            </div>
          )}
          <div>
            <h1 className="font-display text-2xl font-bold text-white flex items-center gap-2">
              {privateProfile?.displayName || user.displayName}
              {isAdmin && (
                <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-300">
                  <Shield className="w-3.5 h-3.5" /> Admin
                </span>
              )}
            </h1>
            <p className="text-xs text-gray-400">{user.email}</p>
          </div>
        </div>

        <button
          onClick={logout}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/15 rounded-lg text-xs text-gray-200 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" /> Sign Out
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        {/* Profile & Experience */}
        <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-lg font-semibold text-white flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-emerald-400" /> Hiker Profile
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Display Name</label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Hiking Experience Level</label>
              <select
                value={experienceLevel}
                onChange={(e) => setExperienceLevel(e.target.value as ExperienceLevel)}
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
              >
                {(['Beginner', 'Intermediate', 'Advanced', 'Alpine'] as ExperienceLevel[]).map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </section>

        {/* Privacy & Location Sharing */}
        <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-lg font-semibold text-white">Location & Privacy Preferences</h2>
          <label className="flex items-start gap-3 text-sm text-gray-200 cursor-pointer">
            <input
              type="checkbox"
              checked={shareGroup}
              onChange={(e) => setShareGroup(e.target.checked)}
              className="mt-1 accent-emerald-500"
            />
            <span>
              Allow sharing live GPS coordinates with my consented hiking group during active sessions.
            </span>
          </label>
          <label className="flex items-start gap-3 text-sm text-gray-200 cursor-pointer">
            <input
              type="checkbox"
              checked={sharePublic}
              onChange={(e) => setSharePublic(e.target.checked)}
              className="mt-1 accent-emerald-500"
            />
            <span>
              Contribute anonymized live session count to public mountain crowd activity metrics.
            </span>
          </label>
        </section>

        {/* Emergency Contacts */}
        <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-lg font-semibold text-white">Trusted Emergency Contacts</h2>
          <p className="text-xs text-gray-400">
            Stored privately in your encrypted user record. Used to pre-fill SOS alerts.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Contact Name"
              className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
            />
            <input
              type="tel"
              value={newPhone}
              onChange={(e) => setNewPhone(e.target.value)}
              placeholder="Phone (+91...)"
              className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
            />
            <div className="flex gap-2">
              <input
                type="text"
                value={newRelation}
                onChange={(e) => setNewRelation(e.target.value)}
                placeholder="Relation"
                className="flex-1 bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              />
              <button
                type="button"
                onClick={handleAddContact}
                className="px-3 py-2 bg-white/10 hover:bg-white/15 rounded-lg text-xs text-white cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {contacts.length > 0 && (
            <div className="divide-y divide-white/10">
              {contacts.map((c, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-white">{c.name}</span>
                    <span className="text-gray-400 ml-2">({c.relation})</span>
                    <span className="font-mono text-emerald-400 ml-3">{c.phone}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setContacts((prev) => prev.filter((_, i) => i !== idx))}
                    className="text-gray-500 hover:text-red-400 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </section>

        {savedMsg && <p className="text-xs text-emerald-400">{savedMsg}</p>}

        <button
          type="submit"
          className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold rounded-lg cursor-pointer"
        >
          Save Profile Changes
        </button>
      </form>
    </div>
  );
}
