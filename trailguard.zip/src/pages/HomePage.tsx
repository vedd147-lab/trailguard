import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Brain,
  CloudRain,
  Compass,
  MapPin,
  Search,
  ShieldAlert,
  Thermometer,
  Users,
  Wind,
} from 'lucide-react';
import { MOUNTAINS } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { PageRoute } from '../types/trailguard';
import { ConditionText } from '../components/ConditionText';

interface HomePageProps {
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const {
    reports,
    publicSessions,
    communityPosts,
    weatherByMountain,
    weatherLoading,
    getEffectiveTrailCondition,
  } = useTrailData();

  const [searchQuery, setSearchQuery] = useState('');

  const filteredMountains = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return MOUNTAINS;
    return MOUNTAINS.filter(
      (m) =>
        m.name.toLowerCase().includes(q) ||
        m.region.toLowerCase().includes(q) ||
        m.country.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const primaryWeather = weatherByMountain['sinhagad-fort'];
  const activeReports = reports.filter((r) => r.status !== 'Resolved' && r.status !== 'Expired').slice(0, 4);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (filteredMountains.length === 1) {
      onNavigate('mountain-detail', filteredMountains[0].id);
    } else {
      onNavigate('mountains');
    }
  };

  return (
    <div className="bg-[#0B0E0D] text-[#E5E7EB]">
      {/* 1. HERO SECTION */}
      <section className="relative min-h-[620px] lg:min-h-[680px] flex items-center overflow-hidden border-b border-white/10">
        <img
          src="/src/assets/images/hero_mountain_summit_1795755592639.jpg"
          alt="Hikers ascending a dramatic misty mountain ridge at sunrise"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E0D] via-[#0B0E0D]/70 to-black/45" />

        <div className="relative z-10 max-w-[1440px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="max-w-3xl space-y-6">
            <p className="text-xs font-semibold tracking-wider text-emerald-400">
              Explore Smarter · Navigate Safer · Reach Further
            </p>
            <h1
              className="font-display font-bold text-white tracking-tight leading-[1.08]"
              style={{ fontSize: 'clamp(2.25rem, 4.2vw, 3.75rem)', textWrap: 'balance' }}
            >
              THE MOUNTAINS ARE CALLING. HIKE WITH CONFIDENCE.
            </h1>
            <p className="text-base sm:text-lg text-gray-300 leading-relaxed max-w-2xl">
              Discover safer trails, monitor mountain conditions, track hiking activity and explore the outdoors with intelligent mountain safety technology.
            </p>

            {/* Mountain Search Bar */}
            <form onSubmit={handleSearchSubmit} className="max-w-xl pt-2">
              <div className="flex flex-col sm:flex-row gap-2 p-1.5 bg-[#111614]/95 border border-white/15 rounded-xl shadow-2xl">
                <div className="relative flex-1 flex items-center">
                  <Search className="w-4 h-4 text-gray-400 ml-3 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search mountain, fort, or region (e.g. Sinhagad, Rajmachi, Fuji)..."
                    aria-label="Search mountains"
                    className="w-full bg-transparent px-3 py-2.5 text-sm text-white placeholder:text-gray-500 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Search Trails
                </button>
              </div>
              {searchQuery.trim() && (
                <div className="mt-2 bg-[#141B18] border border-white/15 rounded-lg divide-y divide-white/10">
                  {filteredMountains.length === 0 ? (
                    <div className="px-4 py-3 text-xs text-gray-400">
                      No matching mountain in directory yet. Open Explorer to view all supported peaks.
                    </div>
                  ) : (
                    filteredMountains.map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => onNavigate('mountain-detail', m.id)}
                        className="w-full px-4 py-2.5 flex items-center justify-between text-left hover:bg-white/5 transition-colors cursor-pointer"
                      >
                        <div>
                          <div className="text-sm font-medium text-white">{m.name}</div>
                          <div className="text-xs text-gray-400">
                            {m.region} · {m.country}
                          </div>
                        </div>
                        <span className="text-xs font-mono tabular-nums text-emerald-400">{m.elevationM} m</span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </form>

            {/* Primary CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('mountains')}
                className="inline-flex items-center gap-2 px-5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Explore Mountains
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onNavigate('conditions')}
                className="inline-flex items-center gap-2 px-5 py-3 bg-[#161D1A] hover:bg-[#1E2723] border border-white/15 text-white text-sm font-medium rounded-lg transition-colors cursor-pointer"
              >
                View Live Conditions
              </button>
              <button
                onClick={() => onNavigate('emergency')}
                className="inline-flex items-center gap-2 px-4 py-3 bg-red-950/60 hover:bg-red-900/70 border border-red-500/35 text-red-200 text-sm font-medium rounded-lg transition-colors cursor-pointer"
              >
                <ShieldAlert className="w-4 h-4 text-red-400" />
                SOS Assistance
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. POPULAR HIKING DESTINATIONS */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 border-b border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-white">Popular Hiking Destinations</h2>
            <p className="text-sm text-gray-400 mt-1">
              Starting with Western Ghats Sahyadri fort treks and built to scale to international alpine peaks.
            </p>
          </div>
          <button
            onClick={() => onNavigate('mountains')}
            className="text-sm font-medium text-emerald-400 hover:text-emerald-300 inline-flex items-center gap-1.5 cursor-pointer"
          >
            All Destinations <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {MOUNTAINS.map((m) => {
            const primaryTrail = m.trails[0];
            const cond = getEffectiveTrailCondition(m.id, primaryTrail.id, primaryTrail.defaultCondition);
            const liveActive = publicSessions.filter((s) => s.mountainId === m.id).length;
            return (
              <button
                key={m.id}
                onClick={() => onNavigate('mountain-detail', m.id)}
                className="group text-left bg-[#131917] hover:bg-[#18201D] border border-white/10 rounded-xl overflow-hidden transition-colors cursor-pointer flex flex-col"
              >
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#1B2320]">
                  <img
                    src={m.imageUrl}
                    alt={m.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-gray-200">
                    <span className="font-mono tabular-nums font-semibold">{m.elevationM} m</span>
                    <span>{m.country}</span>
                  </div>
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="font-display text-lg font-semibold text-white group-hover:text-emerald-300 transition-colors">
                      {m.name}
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {m.region} · {m.trails.length} mapped routes
                    </p>
                  </div>
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                    <ConditionText condition={cond} />
                    <span className="text-xs font-mono tabular-nums text-gray-400">
                      {liveActive} live GPS
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3 & 4. LIVE MOUNTAIN ACTIVITY + CURRENT WEATHER CONDITIONS */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 border-b border-white/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Live Mountain Activity */}
          <div className="lg:col-span-6 bg-[#131917] border border-white/10 rounded-xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl font-semibold text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-emerald-400" />
                  Live Mountain Activity
                </h2>
                <button
                  onClick={() => onNavigate('conditions')}
                  className="text-xs font-medium text-emerald-400 hover:text-emerald-300 cursor-pointer"
                >
                  Crowd Dashboard
                </button>
              </div>
              <p className="text-sm text-gray-400">
                Real-time active GPS sessions shared voluntarily by signed-in hikers, displayed separately from historical baseline ranges.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 border-y border-white/10 py-5">
              <div>
                <div className="text-xs text-gray-400">Verified Live GPS</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                  {publicSessions.length}
                </div>
                <div className="text-[11px] text-emerald-400 mt-0.5">Active shared sessions</div>
              </div>
              <div>
                <div className="text-xs text-gray-400">Active Trail Reports</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                  {reports.filter((r) => r.status !== 'Resolved' && r.status !== 'Expired').length}
                </div>
                <div className="text-[11px] text-amber-400 mt-0.5">Unresolved advisories</div>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <div className="text-xs text-gray-400">Monitored Peaks</div>
                <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                  {MOUNTAINS.length}
                </div>
                <div className="text-[11px] text-gray-400 mt-0.5">India & International</div>
              </div>
            </div>

            <div className="space-y-2.5 text-sm">
              {MOUNTAINS.slice(0, 3).map((m) => {
                const count = publicSessions.filter((s) => s.mountainId === m.id).length;
                return (
                  <div key={m.id} className="flex items-center justify-between py-1.5 border-b border-white/5 last:border-0">
                    <div>
                      <span className="text-gray-200 font-medium">{m.name}</span>
                      <span className="text-xs text-gray-500 ml-2">Baseline: {m.baselineDailyVisitorsRange}</span>
                    </div>
                    <span className="font-mono tabular-nums text-xs text-emerald-400">{count} live</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Current Weather Conditions (Live Open-Meteo) */}
          <div className="lg:col-span-6 bg-[#131917] border border-white/10 rounded-xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-xl font-semibold text-white flex items-center gap-2">
                  <CloudRain className="w-5 h-5 text-emerald-400" />
                  Current Weather Conditions
                </h2>
                <p className="text-xs text-gray-400 mt-1">
                  Sinhagad Fort (1,312 m) · Source: Open-Meteo Forecast API
                </p>
              </div>
              <button
                onClick={() => onNavigate('conditions')}
                className="text-xs font-medium text-emerald-400 hover:text-emerald-300 whitespace-nowrap cursor-pointer"
              >
                Full Weather
              </button>
            </div>

            {weatherLoading['sinhagad-fort'] && !primaryWeather ? (
              <div className="py-10 text-sm text-gray-400">Fetching live mountain weather from Open-Meteo...</div>
            ) : primaryWeather ? (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border-y border-white/10 py-5">
                  <div>
                    <div className="text-xs text-gray-400 flex items-center gap-1">
                      <Thermometer className="w-3.5 h-3.5" /> Temp
                    </div>
                    <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                      {primaryWeather.current.temperatureC.toFixed(1)}°C
                    </div>
                    <div className="text-[11px] text-gray-400">Feels {primaryWeather.current.feelsLikeC.toFixed(1)}°C</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400 flex items-center gap-1">
                      <Wind className="w-3.5 h-3.5" /> Wind
                    </div>
                    <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                      {primaryWeather.current.windSpeedKmh.toFixed(0)} km/h
                    </div>
                    <div className="text-[11px] text-gray-400">Dir {primaryWeather.current.windCardinal}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Rain Prob</div>
                    <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                      {primaryWeather.current.rainProbabilityPct}%
                    </div>
                    <div className="text-[11px] text-gray-400">{primaryWeather.current.rainfallMm} mm</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">Visibility</div>
                    <div className="text-2xl font-mono tabular-nums font-semibold text-white mt-1">
                      {primaryWeather.current.visibilityKm} km
                    </div>
                    <div className="text-[11px] text-gray-400">{primaryWeather.current.conditionLabel}</div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="text-gray-400">Is it a good time to hike? </span>
                    <span className="font-semibold text-emerald-400">{primaryWeather.goodTimeToHike.verdict}</span>
                  </div>
                  <span className="font-mono text-gray-500">
                    Updated {new Date(primaryWeather.fetchedAt).toLocaleTimeString()}
                  </span>
                </div>
              </>
            ) : (
              <div className="py-8 text-sm text-gray-400">
                Live weather preview unavailable right now. Open Live Conditions to retry.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 5 & 6. RECENT TRAIL HAZARDS + RECOMMENDED TRAILS */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 border-b border-white/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Recently Reported Trail Hazards */}
          <div className="lg:col-span-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-semibold text-white">Recently Reported Trail Hazards</h2>
              <button
                onClick={() => onNavigate('reports')}
                className="text-xs font-medium text-emerald-400 hover:text-emerald-300 cursor-pointer"
              >
                Report or Verify
              </button>
            </div>
            {activeReports.length === 0 ? (
              <div className="bg-[#131917] border border-white/10 rounded-xl p-6 text-sm text-gray-400 space-y-3">
                <p>No active unresolved hazard reports have been filed by hikers yet.</p>
                <button
                  onClick={() => onNavigate('reports')}
                  className="px-4 py-2 bg-[#1B2320] hover:bg-[#222D29] border border-white/15 rounded-lg text-xs font-medium text-white cursor-pointer"
                >
                  Submit First Trail Report
                </button>
              </div>
            ) : (
              <div className="divide-y divide-white/10 bg-[#131917] border border-white/10 rounded-xl">
                {activeReports.map((rep) => (
                  <div key={rep.id} className="p-4 flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-white flex items-center gap-2">
                        <AlertTriangle
                          className={`w-4 h-4 shrink-0 ${
                            rep.severity === 'Critical' || rep.severity === 'High' ? 'text-red-400' : 'text-amber-400'
                          }`}
                        />
                        {rep.category} · {rep.severity}
                      </div>
                      <p className="text-xs text-gray-300 line-clamp-2">{rep.description}</p>
                      <div className="text-[11px] text-gray-500">
                        {rep.mountainId} · {rep.status} · {rep.confirmCount} confirmation(s) ·{' '}
                        {new Date(rep.createdAtIso).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recommended Hiking Trails */}
          <div className="lg:col-span-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-semibold text-white">Recommended Hiking Routes</h2>
              <button
                onClick={() => onNavigate('map')}
                className="text-xs font-medium text-emerald-400 hover:text-emerald-300 cursor-pointer"
              >
                Open Live Map
              </button>
            </div>
            <div className="divide-y divide-white/10 bg-[#131917] border border-white/10 rounded-xl">
              {MOUNTAINS.slice(0, 3).map((m) => {
                const easiest = m.trails.find((t) => t.routeTag === 'Easiest') || m.trails[0];
                const cond = getEffectiveTrailCondition(m.id, easiest.id, easiest.defaultCondition);
                return (
                  <button
                    key={easiest.id}
                    onClick={() => onNavigate('mountain-detail', m.id)}
                    className="w-full text-left p-4 hover:bg-white/5 transition-colors flex items-center justify-between gap-4 cursor-pointer"
                  >
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-white">{easiest.name}</div>
                      <div className="text-xs text-gray-400">
                        {m.name} · {easiest.distanceKm} km · +{easiest.elevationGainM} m · {easiest.difficulty}
                      </div>
                    </div>
                    <ConditionText condition={cond} />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* 7. HOW TRAILGUARD WORKS */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 border-b border-white/10">
        <div className="max-w-2xl mb-10">
          <h2 className="font-display text-2xl sm:text-3xl font-semibold text-white">How TRAILGUARD Works</h2>
          <p className="text-sm text-gray-400 mt-2">
            Built to inform every decision before you leave the trailhead, while navigating ridges, and if an emergency arises.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <div className="text-xs font-mono text-emerald-400">01. Pre-Hike Intelligence</div>
            <h3 className="font-display text-lg font-semibold text-white flex items-center gap-2">
              <Brain className="w-4 h-4 text-emerald-400" /> Live Weather & AI Risk
            </h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Combines Open-Meteo mountain forecasts, slope gradient, and verified trail reports to evaluate whether conditions are favorable.
            </p>
          </div>
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <div className="text-xs font-mono text-emerald-400">02. Active Navigation</div>
            <h3 className="font-display text-lg font-semibold text-white flex items-center gap-2">
              <Compass className="w-4 h-4 text-emerald-400" /> Topographic GPS & Offline Packs
            </h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Track elevation gain, distance remaining, shelters, water tanks, and offline trail packages even when cellular reception drops.
            </p>
          </div>
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-3">
            <div className="text-xs font-mono text-emerald-400">03. Collective Safety</div>
            <h3 className="font-display text-lg font-semibold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-400" /> Crowd Verification & SOS
            </h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Report landslides or fallen trees with Gemini vision assistance, share consented group location, and trigger SOS coordinate alerts.
            </p>
          </div>
        </div>
      </section>

      {/* 8 & 9 & 10. SAFETY TIPS + COMMUNITY EXPERIENCES + EMERGENCY PREPAREDNESS */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Safety Tips */}
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-lg font-semibold text-white">Mountain Safety Essentials</h2>
            <ul className="space-y-2.5 text-sm text-gray-300">
              <li>Never choose a route solely because it is shorter—steep gullies like Nalichi Vaat carry severe fall risk.</li>
              <li>Download your mountain offline pack before entering valleys with weak cellular coverage.</li>
              <li>Unverified (Grey) trails mean unknown conditions, never assumed safe passage.</li>
              <li>Carry 2–3 liters of water, windproof shell, headlamp, and power bank on every ascent.</li>
            </ul>
          </div>

          {/* Community Hiking Experiences */}
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" /> Community Logs
                </h2>
                <button
                  onClick={() => onNavigate('community')}
                  className="text-xs text-emerald-400 hover:text-emerald-300 cursor-pointer"
                >
                  Open Community
                </button>
              </div>
              {communityPosts.length === 0 ? (
                <p className="text-sm text-gray-400">
                  Share your trail conditions, trek notes, and group plans with fellow hikers in the Community hub.
                </p>
              ) : (
                <div className="space-y-3">
                  {communityPosts.slice(0, 2).map((p) => (
                    <div key={p.id} className="border-b border-white/10 pb-2.5 last:border-0">
                      <div className="text-sm font-medium text-white">{p.title}</div>
                      <div className="text-xs text-gray-400 mt-0.5">
                        {p.authorName} · {p.mountainId} · Rating {p.rating}/5
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={() => onNavigate('community')}
              className="w-full py-2 text-xs font-medium text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg cursor-pointer"
            >
              Browse & Join Hiking Groups
            </button>
          </div>

          {/* Emergency Preparedness */}
          <div className="bg-[#181212] border border-red-500/25 rounded-xl p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <h2 className="font-display text-lg font-semibold text-white flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-red-400" /> Emergency Preparedness
              </h2>
              <p className="text-sm text-gray-300 leading-relaxed">
                Configure trusted emergency contacts in your profile before every trek. In an emergency, TRAILGUARD prepares GPS SOS alerts, offline survival protocols, and direct emergency call links.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => onNavigate('emergency')}
                className="flex-1 py-2.5 px-4 bg-red-600 hover:bg-red-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Open SOS Center
              </button>
              <button
                onClick={() => onNavigate('ai-risk')}
                className="py-2.5 px-4 bg-white/5 hover:bg-white/10 border border-white/15 text-gray-200 text-xs font-medium rounded-lg transition-colors cursor-pointer"
              >
                AI Risk Check
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
