import React, { useState } from 'react';
import { Award, CloudOff, Download, Navigation, RefreshCw, Trash2, Wifi } from 'lucide-react';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';
import { PageRoute } from '../types/trailguard';

interface DashboardPageProps {
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { user, publicProfile, privateProfile, signInWithGoogle, isAdmin } = useAuth();
  const {
    isOnline,
    mySessions,
    offlinePacks,
    queuedOfflineReports,
    gpsCoordinates,
    downloadMountainOffline,
    deleteMountainOffline,
    syncQueuedOfflineReports,
  } = useTrailData();

  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  const hikesCompleted = publicProfile?.hikesCompleted ?? 0;
  const totalDist = publicProfile?.totalDistanceKm ?? 0;
  const totalElev = publicProfile?.totalElevationM ?? 0;

  const badges = [
    { name: 'First Ascent', unlocked: hikesCompleted >= 1, req: 'Complete 1 GPS hike' },
    { name: 'Ridge Runner', unlocked: totalDist >= 10, req: 'Log 10+ km on trail' },
    { name: 'Vertical 1K', unlocked: totalElev >= 1000, req: 'Gain 1,000+ m elevation' },
    { name: 'Offline Prepared', unlocked: offlinePacks.length >= 1, req: 'Save 1 offline mountain pack' },
  ];

  const handleSync = async () => {
    const count = await syncQueuedOfflineReports();
    setSyncMessage(count > 0 ? `Synced ${count} queued offline report(s) to Firestore.` : 'No reports synced (check sign-in or connectivity).');
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">My Hiking Dashboard & Offline Mode</h1>
          <p className="text-sm text-gray-400 mt-1.5">
            Track your personal stats, route history, saved mountains, and offline expedition packs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => onNavigate('profile')}
            className="px-3.5 py-2 bg-[#131917] hover:bg-white/5 border border-white/15 rounded-lg text-xs text-gray-200 cursor-pointer"
          >
            Profile & Contacts
          </button>
          {isAdmin && (
            <button
              onClick={() => onNavigate('admin')}
              className="px-3.5 py-2 bg-amber-950/50 hover:bg-amber-900/60 border border-amber-500/35 rounded-lg text-xs text-amber-200 cursor-pointer"
            >
              Admin Console
            </button>
          )}
          <button
            onClick={() => onNavigate('map')}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
          >
            <Navigation className="w-3.5 h-3.5" /> Start New Hike
          </button>
        </div>
      </div>

      {!user && (
        <div className="bg-[#131917] border border-white/10 rounded-xl p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-white">Sign In to Sync Personal Stats & Route History</h2>
            <p className="text-xs text-gray-400 mt-1">
              Offline mountain packs and last-known GPS remain accessible locally even before signing in.
            </p>
          </div>
          <button
            onClick={signInWithGoogle}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer shrink-0"
          >
            Sign In with Google
          </button>
        </div>
      )}

      {/* Personal Stats & Badges */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
          <div className="text-xs text-gray-400">Hikes Completed</div>
          <div className="text-3xl font-mono tabular-nums font-bold text-white mt-1">{hikesCompleted}</div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
          <div className="text-xs text-gray-400">Total Distance</div>
          <div className="text-3xl font-mono tabular-nums font-bold text-white mt-1">{totalDist.toFixed(1)} km</div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
          <div className="text-xs text-gray-400">Total Elevation Gain</div>
          <div className="text-3xl font-mono tabular-nums font-bold text-white mt-1">+{totalElev} m</div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-5">
          <div className="text-xs text-gray-400">Connectivity</div>
          <div className="text-sm font-semibold mt-2 flex items-center gap-2">
            {isOnline ? (
              <span className="text-emerald-400 inline-flex items-center gap-1.5">
                <Wifi className="w-4 h-4" /> Online Sync Active
              </span>
            ) : (
              <span className="text-amber-400 inline-flex items-center gap-1.5">
                <CloudOff className="w-4 h-4" /> Offline Mode
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Achievement Badges */}
      <section className="space-y-3">
        <h2 className="font-display text-xl font-semibold text-white flex items-center gap-2">
          <Award className="w-5 h-5 text-emerald-400" /> Hiking Achievement Badges
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {badges.map((b) => (
            <div
              key={b.name}
              className={`border rounded-xl p-4 ${
                b.unlocked
                  ? 'bg-emerald-950/30 border-emerald-500/35 text-white'
                  : 'bg-[#131917] border-white/10 text-gray-500'
              }`}
            >
              <div className="text-sm font-semibold">{b.name}</div>
              <div className="text-xs mt-1">{b.req}</div>
              <div className="text-[11px] font-mono mt-2">
                {b.unlocked ? 'Unlocked' : 'Locked'}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Offline Hiking Mode Manager */}
      <section className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 className="font-display text-xl font-semibold text-white">Offline Hiking Mode</h2>
            <p className="text-xs text-gray-400 mt-1">
              Works offline: route waypoints, shelters, water sources, emergency instructions, cached reports, and report queueing. Requires internet: live Open-Meteo weather, AI risk analysis, map tile streaming outside browser cache, and cloud sync.
            </p>
          </div>
          {queuedOfflineReports.length > 0 && (
            <button
              onClick={handleSync}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg cursor-pointer shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Sync {queuedOfflineReports.length} Queued Report(s)
            </button>
          )}
        </div>

        {syncMessage && <p className="text-xs text-emerald-400">{syncMessage}</p>}

        {/* Quick Download Buttons */}
        <div className="flex flex-wrap gap-2">
          {MOUNTAINS.map((m) => {
            const saved = offlinePacks.some((p) => p.mountainId === m.id);
            return (
              <button
                key={m.id}
                onClick={() => downloadMountainOffline(m.id)}
                className="inline-flex items-center gap-1.5 px-3 py-2 bg-black/40 hover:bg-white/5 border border-white/15 rounded-lg text-xs text-gray-200 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                {saved ? `Update ${m.name} Pack` : `Download ${m.name}`}
              </button>
            );
          })}
        </div>

        {/* Saved Offline Packs */}
        {offlinePacks.length === 0 ? (
          <p className="text-xs text-gray-400">
            No offline mountain packs saved yet. Download any mountain above before heading to low-signal areas.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {offlinePacks.map((pack) => (
              <div key={pack.mountainId} className="bg-black/35 border border-white/10 rounded-lg p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold text-white">{pack.mountainName}</div>
                  <button
                    onClick={() => deleteMountainOffline(pack.mountainId)}
                    aria-label={`Remove ${pack.mountainName} offline pack`}
                    className="text-gray-500 hover:text-red-400 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-xs text-gray-400">
                  {pack.mountain.trails.length} routes · {pack.mountain.pois.length} POIs · {pack.cachedReports.length} cached hazard report(s)
                </div>
                <div className="text-[11px] font-mono text-gray-500">
                  Saved {new Date(pack.savedAtIso).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        )}

        {gpsCoordinates && (
          <div className="text-xs text-gray-300 border-t border-white/10 pt-3 font-mono">
            Last Known GPS Stored Offline: {gpsCoordinates.lat.toFixed(5)}, {gpsCoordinates.lng.toFixed(5)} (
            {new Date(gpsCoordinates.timestampIso).toLocaleString()})
          </div>
        )}
      </section>

      {/* Route History & Saved Mountains */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-xl font-semibold text-white">My Hiking Route History</h2>
          {mySessions.length === 0 ? (
            <p className="text-xs text-gray-400">
              No GPS hiking sessions recorded yet. Start a session from the Live Map to log distance and elevation.
            </p>
          ) : (
            <div className="divide-y divide-white/10">
              {mySessions.map((s) => (
                <div key={s.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="font-semibold text-white">{getMountainById(s.mountainId).name}</div>
                    <div className="text-gray-400">
                      Status: {s.status} · {new Date(s.startedAtIso).toLocaleString()}
                    </div>
                  </div>
                  <div className="text-right font-mono tabular-nums text-gray-200">
                    <div>{s.distanceTravelledKm.toFixed(2)} km</div>
                    <div className="text-emerald-400">+{s.elevationGainedM} m</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-5 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-xl font-semibold text-white">Saved Mountains</h2>
          {!privateProfile || privateProfile.savedMountainIds.length === 0 ? (
            <p className="text-xs text-gray-400">No saved mountains yet.</p>
          ) : (
            <div className="space-y-2">
              {privateProfile.savedMountainIds.map((id) => {
                const m = getMountainById(id);
                return (
                  <button
                    key={id}
                    onClick={() => onNavigate('mountain-detail', id)}
                    className="w-full text-left p-3 bg-black/30 hover:bg-white/5 border border-white/10 rounded-lg flex items-center justify-between cursor-pointer"
                  >
                    <span className="text-sm font-medium text-white">{m.name}</span>
                    <span className="text-xs font-mono text-emerald-400">{m.elevationM} m</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
