import React, { useMemo, useState } from 'react';
import {
  Clock,
  Compass,
  LocateFixed,
  Navigation,
  Pause,
  Play,
  ShieldAlert,
  Square,
  TrendingUp,
} from 'lucide-react';
import { HAZARD_CATEGORIES, MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';
import { LiveMountainMap } from '../components/LiveMountainMap';
import { HazardCategory, PageRoute, ReportSeverity } from '../types/trailguard';

interface LiveMapPageProps {
  initialMountainId: string;
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

function formatDuration(totalSec: number): string {
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function LiveMapPage({ initialMountainId, onNavigate }: LiveMapPageProps) {
  const { user, signInWithGoogle } = useAuth();
  const {
    reports,
    publicSessions,
    activeSession,
    gpsCoordinates,
    gpsPermissionStatus,
    gpsError,
    getEffectiveTrailCondition,
    startHikingSession,
    pauseHikingSession,
    resumeHikingSession,
    endHikingSession,
    requestSingleGpsFix,
    submitTrailReport,
  } = useTrailData();

  const [selectedMountainId, setSelectedMountainId] = useState(initialMountainId || MOUNTAINS[0].id);
  const mountain = getMountainById(selectedMountainId);
  const [selectedTrailId, setSelectedTrailId] = useState(mountain.trails[0].id);
  const [shareMode, setShareMode] = useState<'private' | 'group' | 'public'>('private');
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Map-pin quick hazard modal state
  const [pinCoords, setPinCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [pinCategory, setPinCategory] = useState<HazardCategory>('Slippery trails');
  const [pinSeverity, setPinSeverity] = useState<ReportSeverity>('Moderate');
  const [pinDesc, setPinDesc] = useState('');
  const [submittingPin, setSubmittingPin] = useState(false);

  const selectedTrail = useMemo(
    () => mountain.trails.find((t) => t.id === selectedTrailId) || mountain.trails[0],
    [mountain, selectedTrailId]
  );

  const handleMountainChange = (id: string) => {
    setSelectedMountainId(id);
    const nextM = getMountainById(id);
    setSelectedTrailId(nextM.trails[0].id);
  };

  const distanceRemainingKm = activeSession
    ? Math.max(0, Number((selectedTrail.distanceKm - activeSession.distanceTravelledKm).toFixed(2)))
    : selectedTrail.distanceKm;

  const etaMinutes = activeSession
    ? Math.max(5, Math.round((distanceRemainingKm / Math.max(0.5, selectedTrail.distanceKm)) * selectedTrail.estimatedDurationMin))
    : selectedTrail.estimatedDurationMin;

  const handleStartHike = async () => {
    setActionError(null);
    setActionMsg(null);
    if (!user) {
      await signInWithGoogle();
      return;
    }
    try {
      await startHikingSession(mountain.id, selectedTrail.id, shareMode);
      setActionMsg('Live GPS session started. Inactive sessions auto-expire after 2 hours.');
    } catch (e: any) {
      setActionError(e?.message || 'Unable to start GPS session.');
    }
  };

  const handlePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinCoords || pinDesc.trim().length < 5) return;
    setSubmittingPin(true);
    setActionError(null);
    try {
      const res = await submitTrailReport({
        mountainId: mountain.id,
        trailId: selectedTrail.id,
        category: pinCategory,
        severity: pinSeverity,
        description: pinDesc,
        lat: pinCoords.lat,
        lng: pinCoords.lng,
      });
      setPinCoords(null);
      setPinDesc('');
      setActionMsg(
        res.queuedOffline
          ? 'Offline: hazard report queued locally and will sync when connectivity returns.'
          : 'Hazard marker published to live mountain map.'
      );
    } catch (err: any) {
      setActionError(err?.message || 'Unable to submit report.');
    } finally {
      setSubmittingPin(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Workspace Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#131917] border border-white/10 rounded-xl p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label className="block text-[11px] text-gray-400 mb-1">Mountain</label>
            <select
              value={mountain.id}
              onChange={(e) => handleMountainChange(e.target.value)}
              className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              {MOUNTAINS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.elevationM} m)
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[11px] text-gray-400 mb-1">Target Route</label>
            <select
              value={selectedTrail.id}
              onChange={(e) => setSelectedTrailId(e.target.value)}
              className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              {mountain.trails.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.distanceKm} km)
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[11px] text-gray-400 mb-1">Location Privacy</label>
            <select
              value={shareMode}
              onChange={(e) => setShareMode(e.target.value as 'private' | 'group' | 'public')}
              disabled={Boolean(activeSession)}
              className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 disabled:opacity-50"
            >
              <option value="private">Private (Only Me)</option>
              <option value="group">Hiking Group</option>
              <option value="public">Public Activity Count</option>
            </select>
          </div>
        </div>

        {/* GPS Session Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => requestSingleGpsFix()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-[#1A221F] hover:bg-[#222C28] border border-white/15 rounded-lg text-xs text-gray-200 cursor-pointer"
          >
            <LocateFixed className="w-3.5 h-3.5 text-sky-400" />
            {gpsPermissionStatus === 'requesting' ? 'Locating...' : 'Locate GPS'}
          </button>

          {!activeSession ? (
            <button
              type="button"
              onClick={handleStartHike}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              {user ? 'Start Hiking' : 'Sign In & Start Hiking'}
            </button>
          ) : (
            <>
              {activeSession.status === 'active' ? (
                <button
                  type="button"
                  onClick={pauseHikingSession}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  <Pause className="w-3.5 h-3.5" /> Pause Hiking
                </button>
              ) : (
                <button
                  type="button"
                  onClick={resumeHikingSession}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" /> Resume Hiking
                </button>
              )}
              <button
                type="button"
                onClick={endHikingSession}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                <Square className="w-3.5 h-3.5" /> End Hiking
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => onNavigate('emergency')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-red-950/70 hover:bg-red-900 border border-red-500/40 text-red-200 text-xs font-semibold rounded-lg cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" /> SOS
          </button>
        </div>
      </div>

      {/* Status & Error Banners */}
      {gpsError && (
        <div className="bg-amber-950/50 border border-amber-500/30 rounded-lg px-4 py-2.5 text-xs text-amber-200">
          GPS Notice: {gpsError}. Ensure browser location permission is granted to record live track coordinates.
        </div>
      )}
      {actionError && (
        <div className="bg-red-950/60 border border-red-500/35 rounded-lg px-4 py-2.5 text-xs text-red-200">
          {actionError}
        </div>
      )}
      {actionMsg && (
        <div className="bg-emerald-950/60 border border-emerald-500/35 rounded-lg px-4 py-2.5 text-xs text-emerald-200">
          {actionMsg}
        </div>
      )}

      {/* Telemetry Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#131917] border border-white/10 rounded-xl p-3.5">
          <div className="text-[11px] text-gray-400 flex items-center gap-1"><Navigation className="w-3 h-3" /> Travelled</div>
          <div className="text-lg font-mono tabular-nums font-semibold text-white mt-1">
            {(activeSession?.distanceTravelledKm ?? 0).toFixed(2)} km
          </div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-3.5">
          <div className="text-[11px] text-gray-400 flex items-center gap-1"><Compass className="w-3 h-3" /> Remaining</div>
          <div className="text-lg font-mono tabular-nums font-semibold text-white mt-1">
            {distanceRemainingKm.toFixed(2)} km
          </div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-3.5">
          <div className="text-[11px] text-gray-400 flex items-center gap-1"><Clock className="w-3 h-3" /> Duration</div>
          <div className="text-lg font-mono tabular-nums font-semibold text-white mt-1">
            {formatDuration(activeSession?.durationSec ?? 0)}
          </div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-3.5">
          <div className="text-[11px] text-gray-400 flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Elev Gain</div>
          <div className="text-lg font-mono tabular-nums font-semibold text-white mt-1">
            +{activeSession?.elevationGainedM ?? 0} m
          </div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-3.5">
          <div className="text-[11px] text-gray-400">Est. Time Left</div>
          <div className="text-lg font-mono tabular-nums font-semibold text-white mt-1">{etaMinutes} min</div>
        </div>
        <div className="bg-[#131917] border border-white/10 rounded-xl p-3.5">
          <div className="text-[11px] text-gray-400">GPS Fix</div>
          <div className="text-xs font-mono tabular-nums text-emerald-400 mt-1.5 truncate">
            {gpsCoordinates ? `${gpsCoordinates.lat.toFixed(4)}, ${gpsCoordinates.lng.toFixed(4)}` : 'Awaiting GPS'}
          </div>
        </div>
      </div>

      {/* Full-Scale Interactive Map */}
      <LiveMountainMap
        mountain={mountain}
        reports={reports}
        publicSessions={publicSessions}
        userGps={gpsCoordinates}
        getTrailCondition={getEffectiveTrailCondition}
        onSelectMapCoords={(lat, lng) => setPinCoords({ lat, lng })}
        heightClass="h-[580px]"
      />

      {/* Quick Hazard Pin Modal */}
      {pinCoords && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <form
            onSubmit={handlePinSubmit}
            className="w-full max-w-md bg-[#131917] border border-white/15 rounded-xl p-6 space-y-4 shadow-2xl"
          >
            <h3 className="font-display text-lg font-semibold text-white">Report Trail Hazard at Pin</h3>
            <p className="text-xs font-mono text-gray-400">
              Coordinates: {pinCoords.lat}, {pinCoords.lng} · {mountain.name}
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Category</label>
                <select
                  value={pinCategory}
                  onChange={(e) => setPinCategory(e.target.value as HazardCategory)}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {HAZARD_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Severity</label>
                <select
                  value={pinSeverity}
                  onChange={(e) => setPinSeverity(e.target.value as ReportSeverity)}
                  className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {(['Low', 'Moderate', 'High', 'Critical'] as ReportSeverity[]).map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Description (min 5 chars)</label>
              <textarea
                required
                minLength={5}
                rows={3}
                value={pinDesc}
                onChange={(e) => setPinDesc(e.target.value)}
                placeholder="Describe exact trail obstruction, visibility, or surface condition..."
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPinCoords(null)}
                className="px-4 py-2 text-xs text-gray-300 bg-white/5 hover:bg-white/10 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submittingPin}
                className="px-4 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-lg cursor-pointer disabled:opacity-50"
              >
                {submittingPin ? 'Submitting...' : 'Submit Hazard Report'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
