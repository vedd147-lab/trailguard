import React, { useEffect, useState } from 'react';
import { AlertTriangle, Brain, Camera, CheckCircle2, ShieldAlert, Users } from 'lucide-react';
import { MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { AiCrowdResult, AiRiskResult, AiVisionResult } from '../types/trailguard';

interface AiRiskPageProps {
  initialMountainId: string;
}

export function AiRiskPage({ initialMountainId }: AiRiskPageProps) {
  const { weatherByMountain, fetchWeatherForMountain, reports, publicSessions } = useTrailData();
  const [selectedId, setSelectedId] = useState(initialMountainId || MOUNTAINS[0].id);
  const [activeTab, setActiveTab] = useState<'risk' | 'vision' | 'crowd'>('risk');
  const mountain = getMountainById(selectedId);

  const [riskResult, setRiskResult] = useState<AiRiskResult | null>(null);
  const [riskLoading, setRiskLoading] = useState(false);
  const [riskError, setRiskError] = useState<string | null>(null);

  const [visionImage, setVisionImage] = useState<string | null>(null);
  const [visionResult, setVisionResult] = useState<AiVisionResult | null>(null);
  const [visionVerified, setVisionVerified] = useState<'pending' | 'confirmed' | 'corrected'>('pending');
  const [visionLoading, setVisionLoading] = useState(false);
  const [visionError, setVisionError] = useState<string | null>(null);

  const [crowdResult, setCrowdResult] = useState<AiCrowdResult | null>(null);
  const [crowdLoading, setCrowdLoading] = useState(false);
  const [crowdError, setCrowdError] = useState<string | null>(null);

  useEffect(() => {
    fetchWeatherForMountain(mountain.id);
  }, [mountain.id, fetchWeatherForMountain]);

  const weather = weatherByMountain[mountain.id];
  const recentReports = reports.filter(
    (r) => r.mountainId === mountain.id && r.status !== 'Resolved' && r.status !== 'Expired'
  );
  const activeSessionsHere = publicSessions.filter((s) => s.mountainId === mountain.id).length;

  const runRiskAnalysis = async () => {
    setRiskLoading(true);
    setRiskError(null);
    try {
      const res = await fetch('/api/ai/risk-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mountainName: mountain.name,
          elevationM: mountain.elevationM,
          terrain: mountain.terrainOverview,
          difficulty: mountain.trails.map((t) => `${t.name}: ${t.difficulty}`).join(', '),
          weather: weather?.current || null,
          recentReports: recentReports.map((r) => ({
            category: r.category,
            severity: r.severity,
            status: r.status,
            description: r.description,
          })),
          historicalHazards: mountain.historicalHazards,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Risk analysis failed.');
      setRiskResult(data);
    } catch (err: any) {
      setRiskError(err?.message || 'Unable to generate AI risk analysis.');
    } finally {
      setRiskLoading(false);
    }
  };

  const handleVisionUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVisionError(null);
    setVisionResult(null);
    setVisionVerified('pending');
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = String(reader.result || '');
      setVisionImage(dataUrl);
      setVisionLoading(true);
      try {
        const res = await fetch('/api/ai/hazard-vision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: dataUrl,
            mimeType: file.type,
            mountainName: mountain.name,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Vision classification failed.');
        setVisionResult(data);
      } catch (err: any) {
        setVisionError(err?.message || 'Unable to classify image.');
      } finally {
        setVisionLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const runCrowdForecast = async () => {
    setCrowdLoading(true);
    setCrowdError(null);
    try {
      const dayOfWeek = new Date().toLocaleDateString('en-US', { weekday: 'long' });
      const res = await fetch('/api/ai/crowd-forecast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mountainName: mountain.name,
          activeSessionsCount: activeSessionsHere,
          historicalBaselineDaily: mountain.baselineDailyVisitorsRange,
          dayOfWeek,
          weatherSummary: weather?.current ? `${weather.current.conditionLabel}, ${weather.current.temperatureC}°C` : 'Unknown',
          trails: mountain.trails.map((t) => ({ name: t.name, routeTag: t.routeTag, difficulty: t.difficulty })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Crowd intelligence forecast failed.');
      setCrowdResult(data);
    } catch (err: any) {
      setCrowdError(err?.message || 'Unable to generate crowd intelligence.');
    } finally {
      setCrowdLoading(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">AI Mountain Risk Intelligence</h1>
          <p className="text-sm text-gray-400 mt-1.5">
            Advisory intelligence combining Open-Meteo weather, terrain profiles, trail reports, and multimodal Gemini vision.
          </p>
        </div>
        <select
          value={selectedId}
          onChange={(e) => {
            setSelectedId(e.target.value);
            setRiskResult(null);
            setCrowdResult(null);
          }}
          className="bg-[#131917] border border-white/15 rounded-lg px-3.5 py-2 text-xs text-white"
        >
          {MOUNTAINS.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} ({m.elevationM} m)
            </option>
          ))}
        </select>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex flex-wrap gap-2 p-1 bg-[#131917] border border-white/10 rounded-xl w-fit">
        <button
          onClick={() => setActiveTab('risk')}
          className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer ${
            activeTab === 'risk' ? 'bg-emerald-600 text-white' : 'text-gray-300 hover:text-white'
          }`}
        >
          <Brain className="w-4 h-4" /> A. Trail Risk Intelligence
        </button>
        <button
          onClick={() => setActiveTab('vision')}
          className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer ${
            activeTab === 'vision' ? 'bg-emerald-600 text-white' : 'text-gray-300 hover:text-white'
          }`}
        >
          <Camera className="w-4 h-4" /> B. Hazard Vision Classifier
        </button>
        <button
          onClick={() => setActiveTab('crowd')}
          className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg cursor-pointer ${
            activeTab === 'crowd' ? 'bg-emerald-600 text-white' : 'text-gray-300 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" /> C. Crowd Intelligence
        </button>
      </div>

      {/* Disclaimer Banner */}
      <div className="bg-amber-950/35 border border-amber-500/25 rounded-xl px-4 py-3 text-xs text-amber-200 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <span>
          Experimental AI advisory output — never treat algorithmic risk scores or computer vision predictions as a certified safety clearance. Always verify local forest department advisories.
        </span>
      </div>

      {/* TAB A: TRAIL RISK INTELLIGENCE */}
      {activeTab === 'risk' && (
        <div className="space-y-6">
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="font-display text-xl font-semibold text-white">
                Evaluate {mountain.name} Trail Risk
              </h2>
              <p className="text-xs text-gray-400">
                Inputs: {weather ? `${weather.current.temperatureC}°C, ${weather.current.windSpeedKmh} km/h wind, ${weather.current.rainProbabilityPct}% rain prob` : 'Weather loading'} · {recentReports.length} active hazard report(s) · {mountain.elevationM} m elevation
              </p>
            </div>
            <button
              onClick={runRiskAnalysis}
              disabled={riskLoading}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer disabled:opacity-50 shrink-0"
            >
              {riskLoading ? 'Analyzing Inputs...' : 'Run Trail Risk Assessment'}
            </button>
          </div>

          {riskError && (
            <div className="bg-red-950/50 border border-red-500/30 rounded-xl p-4 text-xs text-red-200">{riskError}</div>
          )}

          {riskResult && (
            <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <div className="text-xs text-gray-400">Estimated Risk Category</div>
                  <div
                    className={`text-3xl font-display font-bold mt-1 ${
                      riskResult.riskLevel === 'Critical' || riskResult.riskLevel === 'High'
                        ? 'text-red-400'
                        : riskResult.riskLevel === 'Moderate'
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {riskResult.riskLevel} Risk · {riskResult.hikeRecommendation}
                  </div>
                </div>
                <div className="text-xs font-mono text-gray-500">
                  Model: {riskResult.model} · {new Date(riskResult.generatedAt).toLocaleTimeString()}
                </div>
              </div>

              <p className="text-sm text-gray-200 leading-relaxed">{riskResult.summary}</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {riskResult.factors.map((f, idx) => (
                  <div key={idx} className="bg-black/30 border border-white/10 rounded-lg p-4 space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="text-white">{f.factor}</span>
                      <span
                        className={
                          f.impact === 'Elevated Risk'
                            ? 'text-red-400'
                            : f.impact === 'Caution'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }
                      >
                        {f.impact}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400">{f.detail}</p>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-semibold text-gray-300">Recommended Gear & Precautions</h3>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-300">
                  {riskResult.gearChecklist.map((g, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{g}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <p className="text-[11px] text-gray-500 border-t border-white/10 pt-3">
                {riskResult.uncertaintyDisclaimer}
              </p>
            </div>
          )}
        </div>
      )}

      {/* TAB B: HAZARD COMPUTER VISION */}
      {activeTab === 'vision' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-xl font-semibold text-white">Upload Trail Photograph</h2>
            <p className="text-xs text-gray-400">
              Detects fallen trees, rockfalls, landslides, damaged bridges, flooding, muddy paths, or poor visibility. Human verification is required.
            </p>
            <label className="flex flex-col items-center justify-center gap-2 p-8 bg-[#0B0E0D] hover:bg-white/5 border border-dashed border-white/20 rounded-xl text-xs text-gray-300 cursor-pointer">
              <Camera className="w-6 h-6 text-emerald-400" />
              <span>Select JPEG, PNG, or WebP trail photograph</span>
              <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleVisionUpload} className="hidden" />
            </label>
            {visionImage && (
              <img
                src={visionImage}
                alt="Uploaded trail photo"
                className="w-full h-56 object-cover rounded-lg border border-white/10"
              />
            )}
          </div>

          <div className="lg:col-span-7 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-xl font-semibold text-white">Vision Classification Output</h2>
            {visionLoading && <p className="text-sm text-emerald-400">Running multimodal hazard inspection...</p>}
            {visionError && <p className="text-sm text-red-400">{visionError}</p>}
            {!visionLoading && !visionResult && !visionError && (
              <p className="text-sm text-gray-400 py-8">
                Upload a trail photograph on the left to classify terrain hazards.
              </p>
            )}
            {visionResult && (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div>
                    <div className="text-xs text-gray-400">Detected Category</div>
                    <div className="text-2xl font-display font-bold text-white mt-0.5">
                      {visionResult.detectedCategory} · {visionResult.severity}
                    </div>
                  </div>
                  <span className="text-xs text-amber-300">{visionResult.confidenceLabel}</span>
                </div>
                <p className="text-sm text-gray-200">{visionResult.observations}</p>
                <div className="bg-black/30 border border-white/10 rounded-lg p-3.5 text-xs text-gray-300">
                  <strong className="text-white">Recommended Action:</strong> {visionResult.recommendedAction}
                </div>

                <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-gray-400">
                    Human Verification Status:{' '}
                    <strong className="text-white capitalize">{visionVerified}</strong>
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setVisionVerified('confirmed')}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg cursor-pointer"
                    >
                      Verify Classification
                    </button>
                    <button
                      onClick={() => setVisionVerified('corrected')}
                      className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/15 text-gray-200 text-xs font-medium rounded-lg cursor-pointer"
                    >
                      Flag as False Positive
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB C: CROWD INTELLIGENCE */}
      {activeTab === 'crowd' && (
        <div className="space-y-6">
          <div className="bg-[#131917] border border-white/10 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="font-display text-xl font-semibold text-white">
                {mountain.name} Experimental Crowd Projection
              </h2>
              <p className="text-xs text-gray-400">
                Current shared GPS sessions: {activeSessionsHere} · Historical baseline: {mountain.baselineDailyVisitorsRange}
              </p>
            </div>
            <button
              onClick={runCrowdForecast}
              disabled={crowdLoading}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer disabled:opacity-50"
            >
              {crowdLoading ? 'Forecasting...' : 'Generate Crowd Forecast'}
            </button>
          </div>

          {crowdError && (
            <div className="bg-red-950/50 border border-red-500/30 rounded-xl p-4 text-xs text-red-200">{crowdError}</div>
          )}

          {crowdResult && (
            <div className="bg-[#131917] border border-white/10 rounded-xl p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-b border-white/10 pb-4">
                <div>
                  <div className="text-xs text-gray-400">Expected Density</div>
                  <div className="text-xl font-display font-bold text-white mt-1">{crowdResult.expectedDensity}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Peak Visiting Period</div>
                  <div className="text-base font-mono text-amber-300 mt-1">{crowdResult.peakWindow}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-400">Recommended Arrival</div>
                  <div className="text-base font-mono text-emerald-400 mt-1">{crowdResult.recommendedArrivalWindow}</div>
                </div>
              </div>
              <p className="text-sm text-gray-200">{crowdResult.bottleneckNotes}</p>
              <p className="text-xs text-gray-500 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                {crowdResult.experimentalNote}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
