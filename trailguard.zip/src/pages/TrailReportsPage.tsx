import React, { useMemo, useState } from 'react';
import { AlertTriangle, Camera, CheckCircle2, LocateFixed, Sparkles } from 'lucide-react';
import { HAZARD_CATEGORIES, MOUNTAINS, getMountainById } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { useAuth } from '../context/AuthContext';
import { AiVisionResult, HazardCategory, ReportSeverity, ReportStatus } from '../types/trailguard';

interface TrailReportsPageProps {
  initialMountainId: string;
}

export function TrailReportsPage({ initialMountainId }: TrailReportsPageProps) {
  const { user, signInWithGoogle } = useAuth();
  const {
    reports,
    gpsCoordinates,
    requestSingleGpsFix,
    submitTrailReport,
    confirmTrailReport,
  } = useTrailData();

  const [filterMountain, setFilterMountain] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('active');

  // Form State
  const [mountainId, setMountainId] = useState(initialMountainId || MOUNTAINS[0].id);
  const selectedMountain = getMountainById(mountainId);
  const [trailId, setTrailId] = useState(selectedMountain.trails[0].id);
  const [category, setCategory] = useState<HazardCategory>('Slippery trails');
  const [severity, setSeverity] = useState<ReportSeverity>('Moderate');
  const [description, setDescription] = useState('');
  const [lat, setLat] = useState<string>(String(selectedMountain.lat));
  const [lng, setLng] = useState<string>(String(selectedMountain.lng));
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [visionResult, setVisionResult] = useState<AiVisionResult | null>(null);
  const [visionLoading, setVisionLoading] = useState(false);
  const [visionError, setVisionError] = useState<string | null>(null);
  const [submitMessage, setSubmitMessage] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const filteredReports = useMemo(() => {
    return reports.filter((r) => {
      if (filterMountain !== 'all' && r.mountainId !== filterMountain) return false;
      if (filterStatus === 'active' && (r.status === 'Resolved' || r.status === 'Expired')) return false;
      if (filterStatus === 'resolved' && r.status !== 'Resolved' && r.status !== 'Expired') return false;
      return true;
    });
  }, [reports, filterMountain, filterStatus]);

  const handleMountainSelect = (id: string) => {
    setMountainId(id);
    const m = getMountainById(id);
    setTrailId(m.trails[0].id);
    setLat(String(m.lat));
    setLng(String(m.lng));
  };

  const handleUseCurrentGps = async () => {
    const fix = await requestSingleGpsFix();
    if (fix) {
      setLat(fix.lat.toFixed(5));
      setLng(fix.lng.toFixed(5));
    } else if (gpsCoordinates) {
      setLat(gpsCoordinates.lat.toFixed(5));
      setLng(gpsCoordinates.lng.toFixed(5));
    }
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVisionError(null);
    setVisionResult(null);

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = String(reader.result || '');
      setPhotoPreview(dataUrl);
      setVisionLoading(true);
      try {
        const res = await fetch('/api/ai/hazard-vision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: dataUrl,
            mimeType: file.type,
            mountainName: selectedMountain.name,
            notes: description,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Vision classification unavailable');
        setVisionResult(data);
        if (HAZARD_CATEGORIES.includes(data.detectedCategory)) {
          setCategory(data.detectedCategory);
        }
        setSeverity(data.severity);
        if (!description.trim()) {
          setDescription(data.observations);
        }
      } catch (err: any) {
        setVisionError(err?.message || 'Unable to classify photo right now.');
      } finally {
        setVisionLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setSubmitMessage(null);
    if (!user && navigator.onLine) {
      await signInWithGoogle();
      return;
    }
    const parsedLat = Number(lat);
    const parsedLng = Number(lng);
    if (!Number.isFinite(parsedLat) || !Number.isFinite(parsedLng)) {
      setSubmitError('Please enter valid numeric GPS coordinates.');
      return;
    }
    if (description.trim().length < 5) {
      setSubmitError('Please enter at least 5 characters describing the hazard.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await submitTrailReport({
        mountainId,
        trailId,
        category,
        severity,
        description,
        lat: parsedLat,
        lng: parsedLng,
        aiClassification: visionResult
          ? `${visionResult.detectedCategory} (${visionResult.confidenceLabel})`
          : undefined,
      });
      setDescription('');
      setPhotoPreview(null);
      setVisionResult(null);
      setSubmitMessage(
        res.queuedOffline
          ? 'Device is offline: report queued locally and ready to sync when connection returns.'
          : 'Trail hazard report published with status "Newly reported".'
      );
    } catch (err: any) {
      setSubmitError(err?.message || 'Unable to submit trail report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="border-b border-white/10 pb-6">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Trail Condition & Hazard Reports</h1>
        <p className="text-sm text-gray-400 mt-1.5">
          Submit verified GPS hazard reports, attach trail photos for AI hazard classification, and confirm active reports from fellow hikers.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Report Submission Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 bg-[#131917] border border-white/10 rounded-xl p-6 space-y-4"
        >
          <h2 className="font-display text-xl font-semibold text-white">Submit Trail Hazard Report</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Mountain</label>
              <select
                value={mountainId}
                onChange={(e) => handleMountainSelect(e.target.value)}
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              >
                {MOUNTAINS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Trail Section</label>
              <select
                value={trailId}
                onChange={(e) => setTrailId(e.target.value)}
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              >
                {selectedMountain.trails.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Hazard Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as HazardCategory)}
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              >
                {HAZARD_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Severity Level</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as ReportSeverity)}
                className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              >
                {(['Low', 'Moderate', 'High', 'Critical'] as ReportSeverity[]).map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-gray-400">GPS Coordinates</label>
              <button
                type="button"
                onClick={handleUseCurrentGps}
                className="inline-flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 cursor-pointer"
              >
                <LocateFixed className="w-3 h-3" /> Use My GPS
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={lat}
                onChange={(e) => setLat(e.target.value)}
                placeholder="Latitude"
                className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs font-mono text-white"
              />
              <input
                type="text"
                value={lng}
                onChange={(e) => setLng(e.target.value)}
                placeholder="Longitude"
                className="bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs font-mono text-white"
              />
            </div>
          </div>

          {/* Photo upload + AI classification */}
          <div className="space-y-2">
            <label className="block text-xs text-gray-400">Trail Photograph (Optional AI Classification)</label>
            <label className="flex items-center justify-center gap-2 px-4 py-3 bg-[#0B0E0D] hover:bg-white/5 border border-dashed border-white/20 rounded-lg text-xs text-gray-300 cursor-pointer">
              <Camera className="w-4 h-4 text-emerald-400" />
              <span>Upload trail photo for Gemini hazard analysis</span>
              <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handlePhotoSelect} className="hidden" />
            </label>
            {photoPreview && (
              <img
                src={photoPreview}
                alt="Trail hazard upload preview"
                className="w-full h-36 object-cover rounded-lg border border-white/10"
              />
            )}
            {visionLoading && (
              <p className="text-xs text-emerald-400">Analyzing photo with Gemini Hazard Intelligence...</p>
            )}
            {visionError && <p className="text-xs text-amber-400">{visionError}</p>}
            {visionResult && (
              <div className="bg-black/40 border border-emerald-500/30 rounded-lg p-3 text-xs space-y-1">
                <div className="font-semibold text-emerald-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> AI Suggestion: {visionResult.detectedCategory} ({visionResult.severity})
                </div>
                <p className="text-gray-300">{visionResult.observations}</p>
                <p className="text-[11px] text-gray-500">
                  {visionResult.confidenceLabel} — please verify accuracy before submitting.
                </p>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs text-gray-400 mb-1">Hazard Description</label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Exact trail landmark, obstruction size, bypass options..."
              className="w-full bg-[#0B0E0D] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
            />
          </div>

          {submitError && <p className="text-xs text-red-400">{submitError}</p>}
          {submitMessage && <p className="text-xs text-emerald-400">{submitMessage}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer disabled:opacity-50"
          >
            {submitting ? 'Submitting...' : user ? 'Submit Trail Report' : 'Sign In & Submit Report'}
          </button>
        </form>

        {/* Reports Feed & Community Confirmation */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <select
                value={filterMountain}
                onChange={(e) => setFilterMountain(e.target.value)}
                className="bg-[#131917] border border-white/15 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="all">All Mountains</option>
                {MOUNTAINS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
              <div className="flex items-center gap-1 p-1 bg-[#131917] border border-white/10 rounded-lg">
                {(['active', 'resolved', 'all'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setFilterStatus(tab)}
                    className={`px-3 py-1 text-xs font-medium rounded-md capitalize cursor-pointer ${
                      filterStatus === tab ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>
            <span className="text-xs font-mono tabular-nums text-gray-400">{filteredReports.length} report(s)</span>
          </div>

          {filteredReports.length === 0 ? (
            <div className="bg-[#131917] border border-white/10 rounded-xl p-8 text-center text-sm text-gray-400">
              No trail reports match the current filter.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredReports.map((rep) => {
                const m = getMountainById(rep.mountainId);
                const isTerminal = rep.status === 'Resolved' || rep.status === 'Expired';
                return (
                  <div
                    key={rep.id}
                    className="bg-[#131917] border border-white/10 rounded-xl p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4"
                  >
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span
                          className={`font-semibold inline-flex items-center gap-1.5 ${
                            rep.severity === 'Critical' || rep.severity === 'High'
                              ? 'text-red-400'
                              : rep.severity === 'Moderate'
                              ? 'text-amber-400'
                              : 'text-gray-200'
                          }`}
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                          {rep.category} · {rep.severity}
                        </span>
                        <span className="text-gray-500">·</span>
                        <span className="text-gray-300">{rep.status}</span>
                        <span className="text-gray-500">·</span>
                        <span className="text-gray-400">{m.name}</span>
                      </div>
                      <p className="text-sm text-gray-200">{rep.description}</p>
                      {rep.aiClassification && (
                        <div className="text-[11px] text-emerald-400">Vision note: {rep.aiClassification}</div>
                      )}
                      <div className="text-[11px] text-gray-500 font-mono tabular-nums">
                        {rep.lat.toFixed(4)}, {rep.lng.toFixed(4)} · By {rep.reporterName} ·{' '}
                        {new Date(rep.createdAtIso).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-end justify-between gap-2 shrink-0">
                      <div className="text-xs font-mono tabular-nums text-gray-300">
                        {rep.confirmCount} confirmation(s)
                      </div>
                      {!isTerminal && (
                        <button
                          type="button"
                          onClick={async () => {
                            if (!user) {
                              await signInWithGoogle();
                              return;
                            }
                            await confirmTrailReport(rep.id, rep.confirmCount, rep.status as ReportStatus);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-emerald-600/20 border border-white/15 hover:border-emerald-500/40 rounded-lg text-xs text-gray-200 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          Still Accurate
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
