import React, { useMemo, useState } from 'react';
import { ArrowRight, MapPin, Mountain as MountainIcon, Search } from 'lucide-react';
import { MOUNTAINS } from '../data/mountains';
import { useTrailData } from '../context/TrailDataContext';
import { PageRoute } from '../types/trailguard';
import { ConditionText } from '../components/ConditionText';
import { LiveMountainMap } from '../components/LiveMountainMap';

interface ExploreMountainsPageProps {
  onNavigate: (route: PageRoute, mountainId?: string) => void;
}

export function ExploreMountainsPage({ onNavigate }: ExploreMountainsPageProps) {
  const { reports, publicSessions, gpsCoordinates, getEffectiveTrailCondition } = useTrailData();
  const [queryText, setQueryText] = useState('');
  const [regionFilter, setRegionFilter] = useState<'all' | 'india' | 'international'>('all');
  const [focusedMountainId, setFocusedMountainId] = useState<string>(MOUNTAINS[0].id);

  const filtered = useMemo(() => {
    return MOUNTAINS.filter((m) => {
      if (regionFilter === 'india' && m.isInternational) return false;
      if (regionFilter === 'international' && !m.isInternational) return false;
      const q = queryText.trim().toLowerCase();
      if (!q) return true;
      return (
        m.name.toLowerCase().includes(q) ||
        m.region.toLowerCase().includes(q) ||
        m.country.toLowerCase().includes(q)
      );
    });
  }, [queryText, regionFilter]);

  const focusedMountain = MOUNTAINS.find((m) => m.id === focusedMountainId) || MOUNTAINS[0];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/10 pb-6">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Explore Mountains</h1>
          <p className="text-sm text-gray-400 mt-1.5">
            Compare routes, elevations, water sources, shelters, rescue stations, and live hazard conditions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={queryText}
              onChange={(e) => setQueryText(e.target.value)}
              placeholder="Filter mountains..."
              className="pl-9 pr-4 py-2 bg-[#131917] border border-white/15 rounded-lg text-sm text-white placeholder:text-gray-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div className="flex items-center gap-1 p-1 bg-[#131917] border border-white/10 rounded-lg">
            {(['all', 'india', 'international'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setRegionFilter(tab)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer capitalize ${
                  regionFilter === tab ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab === 'india' ? 'Sahyadri / India' : tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Overview Map */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-sm font-medium text-gray-200 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-400" />
            Interactive Preview: <span className="text-white font-semibold">{focusedMountain.name}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {MOUNTAINS.map((m) => (
              <button
                key={m.id}
                onClick={() => setFocusedMountainId(m.id)}
                className={`px-2.5 py-1 text-xs rounded-md border cursor-pointer transition-colors ${
                  focusedMountainId === m.id
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-[#131917] border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                {m.name}
              </button>
            ))}
          </div>
        </div>
        <LiveMountainMap
          mountain={focusedMountain}
          reports={reports}
          publicSessions={publicSessions}
          userGps={gpsCoordinates}
          getTrailCondition={getEffectiveTrailCondition}
          heightClass="h-[360px]"
          compact
        />
      </div>

      {/* Mountain Cards Grid */}
      {filtered.length === 0 ? (
        <div className="bg-[#131917] border border-white/10 rounded-xl p-10 text-center text-sm text-gray-400">
          No destinations match "{queryText}". Reset your search filter to see all mountains.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((m) => {
            const easiest = m.trails.find((t) => t.routeTag === 'Easiest') || m.trails[0];
            const activeHazardCount = reports.filter(
              (r) => r.mountainId === m.id && r.status !== 'Resolved' && r.status !== 'Expired'
            ).length;
            const sheltersCount = m.pois.filter((p) => p.type === 'shelter').length;
            const waterCount = m.pois.filter((p) => p.type === 'water').length;
            const cond = getEffectiveTrailCondition(m.id, easiest.id, easiest.defaultCondition);

            return (
              <div
                key={m.id}
                className="bg-[#131917] border border-white/10 rounded-xl overflow-hidden flex flex-col sm:flex-row"
              >
                <div className="sm:w-2/5 aspect-[4/3] sm:aspect-auto relative bg-[#1B2320] shrink-0">
                  <img
                    src={m.imageUrl}
                    alt={m.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h2 className="font-display text-xl font-semibold text-white">{m.name}</h2>
                        <p className="text-xs text-gray-400">
                          {m.region} · {m.country}
                        </p>
                      </div>
                      <span className="font-mono tabular-nums text-xs font-semibold text-emerald-400 shrink-0">
                        {m.elevationM} m
                      </span>
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed line-clamp-2">{m.summary}</p>
                    <div className="pt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-gray-400">
                      <span>{m.trails.length} trails</span>
                      <span>·</span>
                      <span>{sheltersCount} shelter(s)</span>
                      <span>·</span>
                      <span>{waterCount} water source(s)</span>
                      <span>·</span>
                      <span>{activeHazardCount} active report(s)</span>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
                    <ConditionText condition={cond} />
                    <button
                      onClick={() => onNavigate('mountain-detail', m.id)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      View Details <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
